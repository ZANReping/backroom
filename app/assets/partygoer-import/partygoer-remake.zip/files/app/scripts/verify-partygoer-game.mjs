// 派对客重制：在真实运行的游戏里验收（L601、真实渲染器/AI/战斗/HUD）。
// 先在 3318 端口起开发服务，再 node scripts/verify-partygoer-game.mjs；
// 本脚本自己启动/关闭专属无头 QA 浏览器（--headless=new、.cache/partygoer-game-qa、调试端口 9319），不连接已有浏览器。
// 存档只写进这个独立浏览器目录的 localStorage（用于直接进入 L601），不触碰用户的任何存档。
import { spawn } from 'node:child_process'
import { mkdirSync, writeFileSync, rmSync } from 'node:fs'
// PG_QA_QUERY：默认 ?cpu=1——无头 SwiftShader 一画 GPU 蒙皮网格 GPU 进程就崩溃（exit_code=4，随后全体程序报 1282），
// cpu=1 让派对客改用 CPU 蒙皮替身；真实 GPU 复验时设 PG_QA_QUERY= 关闭。
const query = process.env.PG_QA_QUERY ?? '?cpu=1'
const base = process.env.PG_QA_URL ?? 'http://127.0.0.1:3318', port = process.env.PG_GAME_CDP ?? '9319', out = 'reports/partygoer/'
mkdirSync(out, { recursive: true })
const profile = `${process.cwd()}/.cache/partygoer-game-qa`
// 分阶段运行（单条命令有时长上限）：launch → enter（可重复，直到进入 L601）→ run 或 shots → close
// shots：五种姿态各截一张 game2-<光影>-<姿态>.png（伪装递蛋糕 / 暴起抓咬 / 狂战士开胸 / 倒地爬走 / 火盐焚烧）
const phase = process.argv[2] ?? 'launch', mode = process.argv[3] ?? 'classic'
if (phase === 'launch') {
  rmSync(profile, { recursive: true, force: true })
  const c = spawn('chromium', ['--headless=new', '--enable-automation', `--remote-debugging-port=${port}`, `--user-data-dir=${profile}`, '--no-first-run', '--no-default-browser-check', '--no-sandbox', '--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--window-size=1600,900', 'about:blank'], { stdio: 'ignore', detached: true })
  c.unref(); writeFileSync(`${process.cwd()}/.cache/partygoer-game-qa.pid`, String(c.pid)); console.log('QA 浏览器 pid', c.pid); process.exit(0)
}
const errors = [], report = { mode, phase, steps: [] }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
try {
  let page
  for (let i = 0; i < 80 && !page; i++) { await sleep(250); try { page = (await (await fetch(`http://127.0.0.1:${port}/json/list`)).json()).find((p) => p.type === 'page') } catch { /* 等浏览器 */ } }
  if (!page) throw Error('QA 浏览器未启动')
  const ws = new WebSocket(page.webSocketDebuggerUrl); await new Promise((r) => ws.addEventListener('open', r, { once: true }))
  let seq = 0; const pending = new Map()
  ws.addEventListener('message', (e) => { const r = JSON.parse(e.data); if (r.method === 'Runtime.exceptionThrown') errors.push(JSON.stringify(r.params.exceptionDetails).slice(0, 600)); if (r.method === 'Runtime.consoleAPICalled' && r.params.type === 'error') errors.push(r.params.args?.map((a) => a.value ?? a.description).join(' ').slice(0, 600)); const p = pending.get(r.id); if (p) { pending.delete(r.id); r.error ? p.reject(r.error) : p.resolve(r.result) } })
  const send = (method, params = {}) => new Promise((resolve, reject) => { const id = ++seq; pending.set(id, { resolve, reject }); ws.send(JSON.stringify({ id, method, params })) })
  const ev = async (expression) => { const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true }); if (r.exceptionDetails) throw Error(JSON.stringify(r.exceptionDetails).slice(0, 800)); return r.result?.value }
  const until = async (expr, label, tries = Number(process.env.PG_TRIES ?? 300)) => { for (let i = 0; i < tries; i++) { await sleep(300); if (await ev(`Boolean(${expr})`)) return } throw Error('超时：' + label) }
  const shot = async (n) => writeFileSync(out + n + '.png', Buffer.from((await send('Page.captureScreenshot', { format: 'png' })).data, 'base64'))
  const step = (name, data) => { report.steps.push({ name, ...data }); console.log(name, JSON.stringify(data)) }
  await send('Runtime.enable'); await send('Page.enable')
  const ver = await send('Browser.getVersion'), cl = await send('Browser.getBrowserCommandLine')
  if (!ver.userAgent.includes('HeadlessChrome') || !cl.arguments.includes('--headless=new') || !cl.arguments.some((a) => a.includes('partygoer-game-qa'))) throw Error('不是本脚本的无头 QA 浏览器')
  await send('Emulation.setDeviceMetricsOverride', { width: 1600, height: 900, deviceScaleFactor: 1, mobile: false })
  if (phase === 'close') { await send('Browser.close').catch(() => {}); throw Error('closed') }
  const inGame = await ev(`Boolean(window.__engine && __engine.player.level===12 && __renderer?.isNearWorldReady(__engine))`).catch(() => false)
  if (phase === 'enter' && !inGame) {
  const navigated = await ev(`location.href.startsWith(${JSON.stringify(base)})`)
  if (!navigated) {
  const init = await send('Page.addScriptToEvaluateOnNewDocument', { source: `localStorage.clear();sessionStorage.clear();localStorage.setItem('br_settings',JSON.stringify({renderResolution:'native',renderScale:100,maxPixelRatio:1,dynamicRes:false,lightMode:${JSON.stringify(mode)},sceneLightLimit:16,shadowQuality:1,lightShadows:1,loadingBudgetMs:6,devMode:true}))` })
  await send('Page.navigate', { url: base + '/' + query })
  await until('window.__engine && document.querySelector(".title-menu")', '标题界面')
  await send('Page.removeScriptToEvaluateOnNewDocument', { identifier: init.identifier })
  }
  await until('window.__engine && document.querySelector(".title-menu")', '标题界面')
  const hasSave = await ev(`Boolean(localStorage.getItem('br_save_slot1'))`)
  if (!hasSave) {
  await ev(`(()=>{const raw=__engine.snapshot();localStorage.setItem('br_save_slot1',JSON.stringify({...raw,seed:6767,level:12,mapSeed:6767,savedAt:Date.now(),player:{...raw.player,level:12}}))})()`)
  await send('Page.reload')
  await until(`document.querySelector('.title-menu')`, '读档标题')
  }
  await ev(`(()=>{const b=[...document.querySelectorAll('.menu-btn')].find(b=>b.textContent.includes('继续游戏'));b.click()})()`)
  await sleep(600)
  await ev(`(()=>{const b=[...document.querySelectorAll('.hud-panel button')].find(b=>b.textContent.includes('继续'));b&&b.click()})()`)
  await until('__engine.player.level===12 && !__engine.paused && __renderer.isNearWorldReady(__engine)', '进入 L601', 250)
  }
  if (phase === 'enter') { step('已进入 L601', { ok: await ev(`__engine.player.level===12`) }); throw Error('enter-done') }
  if (!inGame) throw Error('还没有进入 L601，先运行 enter')

  if (phase === 'shots') {
    report.query = query
    await ev(`(()=>{const b=[...document.querySelectorAll('.hud-panel button')].find(b=>b.textContent.trim()==='▾');b&&b.click();return true})()`) // 收起开发者面板，免得挡住模型
    // 把目标派对客放到玩家正前方 dist 米处；其余派对客挪到它身后侧面；AI 冻结，姿态量直接写入（每张截图前冻结这一帧的状态）
    const frame = (dist, pitch, side = 0) => ev(`(()=>{const e=__engine,p=e.player,all=e.map.entities.filter(z=>z.def.type==='partygoer'&&!z.dead);e.dev.god=true;e.dev.statLock=true;e.dev.frozenAI=true
      const q=all.find(z=>z.id===window.__pgT)??all[0];window.__pgT=q.id
      let best=null;for(let a=0;a<72;a++){const ang=a/72*Math.PI*2;const s=e.devFindSpot(q.x+Math.cos(ang)*${dist},q.y+Math.sin(ang)*${dist},0.6);if(s&&Math.abs(Math.hypot(s.x-q.x,s.y-q.y)-${dist})<0.35&&e.los(s.x,s.y,q.x,q.y)){best=s;break}}
      if(best){p.x=best.x;p.y=best.y}
      const dx=q.x-p.x,dy=q.y-p.y,d=Math.hypot(dx,dy);q.facing=Math.atan2(-dy,-dx)
      __look.yaw=Math.atan2(-dx,-dy)+${side};__look.pitch=${pitch}
      let k=0;for(const o of all){if(o===q)continue;k++;const s=e.devFindSpot(q.x+dx/d*1.2+(-dy/d)*1.3*k,q.y+dy/d*1.2+(dx/d)*1.3*k,1);if(s){o.x=s.x;o.y=s.y;o.facing=q.facing}}
      return{id:q.id,d:+d.toFixed(2)}})()`)
    const pose = (js) => ev(`(()=>{const q=__engine.map.entities.find(z=>z.id===window.__pgT);const s=q.pg;${js};return{phase:s.phase,offer:s.offer,open:s.open,down:s.down,crawl:s.crawl,burn:s.burn,arms:s.armHp}})()`)
    const check = () => ev(`(()=>{const R=__renderer,q=__engine.map.entities.find(z=>z.id===window.__pgT),g=R.entityMeshes.get(q.id);let cpu=0,sk=0;g?.traverse(o=>{if(o.userData.cpuSkin&&o.visible)cpu++;if(o.isSkinnedMesh&&o.visible)sk++});return{lost:R.three.getContext().isContextLost(),visible:!!g?.visible,ready:R.itemWarmup.ready(g),cpuSkinMeshes:cpu,gpuSkinVisible:sk}})()`)
    const take = async (name, data) => { await sleep(1500); const c = await check(); step(name, { ...data, ...c }); await shot(`game2-${mode}-${name}`) }
    // PG_SHOTS=feign-cake,burn 只截部分（真实光影下软件光栅较慢，单条命令装不下五张时分批）
    const want = (n) => !process.env.PG_SHOTS || process.env.PG_SHOTS.split(',').includes(n)
    const base0 = `s.berserk=false;s.armHp=[26,26];s.armCut=[0,0];s.open=0;s.claw=0;s.down=0;s.crawl=0;s.burn=0;s.reach=0;s.bite=0;s.wave=0;s.offer=0;s.speed=0;s.hitT=99;q.dead=false`
    // 等派对客模型准备好（预热完成、可见）
    await frame(3.6, 0.02); await until(`(()=>{const R=__renderer,g=R.entityMeshes.get(window.__pgT);return g&&g.visible&&R.itemWarmup.ready(g)})()`, '派对客模型就绪', 200)
    // 1) 伪装：挥手后双手递上蛋糕
    if (want('feign-cake')) await frame(3.6, 0.02), await take('feign-cake', await pose(`${base0};s.phase='party';s.offer=1;s.wave=0.25`))
    // 2) 暴起抓咬：吸盘口伸向玩家
    if (want('reveal-bite')) await frame(2.9, 0.06), await take('reveal-bite', await pose(`${base0};s.phase='bite';s.reach=1;s.bite=1;s.speed=0`))
    // 3) 狂战士开胸：双臂已断（真实部位伤害结算），胸甲弹开、蜈蚣爪伸出
    if (want('berserk-chest')) await ev(`(async()=>{const m=await import('/src/game/engine/partygoerAI.ts');const e=__engine,q=e.map.entities.find(z=>z.id===window.__pgT);m.partygoerDamage(e,q,30,'melee','armL');m.partygoerDamage(e,q,30,'melee','armR');q.stunT=0;return q.pg.berserk})()`)
    if (want('berserk-chest')) await frame(3.4, 0.04), await take('berserk-chest', await pose(`s.phase='claw';s.berserk=true;s.armHp=[0,0];s.armCut=[1,1];s.open=1;s.claw=0.7;s.burn=0;s.offer=0;s.wave=0;s.reach=0;s.bite=0;s.down=0;s.crawl=0;s.speed=0`))
    // 4) 倒地后面朝下爬走
    if (want('down-crawl')) await frame(3.2, -0.32), await take('down-crawl', await pose(`s.phase='crawl';s.open=1;s.claw=0;s.down=1;s.crawl=1;s.speed=0.42`))
    // 5) 火盐焚烧：真实投掷物落地逻辑点燃，放开 AI 约 0.9s 让火势/黑烟起来再冻结
    if (want('burn')) {
    await frame(3.4, -0.22)
    await ev(`(async()=>{const e=__engine,q=e.map.entities.find(z=>z.id===window.__pgT);q.pg.phase='down';q.pg.crawl=0;e.dev.frozenAI=false;e.landProjectile({id:9,type:'firesalt',x:q.x,y:q.y,z:q.z,floorZ:q.z,vx:0,vy:0,vz:0},q.x+0.3,q.y);await new Promise(r=>setTimeout(r,900));e.dev.frozenAI=true;return q.pg.phase})()`)
    // 无头软件光栅帧率很低，0.9s 内 AI 只推进了几帧；把火势推进到一半（与 BURN_T 计时一致），按 AI 的 smoke() 同格式补几颗黑烟/火星
    await take('burn', await pose(`s.phase='burn';s.burn=0.55;const e=__engine;for(let i=0;i<26;i++){const a=Math.random()*Math.PI*2,r=Math.random()*0.5;e.particles.push({x:q.x+Math.cos(a)*r,y:q.y+Math.sin(a)*r,z:q.z+0.2+Math.random()*1.1,vx:(Math.random()-0.5)*0.4,vy:(Math.random()-0.5)*0.4,vz:0.6+Math.random()*0.7,t:0,life:2.4+Math.random()*1.2,color:Math.random()<0.3?'#e8622c':(Math.random()<0.5?'#141210':'#2a2622'),size:5+Math.random()*6,opacity:0.8})}`))
    }
    ws.close(); throw Error('shots-done')
  }
  // 记录消息
  await ev(`(()=>{window.__msgs=[];const m=__engine.msg.bind(__engine);__engine.msg=(t,k)=>{window.__msgs.push(t);return m(t,k)}})()`)
  const lvl = await ev(`(()=>{const pg=__engine.map.entities.filter(e=>e.def.type==='partygoer');const lead=pg[0];return{n:pg.length,spread:lead?Math.max(...pg.map(e=>Math.hypot(e.x-lead.x,e.y-lead.y))):-1,cakes:__engine.map.items.filter(i=>i.type==='velvetcake').length,posters:__engine.map.structures.filter(s=>s.kind==='megposter'&&s.data?.party).length,flags:__engine.map.structures.filter(s=>s.kind==='partyflag').length}})()`)
  step('L601 生成', lvl)
  // ---------- 1) 走到派对客群旁：看它们假装办派对 ----------
  await ev(`(()=>{const e=__engine,p=e.player,pg=e.map.entities.filter(q=>q.def.type==='partygoer');e.dev.god=true;e.dev.statLock=true
    // 只留生成的第一群，其余移除；把玩家放到领头者 5m 外一个能站的格子上，面朝它们
    const lead=pg[0];for(let a=0;a<64;a++){const ang=a/64*Math.PI*2,r=4.6;const s=e.devFindSpot(lead.x+Math.cos(ang)*r,lead.y+Math.sin(ang)*r,1);if(s&&e.los(s.x,s.y,lead.x,lead.y)){p.x=s.x;p.y=s.y;break}}
    __look.yaw=Math.atan2(-(lead.x-p.x),-(lead.y-p.y));__look.pitch=-0.05
    // 远处的蛋糕/海报/红旗挪到群边，便于同框
    for(const q of pg){q.pg&&(q.pg.phase='party')}
    return true})()`)
  await sleep(2500)
  const feign = await ev(`(()=>{const p=__engine.player;return __engine.map.entities.filter(q=>q.def.type==='partygoer').map(q=>({d:+Math.hypot(q.x-p.x,q.y-p.y).toFixed(2),phase:q.pg?.phase,offer:+(q.pg?.offer??0).toFixed(2),wave:+(q.pg?.wave??0).toFixed(2),color:q.pg?.color,intern:q.pg?.intern}))})()`)
  step('伪装靠近', { feign })
  await shot('game-feign')
  await sleep(3500)
  const after = await ev(`(()=>{const p=__engine.player;return{pg:__engine.map.entities.filter(q=>q.def.type==='partygoer').map(q=>({d:+Math.hypot(q.x-p.x,q.y-p.y).toFixed(2),phase:q.pg?.phase,flank:q.pg?.flank})),msgs:window.__msgs.slice(-8)}})()`)
  step('暴起', after)
  await shot('game-reveal')
  // ---------- 2) 狂战士：砍断双臂（真实 combat 部位结算）→ 胸甲弹开 ----------
  const berserk = await ev(`(async()=>{const m=await import('/src/game/engine/partygoerAI.ts');const e=__engine,p=e.player,q=e.map.entities.find(z=>z.def.type==='partygoer'&&!z.dead);
    m.partygoerDamage(e,q,30,'melee','armL');m.partygoerDamage(e,q,30,'melee','armR');e.dev.frozenAI=true;q.stunT=0;
    return{berserk:q.pg.berserk,arms:q.pg.armHp,id:q.id,x:q.x,y:q.y}})()`)
  step('断臂→狂战士', berserk)
  await ev(`(()=>{const e=__engine;e.dev.frozenAI=false})()`); await sleep(900); await ev(`(()=>{const e=__engine;e.dev.frozenAI=true;const p=e.player,q=e.map.entities.find(z=>z.id===${berserk.id});__look.yaw=Math.atan2(-(q.x-p.x),-(q.y-p.y));q.facing=Math.atan2(p.y-q.y,p.x-q.x)})()`)
  await sleep(500); await shot('game-berserk')
  // ---------- 3) 打头 → 倒地；火盐晶体烧尽（真实投掷物落地逻辑） ----------
  const down = await ev(`(async()=>{const m=await import('/src/game/engine/partygoerAI.ts');const e=__engine,q=e.map.entities.find(z=>z.id===${berserk.id});for(let i=0;i<20&&q.pg.phase!=='down';i++)m.partygoerDamage(e,q,25,'melee','head');q.pg.down=1;return{phase:q.pg.phase,dead:q.dead,hp:q.hp}})()`)
  step('打头倒地', down)
  await sleep(400); await shot('game-down')
  const burn = await ev(`(async()=>{const e=__engine,q=e.map.entities.find(z=>z.id===${berserk.id});e.dev.frozenAI=false;e.landProjectile({id:9,type:'firesalt',x:q.x,y:q.y,z:q.z,floorZ:q.z,vx:0,vy:0,vz:0},q.x+0.3,q.y);await new Promise(r=>setTimeout(r,1200));const ph=q.pg.phase,b=q.pg.burn;return{phase:ph,burn:b}})()`)
  step('火盐点燃', burn)
  await shot('game-burn')
  await sleep(2600)
  const ash = await ev(`(()=>{const e=__engine;const q=e.map.entities.find(z=>z.id===${berserk.id});return{gone:!q||q.dead,msgs:window.__msgs.filter(t=>/硫磺|灰|黑烟/.test(t))}})()`)
  step('烧尽', ash)
  // ---------- 4) 转化：被咬到满值 → 加入派对 ----------
  const conv = await ev(`(async()=>{const e=__engine,p=e.player;e.dev.god=false;e.dev.frozenAI=false;const keep=setInterval(()=>{if(!e.over)p.hp=100},50);
    const q=e.map.entities.find(z=>z.def.type==='partygoer'&&!z.dead&&!z.pg?.berserk);if(!q)return{skip:true}
    q.pg.phase='hunt';q.pg.heardT=0;const s=e.devFindSpot(q.x+1.2,q.y,2);if(s){p.x=s.x;p.y=s.y}
    const samples=[];for(let i=0;i<60&&!e.over;i++){await new Promise(r=>setTimeout(r,250));samples.push(e.partyConv)}
    clearInterval(keep);return{conv:e.partyConv,over:e.over,samples:samples.filter((v,i,a)=>i===0||v!==a[i-1]),newborn:e.map.entities.some(z=>z.def.type==='partygoer'&&Math.hypot(z.x-p.x,z.y-p.y)<0.01)}})()`)
  step('转化到满', conv)
  await sleep(1500); await shot('game-joined')
  report.textDeath = await ev(`document.body.innerText.includes('加入了派对')`)
  step('死亡画面', { text: report.textDeath })
  ws.close()
} catch (err) { const m = String(err?.message ?? err); if (m !== 'enter-done' && m !== 'closed' && m !== 'shots-done') { report.error = m; console.log('失败：', m) } }
finally {
  report.errors = errors
  if (phase === 'run') writeFileSync(out + `game-verify-${mode}.json`, JSON.stringify(report, null, 2) + '\n')
  if (phase === 'shots') { // 分批截图时合并到同一份结果（同名步骤以本次为准）
    const f = out + `game2-verify-${mode}.json`
    if (process.env.PG_SHOTS) { try { const old = JSON.parse((await import('node:fs')).readFileSync(f, 'utf8')); report.steps = [...old.steps.filter((o) => !report.steps.some((n) => n.name === o.name)), ...report.steps]; report.errors = [...(old.errors ?? []), ...report.errors] } catch { /* 首批 */ } }
    writeFileSync(f, JSON.stringify(report, null, 2) + '\n')
  }
  if (phase === 'close') { try { process.kill(-Number((await import('node:fs')).readFileSync(`${process.cwd()}/.cache/partygoer-game-qa.pid`, 'utf8')), 'SIGKILL') } catch { /* 已退出 */ } }
  if (errors.length) console.log('浏览器错误：', errors.length, JSON.stringify(errors.slice(0, 5)).slice(0, 1500))
  process.exit(0)
}
