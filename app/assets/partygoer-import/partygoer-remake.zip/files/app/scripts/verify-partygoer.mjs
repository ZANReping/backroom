// 派对客重制：无头 Chromium 截图验收（原型页 proto-partygoer.html）。
// 用法：先在 3318 端口起开发服务（npx vite --port 3318 --strictPort），再 node scripts/verify-partygoer.mjs [视图名...]
// 本脚本自己启动/关闭专属 QA 浏览器（--headless=new、独立用户目录 .cache/partygoer-qa、调试端口 9318），不连接任何已有浏览器。
import { spawn } from 'node:child_process'
import { mkdirSync, writeFileSync } from 'node:fs'
const base = process.env.PG_QA_URL ?? 'http://127.0.0.1:3318', port = process.env.PG_QA_CDP ?? '9318', out = 'reports/partygoer/'
mkdirSync(out, { recursive: true })
const VIEWS = {
  front: ['/proto-partygoer.html?mode=front&cpu=1', 1280, 900],
  side: ['/proto-partygoer.html?mode=side&cpu=1', 1280, 900],
  back: ['/proto-partygoer.html?mode=back&cpu=1', 1280, 900],
  close: ['/proto-partygoer.html?mode=close&cpu=1', 1280, 900],
  chest: ['/proto-partygoer.html?mode=chest&cpu=1', 1280, 900],
  poses: ['/proto-partygoer.html?mode=poses&cpu=1', 1920, 1080],
  colors: ['/proto-partygoer.html?mode=colors&cpu=1', 1920, 1080],
  'front-real': ['/proto-partygoer.html?mode=front&cpu=1&real=1', 1280, 900],
  'poses-real': ['/proto-partygoer.html?mode=poses&cpu=1&real=1', 1920, 1080],
}
const want = process.argv.slice(2).length ? process.argv.slice(2) : Object.keys(VIEWS)
const prefix = process.env.PG_SHOT_PREFIX ?? ''
const chrome = spawn('chromium', ['--headless=new', `--remote-debugging-port=${port}`, `--user-data-dir=${process.cwd()}/.cache/partygoer-qa`, '--enable-automation', '--no-first-run', '--no-default-browser-check', '--disable-gpu-sandbox', '--no-sandbox', '--enable-unsafe-swiftshader', '--use-angle=swiftshader', 'about:blank'], { stdio: 'ignore' })
const errors = [], results = {}
try {
  let page
  for (let i = 0; i < 60 && !page; i++) { await new Promise((r) => setTimeout(r, 250)); try { page = (await (await fetch(`http://127.0.0.1:${port}/json/list`)).json()).find((p) => p.type === 'page') } catch { /* 等浏览器起来 */ } }
  if (!page) throw Error('QA 浏览器未启动')
  const ws = new WebSocket(page.webSocketDebuggerUrl); await new Promise((r) => ws.addEventListener('open', r, { once: true }))
  let seq = 0; const pending = new Map()
  ws.addEventListener('message', (e) => { const r = JSON.parse(e.data); if (r.method === 'Runtime.exceptionThrown') errors.push(r.params.exceptionDetails); if (r.method === 'Runtime.consoleAPICalled' && r.params.type === 'error') errors.push(r.params.args?.map((a) => a.value ?? a.description).join(' ')); const p = pending.get(r.id); if (p) { pending.delete(r.id); r.error ? p.reject(r.error) : p.resolve(r.result) } })
  const send = (method, params = {}) => new Promise((resolve, reject) => { const id = ++seq; pending.set(id, { resolve, reject }); ws.send(JSON.stringify({ id, method, params })) })
  const ev = async (expression) => { const r = await send('Runtime.evaluate', { expression, returnByValue: true }); return r.result?.value }
  await send('Runtime.enable'); await send('Page.enable')
  const ver = await send('Browser.getVersion'), cl = await send('Browser.getBrowserCommandLine')
  if (!ver.userAgent.includes('HeadlessChrome') || !cl.arguments.includes('--headless=new')) throw Error('不是本脚本的无头 QA 浏览器')
  for (const name of want) {
    const [path, w, h] = VIEWS[name]
    await send('Emulation.setDeviceMetricsOverride', { width: w, height: h, deviceScaleFactor: 1, mobile: false })
    await send('Page.navigate', { url: base + path })
    let ok = false
    for (let i = 0; i < 300 && !ok; i++) { await new Promise((r) => setTimeout(r, 200)); ok = !!(await ev('window.__ready===true')) }
    await new Promise((r) => setTimeout(r, 400))
    results[name] = { ready: ok, retries: await ev('window.__retries') }
    writeFileSync(out + prefix + name + '.png', Buffer.from((await send('Page.captureScreenshot', { format: 'png' })).data, 'base64'))
    console.log(name, JSON.stringify(results[name]))
  }
  await send('Browser.close').catch(() => {})
  ws.close()
} finally {
  writeFileSync(out + prefix + 'verify-result.json', JSON.stringify({ results, errors }, null, 2) + '\n')
  try { chrome.kill('SIGKILL') } catch { /* 已退出 */ }
  if (errors.length) console.log('浏览器错误：', JSON.stringify(errors).slice(0, 2000))
}
