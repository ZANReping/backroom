import {settlementColliders} from './settlementColliders'
import {isL5DecorKind,L5_DECOR_DEFS} from '../content/l5Decor'
import { appendLegacyStations, settlementCeiling } from './settlement'
// 程序化地图生成：房间+走廊/迷宫混合，按层级 motif 放置结构
import { RNG } from '../core/rng'
import { l1RoofAt } from './l1Architecture'
import { l3RoofAt } from './l3Architecture'
import type { LevelDef, Structure, GroundItem, LightSource, ExitInstance, FloorBand } from '../core/types'
import { UNIVERSAL_ITEMS } from '../content/items'
import { makeEntity, ENTITIES, type Entity } from '../entities'
import { placePrefabs, scatterFeatures } from '../prefabs'
import { generateInfinite, type InfiniteState } from './infinite'
import { bedHeadDeg, infiniteImplFor, type CaveVolumeDef } from './infiniteRegistry' // v55：床类床头靠墙朝向助手
import './infiniteL1' // v29：注册 Level 1 无限 chunk 生成器（副作用导入）
import './infiniteL2' // v41：注册 Level 2 无限 chunk 生成器（副作用导入）
import './infiniteL3' // v51：注册 Level 3 无限 chunk 生成器（副作用导入）
import './infiniteL4' // v54：注册 Level 4 无限 chunk 生成器（副作用导入）
import './infiniteL5' // v54：注册 Level 5 无限 chunk 生成器（副作用导入）
import './infiniteL6' // v56：注册 Level 6 地表/地下双层无限生成器（副作用导入）
import './infiniteL7' // v57：注册 Level 7 入口房间 + 四深度带无限海洋生成器（副作用导入）
import './infiniteL8' // v59：注册 Level 8 无限有机洞穴与生态分区生成器（副作用导入）
import './infiniteL9' // v61：注册 Level 9 无限郊区、住宅街与第九大道引导路线生成器
import './infiniteL10' // v62：注册 Level 10 无限农田、连续道路与湖泊生成器
import './infiniteL11'
import { l11MetroRamp, l11SpaceAt } from './l11Layout'
import { l11MetroColliders,L11_METRO_CEILING } from './l11Metro'
import { l11CanalAt,l11BridgeDeck } from './l11Hydrology'
import { l11BuildingColliders, l11PropColliders,l11CollidersNear,l11CollisionRevision,l11StructureBounds } from './l11Collision'
import { l11SolidHits,l11SolidSegmentHit,l11SolidSurface,type L11Solid,type L11SolidCollider,type SolidPoint } from './l11Solid'
import { isL11DecorKind } from '../content/l11Decor'
import { inPolygon, circlePolygon, type Polygon } from './l11Geometry'
import { genDeep } from './mapgenDeep'
import { genOutpost } from './mapgenOutpost'
import { CONTAINER_KINDS } from '../decorations/containers'
import { l3AngelCollision } from './l3AngelCollision'
import { generationObstacles } from './generationObstacles'

export interface GameMap {
  settlement?: import('../content/settlementTypes').SettlementMapData
  l1Architecture?: boolean // Derived Level 1 capability, regenerated on load (no save schema change).
  w: number
  h: number
  tiles: Uint8Array // 0虚空 1地板 2墙
  structures: Structure[]
  ratGear?: import('../engine/ratAI').RatGear[] // v79：L3 水豚种尸鼠布下的电击陷阱/土制炸弹（世界坐标；不入存档/联机）
  items: GroundItem[]
  lights: LightSource[]
  exits: ExitInstance[]
  entities: Entity[]
  spawn: { x: number; y: number }
  npcs?: { id: string; x: number; y: number; facing?: number; floor?: FloorBand }[] // NPC 所在楼层带，缺省 0
  npcDefs?: import('../content/npcs').NpcDef[] // 随机 NPC 定义（mapgenOutpost 生成；静态 NPC 走 npcs.ts 注册表）
  zones?: { name: string; x: number; y: number; z?: number; x0?: number; y0?: number; x1?: number; y1?: number }[] // 区域名称标注（据点大地图用；x,y=标注中心；v43：z=楼层带 0主层/1上层，缺省 0；v54：可选矩形范围 x0/y0/x1/y1——HUD 区域名矩形内优先，缺省=点标注）
  wet: Uint8Array // 减速区
  // ---- v7 数据契约：高度与室外 ----
  elev: Uint8Array // 每瓦片：0=正常 1=低洼(-1.2m) 2=高台(+1.2m) 3=室外地面 4=深渊（坠入即死）
  outdoor: Uint8Array // 0=室内 1=室外（无天花板/天空/环境光提高）
  step: Uint8Array // 台阶/坡道：bit0-2=上坡方向(1+x 2-x 3+y 4-y)，bit3-4=低侧 elev，bit5-6=高侧 elev
  crawl: Uint8Array // 1=蹲伏低通道（头顶风道，未蹲伏不可进入）
  ceiling: Uint8Array // 0=正常层高 1=挑高（L5 大堂）
  // ---- v13 数据契约：多层结构与液体 ----
  up: Uint8Array // 1=该瓦片存在上层地板（z=FLOOR_H）；下层 tiles=1 仍可走（楼上楼下双层）
  upWall: Uint8Array // 1=上层墙体（仅阻挡上层通行；下层不受影响）
  up2: Uint8Array // v54：1=该瓦片存在第三层地板（z=2×FLOOR_H）；先例=Gamma 基地真三层
  upWall2: Uint8Array // v54：1=第三层墙体（仅阻挡第三层通行）
  stair: Int32Array // 楼梯坡道：0=无；否则 dir(低3位:1+x 2-x 3+y 4-y) | loCm<<3 | hiCm<<17（任意高度连续爬升）
  liquid: Uint8Array // 0=无 1=深水（下沉至 -seaFloor，可游泳） 2=浅水（仅减速+涟漪）
  seaFloor: Float32Array // 每瓦片海床深度（米，水面以下，正数；深水=该深度，非深水缺省 POOL_DEPTH）——v57o L7 垂直深度轴
  floors: number // 可行走楼层总数（1=单层，2=双层，3=三层[v54]）
  // ---- v56 九轮：地下平面（Level 6 双层结构：1F 苔原 + -1F 地下走廊）----
  dn: Uint8Array // 1=地下可走地板瓦片（z=UNDER_FLOOR）；0=地下墙体/土层（阻挡地下通行；地表不受影响）
  dnWall: Uint8Array // 1=地下墙体/土层（阻挡地下通行；地表不受影响）
  hasUnderground?: boolean // O(1) 地下层能力标志，避免热路径扫描 dn 数组
  terrain?: Float32Array // 室外自然地形微起伏（米；L6 由世界坐标低频噪声生成）
  caveCeil?: Float32Array // L8 有机洞穴绝对洞顶高度（与 terrain 同坐标连续采样）
  organicCave?: boolean // L8：渲染/碰撞统一使用有机洞穴曲面
  caveVolumeId?: number // 新洞穴类模式：指向 InfiniteLevelImpl.caveVolume，避免硬编码 L8
  l7SeaTerrain?: boolean // v57t：L7 室外海床/荒岛连续高度场（碰撞与渲染共用一套平滑斜面）
  l10LakeTerrain?: boolean // L10：岸坡与湖底共用 terrain 连续高度场，水面固定在地表水位
  // ---- v17 数据契约：无限模式（L0）与墙面/地面 tint ----
  tint: Uint8Array // 0=无 1=马尼拉墙纸 2=红室 3=熄灯区（几何着色/雾氛围用）
  inf?: InfiniteState // 无限 chunk 模式状态（仅 L0；有限层级缺省）
  // ---- v25：栖息地降级计数（`${type}:${habitat}` → 次数；无符合瓦片时降级 any 的告警计数）----
  habitatFallback?: Record<string, number>
}

// ---- v7 高度系统 ----
export const ELEV_H = [0, -1.2, 1.2, 0, -10] as const // elev → 地面高度（米）；3=室外地面=0；4=深渊（深坑洞底，看不见底）
export const STEP_UP = 0.65 // 步行可直接踏上的最大高差（坡道连续过渡，高台需跳）
export const JUMP_REACH = 1.35 // 跳跃可逾越的最大高差（连通性 BFS 通行规则用）

// ---- v13 多层/液体常量 ----
export const FLOOR_H = 3.0 // 上层地板高度（米）
export const BAND_MID = FLOOR_H / 2 // 楼层高度带分界：z ≥ 1.5 视为上层
export const POOL_DEPTH = 1.7 // 深水池深（玩家沉入水下，眼高没入水面）
export const SHALLOW_DEPTH = 0.25 // 浅水洼深（仅减速，不沉没）
// v56 九轮：地下平面（Level 6：1F 苔原之下数米，-1F 地下走廊）
export const UNDER_FLOOR = -5.0 // 地下走廊地面高度（米）
export const UNDER_CEIL = -2.0 // 地下走廊天花板高度（米，层高 3.0）
export const UNDER_MID = -1.0 // 地下带分界：z < UNDER_MID 视为身处地下平面

// v29a：液体水面高度（= liquid 水位；深水≈所在 elev 地面 +0.03，浅水洼 -0.17），供漂浮物贴水面
export function liquidSurfaceH(m: GameMap, tx: number, ty: number): number | null {
  if (tx < 0 || ty < 0 || tx >= m.w || ty >= m.h) return null
  const canal=l11MapWater(m,tx+.5,ty+.5);if(canal)return canal.bridge?null:canal.surface
  const i = ty * m.w + tx
  if (m.liquid[i] === 1) return m.l10LakeTerrain ? 0.015 : ELEV_H[m.elev[i]] + 0.03
  if (m.liquid[i] === 2) return m.organicCave ? surfaceUndulationAt(m, tx + 0.5, ty + 0.5) + 0.035 : ELEV_H[m.elev[i]] - 0.17
  return null
}
// v29a：金属/肉类/玻璃罐等致密物品落水沉底（-POOL_DEPTH），其余（塑料瓶/绳索/纸张/木制品等）贴水面漂浮
const WATER_SINK = new Set(['canned', 'thingmeat', 'battery', 'wrench', 'crowbar', 'silverware', 'skeleton', 'housekey', 'gas', 'nails', 'presses', 'uvlamp', 'stapler'])
/** 液态瓦片物品生成高度（纯数据版）：沉底物→水底，漂浮物→水面；liquid=0→undefined（默认地面高度）。
 *  Level 7 无限生成器在 chunk raw 阶段没有 GameMap，用本函数计算漂浮/沉底高度。 */
export function waterItemZForTile(liquid: number, elev: number, type: string, depth = POOL_DEPTH): number | undefined {
  if (liquid === 0) return undefined
  const surface = liquid === 1 ? ELEV_H[elev] + 0.03 : ELEV_H[elev] - 0.17
  if (liquid === 1 && WATER_SINK.has(type)) return ELEV_H[elev] - Math.max(0.3, depth)
  return surface
}
/** 物品落在液体瓦片上时的生成高度：沉底物→水底，漂浮物→水面；非液体瓦片→undefined（默认地面高度） */
export function waterItemZ(m: GameMap, tx: number, ty: number, type: string): number | undefined {
  if (tx < 0 || ty < 0 || tx >= m.w || ty >= m.h) return undefined
  const canal=l11MapWater(m,tx+.5,ty+.5);if(canal)return canal.bridge?undefined:WATER_SINK.has(type)?canal.bottom:canal.surface
  return waterItemZForTile(m.liquid[ty * m.w + tx], m.elev[ty * m.w + tx], type, m.seaFloor?.[ty * m.w + tx] ?? POOL_DEPTH)
}
// 统一楼层带：地下 / 地表 / 二层 / 三层。
export const bandOfZ = (z: number): FloorBand => z < UNDER_MID ? -1 : (z >= FLOOR_H + BAND_MID ? 2 : z >= BAND_MID ? 1 : 0)
/** v56 七轮：玩家高度带按实际楼层数钳制——单层图跳跃越过 1.5m 时 bandOfZ 会翻到不存在的
 *  「上层带」（groundHeightAt(band=1)=FLOOR_H 把玩家吸到 3.0m 卡到天花板上方）；玩家相关判断
 *  （移动/交互/隔层过滤/击退落点）一律用本函数，实体用 bandOfZ（实体 z 不叠家具不会越带）
 */
export const bandOfPlayerZ = (m: GameMap, z: number,x?:number,y?:number): FloorBand => {
  if(m.inf&&x!==undefined&&y!==undefined){
    const wx=x+m.inf.ox,wy=y+m.inf.oy,data=m.inf.chunks.get(`${Math.floor(wx/32)},${Math.floor(wy/32)}`)?.l11
    if(data){const b=data.buildings.find(b=>inPolygon(wx,wy,b.footprint));if(b)return Math.max(0,Math.min(b.accessible-1,bandOfZ(z-b.base))) as FloorBand
      return z<UNDER_MID&&!l11CanalAt(data,wx,wy)?-1:0
    }
  }
  const band = bandOfZ(z)
  if (band === -1) return m.hasUnderground ? -1 : 0
  return Math.min(band, Math.max(0, (m.floors ?? 1) - 1)) as FloorBand
}
/** v54：楼层带 f（1|2）的楼板/墙体数组（up/up2 的泛化访问——侵入最小，旧读取点语义不变） */
export const upAt = (m: GameMap, f: 1 | 2): Uint8Array => (f === 2 ? m.up2 : m.up)
export const upWallAt = (m: GameMap, f: 1 | 2): Uint8Array => (f === 2 ? m.upWall2 : m.upWall)
/** v54：坡道高度段 [lo,hi] 是否服务楼层带 band（坡道到达/经过该层地面 ±tol 才可在该带行走——
 *  3F 不会踩进 1F→2F 坡道的天井，1F 也不会走上悬空的 2F→3F 坡道段）；
 *  tol：canOccupy 用 STEP_UP（严格，防跌井）；bfs3D/entityWalkH 用 JUMP_REACH（宽松，保旧行为） */
export const stairServesBand = (s2: number, band: FloorBand, tol = STEP_UP): boolean => {
  if (band === -1) return false
  const lo = ((s2 >> 3) & 0x3fff) / 100, hi = ((s2 >> 17) & 0x3fff) / 100
  return lo <= band * FLOOR_H + tol && hi >= band * FLOOR_H - tol
}

// 楼梯编码：dir(1+x 2-x 3+y 4-y) | loCm<<3 | hiCm<<17（厘米整数，支持 0..3m 任意爬升）
export const encStair = (dir: number, loCm: number, hiCm: number) => dir | (loCm << 3) | (hiCm << 17)
const stairLo = (v: number) => ((v >> 3) & 0x3fff) / 100
const stairHi = (v: number) => ((v >> 17) & 0x3fff) / 100

// 瓦片代表高度（台阶/楼梯取中位；连通性/实体规则用）
export function tileH(m: GameMap, tx: number, ty: number): number {
  if (tx < 0 || ty < 0 || tx >= m.w || ty >= m.h) return 0
  const i = ty * m.w + tx
  const s2 = m.stair[i]
  if (s2 & 7) return (stairLo(s2) + stairHi(s2)) / 2
  const st = m.step[i]
  if (st & 7) return (ELEV_H[(st >> 3) & 3] + ELEV_H[(st >> 5) & 3]) / 2
  if (m.organicCave && m.elev[i] === 3) return m.terrain?.[i] ?? 0
  if (m.l10LakeTerrain && m.elev[i] === 3) return m.terrain?.[i] ?? 0
  if (m.liquid[i] === 1) return -(m.seaFloor[i] || POOL_DEPTH)
  if (m.liquid[i] === 2) return ELEV_H[m.elev[i]] - SHALLOW_DEPTH
  return ELEV_H[m.elev[i]] + (m.elev[i] === 3 ? (m.terrain?.[i] ?? 0) : 0)
}

function terrainCorner(m: GameMap, vx: number, vy: number): number {
  if (!m.terrain) return 0
  let sum = 0, n = 0
  for (let y = vy - 1; y <= vy; y++) for (let x = vx - 1; x <= vx; x++) {
    if (x < 0 || y < 0 || x >= m.w || y >= m.h) continue
    sum += m.terrain[y * m.w + x]; n++
  }
  return n ? sum / n : 0
}

function caveVolumeDefFor(m: GameMap): CaveVolumeDef | null {
  if (m.caveVolumeId === undefined || !m.inf) return null
  return infiniteImplFor(m.caveVolumeId).caveVolume ?? null
}

const caveWorldXZ = (m: GameMap, x: number, y: number): [number, number] => [x + (m.inf?.ox ?? 0), y + (m.inf?.oy ?? 0)]

/** 体积洞穴的真实三维场值：正数为空气、负数为岩体。 */
export function caveVolumeFieldAt(m: GameMap, x: number, worldY: number, y: number): number {
  const volume = caveVolumeDefFor(m)
  if (!volume || !m.inf) return Infinity
  const [wx, wz] = caveWorldXZ(m, x, y)
  return volume.field(m.inf.seed, wx, worldY, wz)
}

/** 自然地形连续高度：对共享瓦片角高双线性插值，chunk 接缝与碰撞/渲染完全一致。 */
export function surfaceUndulationAt(m: GameMap, x: number, y: number): number {
  const volume = caveVolumeDefFor(m)
  if (volume && m.inf) {
    const [wx, wz] = caveWorldXZ(m, x, y)
    return volume.ground(m.inf.seed, wx, wz)
  }
  if (!m.terrain) return 0
  const tx = Math.floor(x), ty = Math.floor(y), fx = x - tx, fy = y - ty
  const a = terrainCorner(m, tx, ty), b = terrainCorner(m, tx + 1, ty)
  const c = terrainCorner(m, tx, ty + 1), d = terrainCorner(m, tx + 1, ty + 1)
  return (a + (b - a) * fx) * (1 - fy) + (c + (d - c) * fx) * fy
}

function caveCeilCorner(m: GameMap, vx: number, vy: number): number {
  if (!m.caveCeil) return 3
  let sum = 0, n = 0
  for (let y = vy - 1; y <= vy; y++) for (let x = vx - 1; x <= vx; x++) {
    if (x < 0 || y < 0 || x >= m.w || y >= m.h) continue
    sum += m.caveCeil[y * m.w + x]; n++
  }
  return n ? sum / n : 3
}

/** L8 连续洞顶高度；和地面一样对共享角点插值，渲染与头部碰撞完全一致。 */
export function caveCeilingAt(m: GameMap, x: number, y: number): number {
  const volume = caveVolumeDefFor(m)
  if (volume && m.inf) {
    const [wx, wz] = caveWorldXZ(m, x, y)
    return volume.roof(m.inf.seed, wx, wz)
  }
  if (!m.caveCeil) return 3
  const tx = Math.floor(x), ty = Math.floor(y), fx = x - tx, fy = y - ty
  const a = caveCeilCorner(m, tx, ty), b = caveCeilCorner(m, tx + 1, ty)
  const c = caveCeilCorner(m, tx, ty + 1), d = caveCeilCorner(m, tx + 1, ty + 1)
  return (a + (b - a) * fx) * (1 - fy) + (c + (d - c) * fx) * fy
}

// v57t：L7 室外海床/荒岛连续高度场。
// 每个参与瓦片取 3×3 网格：中心=本瓦片代表高度；边中点=本瓦片与相邻瓦片中心的均值；
// 四角=共享该角的参与瓦片中心均值。相邻瓦片在边/角上取到完全相同的顶点高度，
// 因此 chunk 接缝处几何无缝，瓦片之间由四个小斜面连接，而非垂直台阶。
export function l7SeaTile(m: GameMap, tx: number, ty: number): boolean {
  if (!m.l7SeaTerrain || tx < 0 || ty < 0 || tx >= m.w || ty >= m.h) return false
  const i = ty * m.w + tx
  if (m.tiles[i] !== 1 || m.outdoor[i] !== 1) return false
  if (m.liquid[i] === 1) return true
  return m.liquid[i] === 0 && (m.seaFloor?.[i] ?? POOL_DEPTH) <= 0.01 // 抬升到海面的荒岛
}
/** L7 室外连续地形瓦片代表高度（海床=-seaFloor；荒岛=ELEV_H[elev]）。 */
export function l7SeaTileH(m: GameMap, tx: number, ty: number): number {
  const i = ty * m.w + tx
  return m.liquid[i] === 1 ? -(m.seaFloor?.[i] ?? POOL_DEPTH) : ELEV_H[m.elev[i]]
}
/** L7 室外连续地形任意世界点高度：瓦片内 2×2 分段双线性，中心恰为瓦片代表高度。 */
export function l7SeaHAt(m: GameMap, x: number, y: number): number {
  // 窗口边缘 chunk 的最外侧顶点会落在 x/y = m.w/m.h 上：把采样钳制到最后一个瓦片的
  // 外缘（fx/fy=1），避免用越界瓦片中心参与插值产生 NaN。
  let tx = Math.floor(x), ty = Math.floor(y)
  if (tx < 0) tx = 0; else if (tx >= m.w) tx = m.w - 1
  if (ty < 0) ty = 0; else if (ty >= m.h) ty = m.h - 1
  const fx = Math.max(0, Math.min(1, x - tx)), fy = Math.max(0, Math.min(1, y - ty))
  const gx = fx * 2, gy = fy * 2
  const qx = Math.min(1, Math.floor(gx + 1e-6)), qy = Math.min(1, Math.floor(gy + 1e-6))
  const ux = gx - qx, uy = gy - qy
  const node = (px: number, py: number): number => {
    if (px === 1 && py === 1) return l7SeaTileH(m, tx, ty)
    if (py === 1) {
      const nx = tx + (px === 2 ? 1 : -1)
      return l7SeaTile(m, nx, ty) ? (l7SeaTileH(m, tx, ty) + l7SeaTileH(m, nx, ty)) / 2 : l7SeaTileH(m, tx, ty)
    }
    if (px === 1) {
      const ny = ty + (py === 2 ? 1 : -1)
      return l7SeaTile(m, tx, ny) ? (l7SeaTileH(m, tx, ty) + l7SeaTileH(m, tx, ny)) / 2 : l7SeaTileH(m, tx, ty)
    }
    // 四角：共享该角的四个参与瓦片取均值；角落无邻接时退回本瓦片高度，边缘保持封闭
    const ax = px === 2 ? tx : tx - 1, ay = py === 2 ? ty : ty - 1
    let sum = 0, n = 0
    for (let dy = 0; dy <= 1; dy++) for (let dx = 0; dx <= 1; dx++) {
      if (!l7SeaTile(m, ax + dx, ay + dy)) continue
      sum += l7SeaTileH(m, ax + dx, ay + dy); n++
    }
    return n ? sum / n : l7SeaTileH(m, tx, ty)
  }
  const a = node(qx, qy), b = node(qx + 1, qy), c = node(qx, qy + 1), d = node(qx + 1, qy + 1)
  return (a + (b - a) * ux) * (1 - uy) + (c + (d - c) * ux) * uy
}


// 连续地面高度（世界坐标，坡道 smoothstep 平滑插值；玩家脚底/相机/实体站立用）
// band：楼层高度带（0=主层 1=上层 2=第三层[v54]），上层非楼梯瓦片地面=band×FLOOR_H
export function l11MapSpace(m:GameMap,x:number,y:number,band:number,feet?:number){
  const inf=m.inf;if(!inf)return null;const wx=x+inf.ox,wy=y+inf.oy,data=inf.chunks.get(`${Math.floor(wx/32)},${Math.floor(wy/32)}`)?.l11
  return data?l11SpaceAt(data,wx,wy,band,feet):null
}
/** Exact continuous canal footprint, including the water underneath bridges. */
export function l11MapWater(m:GameMap,x:number,y:number){
  const inf=m.inf;if(!inf)return null;const wx=x+inf.ox,wy=y+inf.oy,data=inf.chunks.get(`${Math.floor(wx/32)},${Math.floor(wy/32)}`)?.l11
  return data?l11CanalAt(data,wx,wy):null
}
function* l11BridgeCollidersAt(m:GameMap,x:number,y:number,r=0){
  const inf=m.inf;if(!inf)return;const wx=x+inf.ox,wy=y+inf.oy
  for(let cy=Math.floor((wy-r)/32);cy<=Math.floor((wy+r)/32);cy++)for(let cx=Math.floor((wx-r)/32);cx<=Math.floor((wx+r)/32);cx++){
    const data=inf.chunks.get(`${cx},${cy}`)?.l11;if(!data)continue
    for(const b of [...l11BridgeDeck(data).colliders,...l11BridgeDeck(data).supports])if(wx+r>=b.x0&&wx-r<=b.x1&&wy+r>=b.y0&&wy-r<=b.y1)yield b
  }
}
export function floorHeight(m: GameMap, x: number, y: number, band: FloorBand = bandOfZ(0),feet?:number): number {
  const city=l11MapSpace(m,x,y,band,feet);if(city)return city.height
  if(band===0&&m.inf?.l0){
    const wx=x+m.inf.ox,wy=y+m.inf.oy,a=m.inf.chunks.get(`${Math.floor(wx/32)},${Math.floor(wy/32)}`)?.l0
    if(a){
      if(a.pits.some(r=>wx>=r.x&&wx<r.x+r.w&&wy>=r.y&&wy<r.y+r.h))return -10
      const puddle=a.puddles.find(r=>wx>=r.x&&wx<r.x+r.w&&wy>=r.y&&wy<r.y+r.h)
      return puddle?-puddle.depth:0
    }
  }
  const tx = Math.floor(x), ty = Math.floor(y)
  if (tx < 0 || ty < 0 || tx >= m.w || ty >= m.h) return 0
  const i = ty * m.w + tx
  if (m.tint[i] === 58 && m.inf) {
    const ramp = l11MetroRamp(x + m.inf.ox, y + m.inf.oy)
    if (ramp !== null) return ramp
  }
  if (band === -1) return UNDER_FLOOR
  const s2 = m.stair[i]
  if (s2 & 7) { // 楼梯：跨层连续坡道（与 band 无关）
    const dir = s2 & 7
    const low = stairLo(s2), high = stairHi(s2)
    const fx = x - tx, fy = y - ty
    const t0 = dir === 1 ? fx : dir === 2 ? 1 - fx : dir === 3 ? fy : 1 - fy
    const t = t0 * t0 * (3 - 2 * t0)
    return low + (high - low) * t
  }
  if (band === 1) return FLOOR_H // 上层：楼板高度（无楼板格由碰撞层拦截）
  if (band === 2) return 2 * FLOOR_H // v54：第三层
  if (m.organicCave && m.elev[i] === 3) return surfaceUndulationAt(m, x, y)
  const st = m.step[i]
  if (st & 7) {
    const dir = st & 7
    const low = ELEV_H[(st >> 3) & 3], high = ELEV_H[(st >> 5) & 3]
    const fx = x - tx, fy = y - ty
    const t0 = dir === 1 ? fx : dir === 2 ? 1 - fx : dir === 3 ? fy : 1 - fy
    const t = t0 * t0 * (3 - 2 * t0)
    return low + (high - low) * t
  }
  if (l7SeaTile(m, tx, ty)) return l7SeaHAt(m, x, y) // v57t：L7 室外海床/荒岛=连续平滑斜面（碰撞与渲染共用）
  if (m.l10LakeTerrain && m.elev[i] === 3) return surfaceUndulationAt(m, x, y)
  if (m.liquid[i] === 1) return -(m.seaFloor[i] || POOL_DEPTH)
  if (m.liquid[i] === 2) return ELEV_H[m.elev[i]] - SHALLOW_DEPTH // 浅水洼：以所在高度档为基准
  if(m.inf?.l0&&m.wet[i]){
    const wx=x+m.inf.ox,wy=y+m.inf.oy,layout=m.inf.chunks.get(`${Math.floor(wx/32)},${Math.floor(wy/32)}`)?.l0
    const puddle=layout?.puddles.find(p=>wx>=p.x&&wx<p.x+p.w&&wy>=p.y&&wy<p.y+p.h)
    if(puddle)return -puddle.depth
  }
  return ELEV_H[m.elev[i]] + (m.elev[i] === 3 ? surfaceUndulationAt(m, x, y) : 0)
}

/** 兼容旧调用；新代码应使用 floorHeight。 */
export const groundHeightAt = floorHeight

/** 指定楼层带的墙/不可达地形判定。越界恒视为墙。 */
const cityTileWalkability=new WeakMap<object,Uint8Array>()
export function wallAt(m: GameMap, tx: number, ty: number, band: FloorBand): boolean {
  if (tx < 0 || ty < 0 || tx >= m.w || ty >= m.h) return true
  const inf=m.inf,wx=tx+(inf?.ox??0),wy=ty+(inf?.oy??0),cx=Math.floor(wx/32),cy=Math.floor(wy/32),city=inf?.chunks.get(`${cx},${cy}`)?.l11
  if(city){
    // Immutable chunk plans make tile-centre navigation queries cacheable;
    // sub-tile player collision still uses the exact polygons above.
    let values=cityTileWalkability.get(city);if(!values){values=new Uint8Array(4096);cityTileWalkability.set(city,values)}
    const k=(band+1)*1024+(wy-cy*32)*32+wx-cx*32
    if(!values[k])values[k]=l11SpaceAt(city,wx+.5,wy+.5,band).walkable?1:2
    return values[k]===2
  }
  const i = ty * m.w + tx

  if (band === -1) return m.dn[i] !== 1 || m.dnWall[i] === 1
  if (band === 0) return m.tiles[i] !== 1
  return upAt(m, band)[i] !== 1 || upWallAt(m, band)[i] === 1
}

/** 指定楼层带是否存在可走地面；结构碰撞由 structBlocksPoint 统一叠加。 */
export function walkableAt(m: GameMap, tx: number, ty: number, band: FloorBand): boolean {
  return !wallAt(m, tx, ty, band)
}

const idx = (m: { w: number }, x: number, y: number) => y * m.w + x

/**
 * 派对客群（Entity 67）：把同批生成的个体聚到领头者 1–2.6 格内（永不落单），
 * 并在附近放 1–2 块「丝绒蛋糕」（陷阱物品）、1–2 张「TIME 4 FUN =)」派对海报（megposter data.party）和一面大红旗（partyflag）。
 * 维基：「派对饰品一般是一面大红旗」「它们使用海报和假造数据库条目引诱流浪者至其死地」。
 */
export function placePartyPack(m: GameMap, pack: { x: number; y: number; targetX: number; targetY: number }[]) {
  if (!pack.length || !m.tiles) return
  const lead = pack[0]
  let a = (Math.floor(lead.x) * 73856093) ^ (Math.floor(lead.y) * 19349663) ^ 0x6767
  const R = () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296 }
  const free = (x: number, y: number) => x > 0 && y > 0 && x < m.w - 1 && y < m.h - 1 && m.tiles[idx(m, x, y)] === 1 && !isSolidStruct(m, x, y) && !(m.stair[idx(m, x, y)] & 7) && m.liquid[idx(m, x, y)] !== 1
  const near = (r0: number, r1: number, ok: (x: number, y: number) => boolean) => {
    for (let t = 0; t < 60; t++) {
      const ang = R() * Math.PI * 2, r = r0 + R() * (r1 - r0)
      const x = Math.floor(lead.x + Math.cos(ang) * r), y = Math.floor(lead.y + Math.sin(ang) * r)
      if (ok(x, y)) return { x, y }
    }
    return null
  }
  for (const e of pack.slice(1)) {
    const q = near(1, 2.6, free)
    if (q) { e.x = q.x + 0.5; e.y = q.y + 0.5; e.targetX = e.x; e.targetY = e.y }
  }
  const nCake = 1 + (R() < 0.5 ? 1 : 0)
  for (let i = 0; i < nCake; i++) {
    const q = near(1.2, 3.2, free)
    if (q) m.items.push({ id: 870000 + Math.floor(R() * 99999), type: 'velvetcake', x: q.x + 0.3 + R() * 0.4, y: q.y + 0.3 + R() * 0.4 })
  }
  const wallHug = (x: number, y: number) => free(x, y) && [[1, 0], [-1, 0], [0, 1], [0, -1]].some(([dx, dy]) => m.tiles[idx(m, x + dx, y + dy)] !== 1)
    && !m.structures.some((s) => s.x === x && s.y === y)
  const nPoster = 1 + (R() < 0.6 ? 1 : 0)
  for (let i = 0; i < nPoster; i++) {
    let q = near(1.5, 7, wallHug) ?? near(4, 12, wallHug)
    for (let t = 0; t < 400 && !q; t++) { const x = 1 + Math.floor(R() * (m.w - 2)), y = 1 + Math.floor(R() * (m.h - 2)); if (wallHug(x, y)) q = { x, y } } // 群边没有墙：贴到本层任意一面墙上，作远处的诱饵
    if (q) m.structures.push({ kind: 'megposter', x: q.x, y: q.y, w: 1, h: 1, solid: false, data: { party: 1, v: Math.floor(R() * 3) } })
  }
  const f = near(2, 4.5, (x, y) => free(x, y) && !m.structures.some((s) => x >= s.x && x < s.x + s.w && y >= s.y && y < s.y + s.h))
  if (f) m.structures.push({ kind: 'partyflag', x: f.x, y: f.y, w: 1, h: 1, solid: false, data: { lean: Math.floor(R() * 4) } })
}

function isSolidStruct(m: GameMap, x: number, y: number): boolean {
  return m.structures.some((s) => s.solid && x >= s.x && x < s.x + s.w && y >= s.y && y < s.y + s.h)
}

// v13：楼层过滤的实心结构判定（碰撞/AI 按所在楼层高度带过滤；lift 跨层不算实心）
export function solidStructAtFloor(m: GameMap, x: number, y: number, floor: FloorBand, ignore?: Structure): boolean {
  for(const s of structsNear(m,x,y)){
    if(s===ignore||!s.solid||!s.l11&&(s.floor??0)!==floor)continue
    const boxes=structColliders(s,m)
    // Preserve the same exact collision predicate; only narrow the candidate
    // set. A nearby room must not scan the tower's roof and every facade bay.
    for(const b of s.l11?l11CollidersNear(boxes as L11SolidCollider[],x,y,0):boxes)
      if(x>=b.x0&&x<=b.x1&&y>=b.y0&&y<=b.y1&&(!b.polygon||inPolygon(x,y,b.polygon))&&(!s.l11||colliderBlocksBody(s.l11.base,b,s.l11.base+floor*3)))return true
  }
  return false
}

// v55c（任务3 性能）：结构碰撞空间索引——仅无限层运行时启用（m.inf 存在：单窗千级结构 × 每帧
// 数十次查询；rev 随窗口平移失效重建）。有限层生成期会反复增删结构（BFS 回填/修正），线性扫描保正确性。
const runtimeStructGridMaps = new WeakSet<GameMap>()
const structGridCache = new WeakMap<GameMap, {
  rev: number; modelRev: number; structures: Structure[]; count: number; grid: Map<number, Structure[]>
}>()

/** Enable once solid layout placement has finished; mutable generation keeps linear scans. */
export function enableRuntimeStructCollisionIndex(m: GameMap): void {
  runtimeStructGridMaps.add(m)
  structGridCache.delete(m)
}

function structGrid(m: GameMap): Map<number, Structure[]> | null {
  if (!m.inf && !runtimeStructGridMaps.has(m)) return null
  const rev = m.inf?.rev ?? 0
  const hit = structGridCache.get(m)
  if (hit && hit.rev === rev && hit.modelRev === modelColliderSpatialRev+l11CollisionRevision
    && hit.structures === m.structures && hit.count === m.structures.length) return hit.grid
  const grid = new Map<number, Structure[]>()
  for (const s of m.structures) {
    if (!s.solid && !(s.kind==='glassdoor'&&s.data?.l4)) continue // open doors must remain indexed when closed later
    const boxes = s.l11||isL11DecorKind(s.kind)?[l11StructureBounds(s)]:structColliders(s, m)
    const x0 = Math.min(...boxes.map((b) => b.x0)), y0 = Math.min(...boxes.map((b) => b.y0))
    const x1 = Math.max(...boxes.map((b) => b.x1)), y1 = Math.max(...boxes.map((b) => b.y1))
    for (let ty = Math.max(0, Math.floor(y0)); ty <= Math.min(m.h - 1, Math.floor(y1 - 1e-6)); ty++)
      for (let tx = Math.max(0, Math.floor(x0)); tx <= Math.min(m.w - 1, Math.floor(x1 - 1e-6)); tx++) {
        const k = ty * m.w + tx
        const arr = grid.get(k)
        if (arr) arr.push(s); else grid.set(k, [s])
      }
  }
  structGridCache.set(m, {
    rev, modelRev: modelColliderSpatialRev+l11CollisionRevision, structures: m.structures, count: m.structures.length, grid,
  })
  return grid
}
const structsNear = (m: GameMap, x: number, y: number): readonly Structure[] => {
  const g = structGrid(m)
  if (!g) return m.structures // 有限层回退全表（生成期正确性）
  const tx = Math.floor(x), ty = Math.floor(y)
  if (tx < 0 || ty < 0 || tx >= m.w || ty >= m.h) return []
  return g.get(ty * m.w + tx) ?? [] // 桶缺失=附近无实心结构
}

/** Bounded local recovery candidates for saves made inside an old cubicle collider. */
export function l4CubicleEscapePoints(m:GameMap,x:number,y:number,z:number,r:number){
  const points:{x:number;y:number}[]=[],seen=new Set<Structure>()
  for(const dx of [-r,r])for(const dy of [-r,r])for(const s of structsNear(m,Math.floor(x+dx),Math.floor(y+dy))){
    if(seen.has(s)||!s.solid||s.kind!=='cubicle'||!s.data?.l4)continue
    seen.add(s)
    for(const b of structColliders(s,m)){
      if(!colliderBlocksBody(0,b,z)||x+r<b.x0||x-r>b.x1||y+r<b.y0||y-r>b.y1)continue
      points.push({x:b.x0-r-.005,y},{x:b.x1+r+.005,y},{x,y:b.y0-r-.005},{x,y:b.y1+r+.005})
    }
  }
  const limit=r*Math.SQRT2+.12,near=points.filter(p=>Math.hypot(p.x-x,p.y-y)<=limit)
  // Two meeting panels need a diagonal correction; a single-axis push still overlaps the other.
  for(const px of near.filter(p=>p.x!==x))for(const py of near.filter(p=>p.y!==y))points.push({x:px.x,y:py.y})
  return points.filter(p=>Math.hypot(p.x-x,p.y-y)<=limit).sort((a,b)=>Math.hypot(a.x-x,a.y-y)-Math.hypot(b.x-x,b.y-y))
}

// ================= v26：精细碰撞体积 =================
// 结构碰撞盒（世界坐标 AABB）。top=碰撞顶面高度；stand=true 时顶面可作为站立平台（接入 z 物理）。
// FULL_BLOCK 表示全高阻挡（不可跳上/翻越）；缺省类型 = 整个 w×h 外接范围全高阻挡（旧行为）。
export interface ColliderBox {
  volume?: L11Solid
  pieces?: L11SolidCollider[]
  polygon?: Polygon
  x0: number; y0: number; x1: number; y1: number
  /** 相对结构所在地面的碰撞上沿。 */
  top: number
  /** 相对结构所在地面的可选碰撞下沿；仅悬挂结构需要。 */
  bottom?: number
  stand: boolean
}
export const FULL_BLOCK = 9e9

/**
 * 渲染模型派生的局部碰撞盒。横轴相对结构中心，竖轴相对结构所在地面；使用
 * WeakMap 避免把运行时数据写进存档，也让无限区块平移时无需逐盒改坐标。
 */
export interface ModelColliderBox {
  x0: number; y0: number; x1: number; y1: number
  bottom: number; top: number; stand: boolean
}
type ModelColliderEntry = {
  local: ModelColliderBox[]
  world: ColliderBox[] | null
  x: number
  y: number
}
const modelColliderCache = new WeakMap<Structure, ModelColliderEntry>()
let modelColliderSpatialRev = 0
const modelFootprint = (boxes: readonly ModelColliderBox[]) => ({
  x0: Math.min(...boxes.map((b) => b.x0)), y0: Math.min(...boxes.map((b) => b.y0)),
  x1: Math.max(...boxes.map((b) => b.x1)), y1: Math.max(...boxes.map((b) => b.y1)),
})

/** 由渲染器在模型创建或姿态变化后登记；无有效网格时删除并回退旧占地。 */
export function setStructModelColliders(s: Structure, boxes: readonly ModelColliderBox[]): void {
  const clean = boxes.filter((b) => Number.isFinite(b.x0 + b.y0 + b.x1 + b.y1 + b.bottom + b.top)
    && b.x1 > b.x0 && b.y1 > b.y0 && b.top > b.bottom)
  const old = modelColliderCache.get(s)
  if (!clean.length) {
    if (old) { modelColliderCache.delete(s); modelColliderSpatialRev++ }
    return
  }
  const prev = old?.local.length ? modelFootprint(old.local) : null
  const next = modelFootprint(clean)
  modelColliderCache.set(s, {
    local: clean.map((b) => ({ ...b })), world: null, x: Number.NaN, y: Number.NaN,
  })
  if (!prev || Math.abs(prev.x0 - next.x0) > .015 || Math.abs(prev.y0 - next.y0) > .015
    || Math.abs(prev.x1 - next.x1) > .015 || Math.abs(prev.y1 - next.y1) > .015) modelColliderSpatialRev++
}

const modelCollidersFor = (s: Structure): ColliderBox[] | null => {
  const entry = modelColliderCache.get(s)
  if (!entry?.local.length) return null
  if (entry.world && entry.x === s.x && entry.y === s.y) return entry.world
  const cx = s.x + s.w / 2, cy = s.y + s.h / 2
  entry.world = entry.local.map((b) => ({
    x0: cx + b.x0, y0: cy + b.y0, x1: cx + b.x1, y1: cy + b.y1,
    ...(b.bottom > .08 ? { bottom: b.bottom } : {}), top: b.top, stand: b.stand,
  }))
  entry.x = s.x
  entry.y = s.y
  return entry.world
}

// 按类型定义精确碰撞（与 renderer/structures.ts 的低模外观尺寸逐一核对）：
// - table 桌：顶板 s.w*0.85 × s.h*0.8 @0.75m → 桌面可跳上；chair 椅：座面 0.42×0.42 @0.45m
// - bed 床：垫面 s.w*0.95 × s.h*0.95 @≈0.47m → 0.5m 可跳上
// - frontdesk 前台：视觉仅 s.w×0.7m 台面（原 w×h=4×2 外接方块 → 空气墙）→ 真实轮廓全高阻挡
// - ladder 装饰梯：双立柱+横档仅 0.56×0.14m 薄片（原 1×2 整瓦阻挡 → 空气墙）→ 细柱不挡路
// - desk 书桌：顶板 s.w*0.9×0.7 @0.77m；crate 木箱：0.84×0.84 @0.70m
// - boiler 锅炉：圆柱罐体底 r1.4/顶 r1.3 @2.6m（structures.ts case 'boiler'）→ 盒 ±1.2 贴合罐体
//   （钳制不超出自身 footprint，1×1 据点锅炉不外扩）；罐顶 2.6m 不可站
// - sphboiler 球罐：砖石基座 1.7×1.7 + 球罐 r0.85 @顶 ~2.2m → 盒 ±0.85；球顶不可站
export function structColliders(s: Structure, m?: GameMap): ColliderBox[] {
  if(s.kind==='l11subway')return l11MetroColliders(s)
  if(isL11DecorKind(s.kind))return l11PropColliders(s)
  if(s.data?.l1Static){
    const height={bottom:Number(s.data.bottom),top:Number(s.data.top),stand:false}
    if(!s.data.l1Round)return [{x0:s.x,y0:s.y,x1:s.x+s.w,y1:s.y+s.h,...height}]
    // Tight circumscribed strips retain the existing AABB broad phase without
    // the square corners of a cylindrical column becoming invisible blockers.
    return Array.from({length:16},(_,i)=>{const lo=-1+i/8,hi=lo+.125,nearest=lo>0?lo:hi<0?hi:0,r=Math.sqrt(1-nearest*nearest)*s.h/2;return{x0:s.x+i*s.w/16,x1:s.x+(i+1)*s.w/16,y0:s.y+s.h/2-r,y1:s.y+s.h/2+r,...height}})
  }
  if(s.data?.l0Door){const vertical=Number(s.data.deg)%180!==0,x=s.x+s.w/2,y=s.y+s.h/2;return[{x0:x-(vertical?.04:.44),y0:y-(vertical?.44:.04),x1:x+(vertical?.04:.44),y1:y+(vertical?.44:.04),bottom:0,top:2.13,stand:false}]}
  if(s.data?.l0Wall)return [{x0:s.x,y0:s.y,x1:s.x+s.w,y1:s.y+s.h,bottom:Number(s.data.bottom),top:Number(s.data.top),stand:false}]
  const settlement = settlementColliders(s)
  if (settlement) return settlement
  const cx = s.x + s.w / 2, cy = s.y + s.h / 2
  if(s.l11)return l11BuildingColliders(s)
  if (s.kind === 'l11window') return [{ x0:s.data?.axis?cx-.05:s.x,y0:s.data?.axis?s.y:cy-.05,x1:s.data?.axis?cx+.05:s.x+s.w,y1:s.data?.axis?s.y+s.h:cy+.05,top:3,stand:false }]
  if (s.kind === 'l11prop' && s.data?.prop === 'tree') return [{ x0:cx-.2,y0:cy-.2,x1:cx+.2,y1:cy+.2,top:3.5,stand:false }]
  if (s.kind === 'angelstatue') return l3AngelCollision(s)
  // 运行时模型一旦完成构建，所有可见实心结构统一以真实子网格包围盒为准。
  // 下方逐类型定义只负责无渲染器的地图生成阶段，以及纯逻辑/隐形碰撞结构的回退。
  const l4Analytic=!!s.data?.l4&&['cubicle','l4stairs','glasswin','windowblack','windowtrap','pillar','hoteldoor','glassdoor'].includes(s.kind)
  const modeled = l4Analytic?null:modelCollidersFor(s)
  if (modeled) return modeled
  if(isL5DecorKind(s.kind)){
    const d=L5_DECOR_DEFS.find(d=>d.id===s.kind)!
    return d.solid?structColliders({...s,kind:d.kind,data:{...d.data,...s.data}},m):[]
  }
  switch (s.kind) {
    case 'pillar':
      return s.data?.l4?[{x0:cx-.25,y0:cy-.25,x1:cx+.25,y1:cy+.25,top:FULL_BLOCK,stand:false}]:[{x0:s.x,y0:s.y,x1:s.x+s.w,y1:s.y+s.h,top:FULL_BLOCK,stand:false}]
    case 'stalagspike': {
      // L8 钟乳石/石笋：碰撞体随模型缩放，并对洞顶钟乳石使用悬挂高度带。
      // 半径略小于可见簇，既能阻挡穿模，也允许玩家从零碎尖刺之间擦身通过。
      const requested = Math.max(0.4, Number(s.data?.scale ?? 1))
      let scale = requested
      let span = 4.2
      if (m) {
        const base = floorHeight(m, cx, cy, 0)
        span = Math.max(1.1, caveCeilingAt(m, cx, cy) - base)
        scale = Math.min(requested, Math.max(0.5, (span - 0.35) / 2.35))
      }
      const radius = Math.min(0.37, 0.22 + scale * 0.075)
      const reach = Math.min(span - 0.12, 2.04 * scale)
      if (s.data?.ceiling === 1) {
        return [{ x0: cx - radius, y0: cy - radius, x1: cx + radius, y1: cy + radius, bottom: Math.max(0, span - reach), top: span, stand: false }]
      }
      return [{ x0: cx - radius, y0: cy - radius, x1: cx + radius, y1: cy + radius, top: reach, stand: false }]
    }
    case 'caveboulder': {
      // 突兀岩块不再占满整格；碰撞近似模型主体，周边碎石保留可跨越空间。
      const scale = Math.max(0.45, Number(s.data?.scale ?? 1))
      const radius = Math.min(0.46, 0.29 + scale * 0.08)
      return [{ x0: cx - radius, y0: cy - radius, x1: cx + radius, y1: cy + radius, top: Math.max(0.58, scale * 0.94), stand: false }]
    }
    case 'cubicle': {
      if(!s.data?.l4)return[{x0:s.x,y0:s.y,x1:s.x+s.w,y1:s.y+s.h,top:FULL_BLOCK,stand:false}]
      const left=Number(s.data.deg)===270,bx=left?s.x+.025:s.x+s.w-.1
      return[
        {x0:bx,y0:s.y,x1:bx+.075,y1:s.y+s.h,bottom:0,top:1.37,stand:true},
        {x0:s.x,y0:s.y,x1:s.x+s.w,y1:s.y+.08,bottom:0,top:1.37,stand:true},
        {x0:s.x,y0:s.y+s.h-.08,x1:s.x+s.w,y1:s.y+s.h,bottom:0,top:1.37,stand:true},
        {x0:left?s.x:s.x+s.w-.9,y0:s.y+.12,x1:left?s.x+.9:s.x+s.w,y1:s.y+s.h-.12,bottom:0,top:.78,stand:true},
      ]
    }
    case 'table':
      if (s.data?.chair) return [{ x0: cx - 0.23, y0: cy - 0.23, x1: cx + 0.23, y1: cy + 0.23, top: 0.47, stand: true }]
      return [{ x0: cx - s.w * 0.425, y0: cy - s.h * 0.4, x1: cx + s.w * 0.425, y1: cy + s.h * 0.4, top: 0.75, stand: true }]
    case 'bed':
      return [{ x0: cx - s.w * 0.475, y0: cy - s.h * 0.475, x1: cx + s.w * 0.475, y1: cy + s.h * 0.475, top: 0.5, stand: true }]
    case 'frontdesk':
      return [{ x0: s.x + 0.02, y0: cy - 0.36, x1: s.x + s.w - 0.02, y1: cy + 0.36, top: FULL_BLOCK, stand: false }]
    case 'ladder':
      return [{ x0: cx - 0.28, y0: cy - 0.07, x1: cx + 0.28, y1: cy + 0.07, top: FULL_BLOCK, stand: false }]
    case 'desk':
      return [{ x0: cx - s.w * 0.45, y0: cy - 0.35, x1: cx + s.w * 0.45, y1: cy + 0.35, top: 0.77, stand: true }]
    case 'crate':
      if(s.data?.l1Crate)return[{x0:s.x,y0:s.y,x1:s.x+s.w,y1:s.y+s.h,top:Number(s.data.l1Stack)===2?1.36:.68,stand:true}]
      return [{ x0: cx - 0.42, y0: cy - 0.42, x1: cx + 0.42, y1: cy + 0.42, top: 0.7, stand: true }]
    case 'l10haybale': {
      // 渲染器尚未建立模型碰撞时的确定性回退。按实际摆放角度求旋转长方体的平面 AABB；
      // 加载完成后会自动切换为 RoundedBoxGeometry 的模型包围盒。
      const a = Number(s.data?.deg ?? 0) * Math.PI / 180
      const ca = Math.abs(Math.cos(a)), sa = Math.abs(Math.sin(a))
      const ex = ca * s.w * .5 + sa * s.h * .5
      const ey = sa * s.w * .5 + ca * s.h * .5
      return [{
        x0: cx - ex, y0: cy - ey, x1: cx + ex, y1: cy + ey,
        top: Math.max(.42, Number(s.data?.height ?? .64)) - .025, stand: true,
      }]
    }
    case 'barrel':
      // v57t：木桶按真实圆柱半径/高度给碰撞——深海底的桶只占据海床以上 0.9m，不再把整条水柱堵死
      return [{ x0: cx - 0.34, y0: cy - 0.34, x1: cx + 0.34, y1: cy + 0.34, top: 0.9, stand: false }]
    case 'arch': {
      // 拱廊只由薄墙、两侧窄立柱与低窗台占据；旧版整块 3×1 碰撞会堵死整个拱洞。
      const halfD = 0.14, pier = 0.22
      return [
        { x0: s.x, y0: cy - halfD, x1: s.x + s.w, y1: cy + halfD, top: 0.86, stand: true },
        { x0: s.x, y0: cy - halfD, x1: s.x + pier, y1: cy + halfD, top: FULL_BLOCK, stand: false },
        { x0: s.x + s.w - pier, y0: cy - halfD, x1: s.x + s.w, y1: cy + halfD, top: FULL_BLOCK, stand: false },
      ]
    }
    case 'boiler': {
      // v54：圆柱罐体（底 r1.4/顶 r1.3，高 2.6；玩家身高处 r≈1.36）→ 盒半宽 1.2 贴合罐体，
      // 钳制不超出自身 footprint（1×1 据点锅炉不外扩）；罐顶 2.6m 不可站
      const r = Math.min(1.2, s.w / 2, s.h / 2)
      return [{ x0: cx - r, y0: cy - r, x1: cx + r, y1: cy + r, top: 2.6, stand: false }]
    }
    case 'sphboiler':
      // v54：砖石基座 1.7×1.7 + 球罐 r0.85（顶 ~2.2m）→ 盒 ±0.85（钳制于 footprint）；球顶不可站
      return [{ x0: cx - Math.min(0.85, s.w / 2), y0: cy - Math.min(0.85, s.h / 2), x1: cx + Math.min(0.85, s.w / 2), y1: cy + Math.min(0.85, s.h / 2), top: 2.2, stand: false }]
    // v51：容器柜类精确碰撞（模型比整瓦小；flushToWall 贴墙位移——碰撞盒同向贴墙，消除空气墙）。
    // 尺寸逐一核对 structures.ts 模型；贴墙方向镜像渲染层 wallDirs（NB4 序第一面非地板邻墙），
    // 位移量 = 0.5 − 深/2 − 0.02（同 flushToWall）；贴东西墙时模型旋 90°，碰撞盒宽高互换；
    // data.deg/data.row 显式朝向（渲染层不位移）：仅按朝向换轴、居中；megcrate 无贴墙位移。
    case 'cabinet': case 'locker': case 'dresser': case 'safebox':
    case 'toolbox': case 'megcrate': case 'binshelf': case 'libshelf': case 'vending':
    case 'sofa': case 'servercase': case 'phonograph': { // v54：双人沙发/塔式服务器机箱（同柜类贴墙碰撞约定）；v55：留声机同（修复模型 flushToWall 贴墙而碰撞盒居中的错位）
      if (s.kind === 'dresser' && s.data?.manilaTable) {
        return [{ x0: cx - 0.84, y0: cy - 0.84, x1: cx + 0.84, y1: cy + 0.84, top: 0.88, stand: true }]
      }
      const dims: Record<string, [number, number]> = { // [宽(模型局部 X)，深]
        cabinet: [0.85, 0.5], locker: [0.64, 0.46], dresser: [0.85, 0.5], safebox: [0.72, 0.66],
        toolbox: [0.58, 0.3], megcrate: [0.85, 0.85], binshelf: [s.w, 0.42], libshelf: [1.0, 0.58],
        vending: [0.95, 0.7], // v54：自动售货机精确碰撞（消除整瓦片空气墙；贴墙位移同渲染层 flushToWall）
        sofa: [1.56, 0.78], servercase: [0.55, 0.6], // v54
        phonograph: [0.64, 0.54], // v55：留声机（柜座+喇叭外缘）
      }
      const [bw, bd] = dims[s.kind]
      let ox = cx, oy = cy, swap = false
      const deg = s.data?.deg !== undefined ? (((Number(s.data.deg) || 0) % 360) + 360) % 360 : -1
      if (deg >= 0 || s.data?.row) swap = deg === 90 || deg === 270
      else if (m && s.kind !== 'megcrate') {
        const tx = Math.floor(s.x + s.w / 2), ty = Math.floor(s.y + s.h / 2)
        const NB: [number, number][] = [[0, -1], [1, 0], [0, 1], [-1, 0]]
        for (const [dx, dy] of NB) {
          const nx = tx + dx, ny = ty + dy
          if (nx < 0 || ny < 0 || nx >= m.w || ny >= m.h) continue
          if (m.tiles[ny * m.w + nx] !== 1) {
            const off = 0.5 - bd / 2 - 0.02
            ox = cx + dx * off; oy = cy + dy * off
            swap = dx !== 0
            break
          }
        }
      }
      const hw = (swap ? bd : bw) / 2, hd = (swap ? bw : bd) / 2
      return [{ x0: ox - hw, y0: oy - hd, x1: ox + hw, y1: oy + hd, top: FULL_BLOCK, stand: false }]
    }
    case 'handrail': {
      // v46 扶手实心化：细条碰撞盒贴模型横杆一侧（deg 0=+z 90=+x 180=-z 270=-x；全高阻挡不可跨越）
      const deg = (((Number(s.data?.deg) || 0) % 360) + 360) % 360
      const T = 0.09 // 碰撞条半厚
      if (deg === 90) return [{ x0: s.x + s.w - 0.08 - T, y0: s.y, x1: s.x + s.w - 0.08 + T, y1: s.y + s.h, top: FULL_BLOCK, stand: false }]
      if (deg === 270) return [{ x0: s.x + 0.08 - T, y0: s.y, x1: s.x + 0.08 + T, y1: s.y + s.h, top: FULL_BLOCK, stand: false }]
      if (deg === 180) return [{ x0: s.x, y0: s.y + 0.08 - T, x1: s.x + s.w, y1: s.y + 0.08 + T, top: FULL_BLOCK, stand: false }]
      return [{ x0: s.x, y0: s.y + s.h - 0.08 - T, x1: s.x + s.w, y1: s.y + s.h - 0.08 + T, top: FULL_BLOCK, stand: false }]
    }
    case 'redpillar': // v55：红木纹方柱（L5 主厅）——柱身 0.62 见方 + 金柱头/础，全高阻挡（钳制不超出 1×1 占地）
      return [{ x0: cx - 0.43, y0: cy - 0.43, x1: cx + 0.43, y1: cy + 0.43, top: FULL_BLOCK, stand: false }]
    case 'pipes': {
      // v55c（任务5）：管道精确碰撞——消除整瓦空气墙，低管道/贴墙管群让出通行：
      if (s.data?.run) {
        // 贴墙平行粗管群（L2 廊道：净宽 3→2 既定观感不变）：管心贴 hug 侧墙 0.25~0.46——碰撞条贴墙侧 0.28 深
        const hug = Number(s.data.side ?? 0) === 1 ? 1 : -1
        return [{ x0: hug > 0 ? s.x + 0.72 : s.x, y0: s.y, x1: hug > 0 ? s.x + 1 : s.x + 0.28, y1: s.y + 1, top: FULL_BLOCK, stand: false }]
      }
      if (s.data?.cross) {
        // 横穿廊道的大小管道（L2 扭曲段，crawl 蹲伏通道）：按模型管径高度分盒——大管顶 1.18 / 小管顶 0.71
        // （低于头顶的悬空管段不再整瓦阻挡；蹲行可从管侧/管下通过）
        return [
          { x0: s.x, y0: s.y + 0.14, x1: s.x + s.w, y1: s.y + 0.46, top: 1.18, stand: false },
          { x0: s.x, y0: s.y + 0.59, x1: s.x + s.w, y1: s.y + 0.77, top: 0.71, stand: false },
        ]
      }
      // 代墙管排（data.wall）与其余：管排即墙——维持整格全高阻挡
      return [{ x0: s.x, y0: s.y, x1: s.x + s.w, y1: s.y + s.h, top: FULL_BLOCK, stand: false }]
    }
    case 'oddtable': // v55：异形小桌（L5 贝弗莉室）——歪腿大桌面 1.3×1.05 @0.69m 可站上
      return [{ x0: cx - 0.6, y0: cy - 0.48, x1: cx + 0.6, y1: cy + 0.48, top: 0.69, stand: true }]
    case 'furnace': // v55：熔炉（L5 锅炉房）——砖砌炉体 0.9×0.8 全高阻挡（烟道贴顶）
      return [{ x0: cx - 0.45, y0: cy - 0.4, x1: cx + 0.45, y1: cy + 0.4, top: FULL_BLOCK, stand: false }]
    case 'treadmill': // v55：跑步机（L5 健身房）——跑带台 0.62×1.5 @0.25m 可站上
      return [{ x0: cx - 0.31, y0: cy - 0.75, x1: cx + 0.31, y1: cy + 0.75, top: 0.25, stand: true }]
    case 'dumbbellrack': // v55：哑铃架（L5 健身房）——双层架 1.2×0.3 @0.8m 不可站
      return [{ x0: cx - 0.6, y0: cy - 0.15, x1: cx + 0.6, y1: cy + 0.15, top: 0.8, stand: false }]
    case 'spinbike': // v55：动感单车（L5 健身房）——车架 0.4×0.9 @0.5m 可站上
      return [{ x0: cx - 0.2, y0: cy - 0.45, x1: cx + 0.2, y1: cy + 0.45, top: 0.5, stand: true }]
    case 'divingboard': // v54：跳台（L5 泳池）——短柱 + 悬挑跳板：板面 0.5×1.0 @0.85m 可站上
      return [{ x0: cx - 0.25, y0: cy - 0.5, x1: cx + 0.25, y1: cy + 0.5, top: 0.85, stand: true }]
    case 'gymbench': // v54：健身卧推凳（L5 健身房）——凳面 0.45×1.1 @0.45m 可站上（杠铃架细柱不另计）
      return [{ x0: cx - 0.23, y0: cy - 0.55, x1: cx + 0.23, y1: cy + 0.55, top: 0.45, stand: true }]
    case 'stairrail': {
      // v54：oldstairs 井口护栏碰撞（仅碰撞无模型；可见护栏在出口模型）——沿走向两侧细条 + 尽头横栏（data.end）
      // data.deg=出口朝向（同 orientStairs 的 rotation.y 角度制：90=墙在 +x/走向 -x；270=墙 -x；0=墙 +y；180=墙 -y）
      const deg = (((Number(s.data?.deg) || 0) % 360) + 360) % 360
      const T = 0.06 // 半厚
      const out: ColliderBox[] = []
      if (deg === 0 || deg === 180) { // 走向沿 y：两侧栏杆在 x=cx±0.55
        out.push({ x0: cx + 0.55 - T, y0: s.y, x1: cx + 0.55 + T, y1: s.y + 1, top: FULL_BLOCK, stand: false })
        out.push({ x0: cx - 0.55 - T, y0: s.y, x1: cx - 0.55 + T, y1: s.y + 1, top: FULL_BLOCK, stand: false })
        if (s.data?.end) { // 尽头横栏：deg 0=走向 -y（北缘）；deg 180=走向 +y（南缘）
          const ey = deg === 0 ? s.y : s.y + 1
          out.push({ x0: s.x, y0: ey - T, x1: s.x + 1, y1: ey + T, top: FULL_BLOCK, stand: false })
        }
      } else { // 走向沿 x：两侧栏杆在 y=cy±0.55
        out.push({ x0: s.x, y0: cy + 0.55 - T, x1: s.x + 1, y1: cy + 0.55 + T, top: FULL_BLOCK, stand: false })
        out.push({ x0: s.x, y0: cy - 0.55 - T, x1: s.x + 1, y1: cy - 0.55 + T, top: FULL_BLOCK, stand: false })
        if (s.data?.end) { // 尽头横栏：deg 90=走向 -x（西缘）；deg 270=走向 +x（东缘）
          const ex = deg === 90 ? s.x : s.x + 1
          out.push({ x0: ex - T, y0: s.y, x1: ex + T, y1: s.y + 1, top: FULL_BLOCK, stand: false })
        }
      }
      return out
    }
    case 'glassdoor': {
      if (!s.data?.l4) return [{x0:s.x,y0:s.y,x1:s.x+s.w,y1:s.y+s.h,top:FULL_BLOCK,stand:false}]
      // The closed leaf is a thin plane through the frame, not a one-metre cube.
      const spans=s.solid?[[0,s.w]]:[[0,.06],[s.w-.06,s.w]]
      return spans.map(([a,b])=>s.data!.axis==='y'
        ? {x0:cx-.08,y0:s.y+a,x1:cx+.08,y1:s.y+b,top:FULL_BLOCK,stand:false}
        : {x0:s.x+a,y0:cy-.08,x1:s.x+b,y1:cy+.08,top:FULL_BLOCK,stand:false})
    }
    case 'l4stairs':
      return [s.x+.02,s.x+1.96,s.x+3.90].map(x=>({x0:x,y0:s.y+.65,x1:x+.08,y1:s.y+s.h,top:FULL_BLOCK,stand:false}))
    case 'windowblack': case 'windowtrap': case 'glasswin': {
      if(s.data?.partition)return[{x0:s.x,y0:s.y+.45,x1:s.x+s.w,y1:s.y+.55,top:FULL_BLOCK,stand:false}]
      // v54b：L4 雨窗（data.deg 定向变体）精确碰撞——窗体是贴瓦片外缘的薄墙板（框深 0.22 + 玻璃全高不可穿），
      // 碰撞条贴同侧瓦片缘（消除整瓦空气墙）；无 deg 变体（L274 彩窗等贴墙件）保持整瓦默认
      if (s.data?.deg === undefined) return [{ x0: s.x, y0: s.y, x1: s.x + s.w, y1: s.y + s.h, top: FULL_BLOCK, stand: false }] // 非定向变体：整瓦默认
      const deg = (((Number(s.data.deg) || 0) % 360) + 360) % 360
      const T = 0.26 // 碰撞条厚（覆盖框 0.28..0.50 并略内收）
      if (deg === 0) return [{ x0: s.x, y0: s.y + s.h - T, x1: s.x + s.w, y1: s.y + s.h, top: FULL_BLOCK, stand: false }]
      if (deg === 180) return [{ x0: s.x, y0: s.y, x1: s.x + s.w, y1: s.y + T, top: FULL_BLOCK, stand: false }]
      if (deg === 90) return [{ x0: s.x + s.w - T, y0: s.y, x1: s.x + s.w, y1: s.y + s.h, top: FULL_BLOCK, stand: false }]
      return [{ x0: s.x, y0: s.y, x1: s.x + T, y1: s.y + s.h, top: FULL_BLOCK, stand: false }]
    }
    case 'tvset': {
      // v54：立式大电视——机身 1.06×0.5（含底座），deg 90/270 换轴
      const deg = (((Number(s.data?.deg) || 0) % 360) + 360) % 360
      const hw = 0.53, hd = 0.25
      const swap = deg === 90 || deg === 270
      return [{ x0: cx - (swap ? hd : hw), y0: cy - (swap ? hw : hd), x1: cx + (swap ? hd : hw), y1: cy + (swap ? hw : hd), top: FULL_BLOCK, stand: false }]
    }
    case 'settlementprop':
      return [{x0:s.x,y0:s.y,x1:s.x+s.w,y1:s.y+s.h,bottom:Number(s.data?.bottom??0),top:Number(s.data?.height??1),stand:!s.data?.partition}]
    case 'seadais': // v58：环形石台——0.42m 低台可踏上（stand），台面嵌木门出口
      return [{ x0: s.x + 0.12, y0: s.y + 0.12, x1: s.x + s.w - 0.12, y1: s.y + s.h - 0.12, top: 0.42, stand: true }]
    case 'seapipe': { // v58：水下管道——管身抬空，低矮碰撞条（不挡上方水层）
      const deg = (((Number(s.data?.deg) || 0) % 360) + 360) % 360
      const hw = 1.0, hd = 0.34
      const swap = deg === 90 || deg === 270
      return [{ x0: cx - (swap ? hd : hw), y0: cy - (swap ? hw : hd), x1: cx + (swap ? hd : hw), y1: cy + (swap ? hw : hd), top: 0.85, stand: false }]
    }
    case 'seapillar': // v58：水下石柱——居中 0.62 见方全高阻挡
      return [{ x0: cx - 0.31, y0: cy - 0.31, x1: cx + 0.31, y1: cy + 0.31, top: FULL_BLOCK, stand: false }]
    default:
      return [{ x0: s.x, y0: s.y, x1: s.x + s.w, y1: s.y + s.h, top: FULL_BLOCK, stand: false }]
  }
}

/** 碰撞盒在脚底高度 z 处是否会阻挡直立角色；与点/圆检测共用同一套高度规则。 */
const colliderBlocksBody = (base: number, b: ColliderBox, z: number): boolean => {
  if (b.bottom !== undefined) {
    const playerTop = z + 1.48
    // 已站到可站立顶面后，不能让同一个盒把角色判定在自身内部。
    if (b.stand && z >= base + b.top - .06) return false
    // Touching a top plane is not body penetration (notably L0 well walls
    // whose top is exactly the walkable floor). Keep below-floor sides solid.
    return playerTop > base + b.bottom + .0001 && z < base + b.top - .0001
  }
  // 接地低物件可直接踏上；超过台阶高度的部分才横向阻挡。
  return base + b.top - z > STEP_UP
}

// 世界点 (x,y) 在脚底高度 z 处是否被实心结构碰撞盒阻挡（精细亚瓦片判定）
const citySolid=(s:Structure)=>!!s.l11||isL11DecorKind(s.kind)||s.kind==='l11subway'
const colliderBase=(s:Structure,m:GameMap,band:FloorBand)=>s.kind==='l11subway'?0:s.l11?.base??(floorHeight(m,s.x+s.w/2,s.y+s.h/2,isL11DecorKind(s.kind)?s.floor??0:band)+Number(s.data?.mount??0))
const collidersAt=(s:Structure,m:GameMap,x:number,y:number,r=0):Iterable<ColliderBox>=>s.l11?l11CollidersNear(l11BuildingColliders(s),x,y,r):structColliders(s,m)
export function structBlocksPoint(m: GameMap, x: number, y: number, z: number, band: FloorBand, ignoreStructure?: Structure): boolean {
  for(const b of l11BridgeCollidersAt(m,x,y))if(l11SolidHits(b,x+m.inf!.ox,y+m.inf!.oy,0,z,z+1.48))return true
  const arr = structsNear(m, Math.floor(x), Math.floor(y)) // v55c：无限层瓦片桶；有限层全表
  for (const s of arr) {
    if (s === ignoreStructure) continue
    if ((!s.solid && !(s.kind==='glassdoor'&&s.data?.l4)) || (!citySolid(s) && (s.floor ?? 0) !== band)) continue
    const base = colliderBase(s,m,band)
    for (const b of collidersAt(s,m,x,y)) {
      if (x < b.x0 || x > b.x1 || y < b.y0 || y > b.y1 || b.polygon&&!inPolygon(x,y,b.polygon)) continue
      if (b.volume?l11SolidHits(b as L11SolidCollider,x,y,0,z-base,z-base+1.48):colliderBlocksBody(base,b,z))return true
    }
  }
  return false
}

/**
 * 圆形角色碰撞体与结构模型盒的精确二维相交检测。旧的 8 点圆周采样会在路灯杆、
 * 栏杆柱等细模型完全落入角色圆内部时漏检；圆心到 AABB 最近点检测不会产生该盲区。
 */
export function structBlocksCircle(m: GameMap, x: number, y: number, radius: number, z: number, band: FloorBand,bodyHeight=1.48,flightWallH?:number,ignoreStructure?:Structure): boolean {
  const r = Math.max(0, radius)
  const flying = flightWallH !== undefined
  for(const b of l11BridgeCollidersAt(m,x,y,r))if(l11SolidHits(b,x+m.inf!.ox,y+m.inf!.oy,r,z,z+bodyHeight)&&(flying||l11SolidSurface(b,x+m.inf!.ox,y+m.inf!.oy,r)>z+.22))return true
  const hits = (s: Structure): boolean => {
    if (s === ignoreStructure) return false
    if ((!s.solid && !(s.kind==='glassdoor'&&s.data?.l4)) || (!flying && !citySolid(s) && (s.floor ?? 0) !== band)) return false
    const base = colliderBase(s,m,flying ? s.floor ?? 0 : band)
    for (const b of collidersAt(s,m,x,y,r)) {
      const qx = Math.max(b.x0, Math.min(b.x1, x))
      const qy = Math.max(b.y0, Math.min(b.y1, y))
      const dx = x - qx, dy = y - qy
      if (dx * dx + dy * dy > r * r + 1e-9 || b.polygon&&!circlePolygon(x,y,r,b.polygon)) continue
      if(b.volume){
        if(z-base>=b.top-.025)continue
        if(!l11SolidHits(b as L11SolidCollider,x,y,r,z-base,z-base+bodyHeight))continue
        // Visible stair risers/kerbs can be stepped onto; taller furniture
        // requires a jump. Do not extrude a high horizontal bar to the floor.
        if(!flying&&l11SolidSurface(b as L11SolidCollider,x,y,r)<=z-base+.22)continue
        return true
      }
      if (flying) {
        // Free flight uses the actual vertical volume, without ground-step allowances.
        const ceiling = ceilingHeightAt(m,x,y,flightWallH!,s.floor??0)
        const top = b.top >= FULL_BLOCK ? (Number.isFinite(ceiling) ? ceiling : base + flightWallH!) : base + b.top
        if (z + bodyHeight > base + (b.bottom ?? 0) + .0001 && z < top - .0001) return true
        continue
      }
      if (colliderBlocksBody(base, b, z)) return true
    }
    return false
  }
  const g = structGrid(m)
  if (!g) return m.structures.some(hits)
  const minX = Math.max(0, Math.floor(x - r)), minY = Math.max(0, Math.floor(y - r))
  const maxX = Math.min(m.w - 1, Math.floor(x + r)), maxY = Math.min(m.h - 1, Math.floor(y + r))
  // 玩家半径只覆盖至多四个桶；允许同一结构被重复检查，比每个物理子步创建 Set 更省 GC。
  for (let ty = minY; ty <= maxY; ty++) for (let tx = minX; tx <= maxX; tx++) {
    const bucket = g.get(ty * m.w + tx)
    if (bucket?.some(hits)) return true
  }
  return false
}

/** 三维视线是否被指定楼层带的精细结构碰撞盒截断；target 可忽略目标自身，避免柜体遮住自己的交互面。 */
export function structBlocksSight(m: GameMap, x: number, y: number, z: number, band: FloorBand, target?: Structure): boolean {
  for(const b of l11BridgeCollidersAt(m,x,y))if(l11SolidHits(b,x+m.inf!.ox,y+m.inf!.oy,.0001,z-.001,z+.001))return true
  const arr = structsNear(m, Math.floor(x), Math.floor(y))
  for (const s of arr) {
    if (s === target || !s.solid || s.data?.noSight === 1 || (!citySolid(s) && (s.floor ?? 0) !== band)) continue // v58：noSight=仅碰撞结构（电梯门挡块）不遮交互视线
    const base = colliderBase(s,m,band)
    for (const b of collidersAt(s,m,x,y)) {
      if (x < b.x0 || x > b.x1 || y < b.y0 || y > b.y1 || b.polygon&&!inPolygon(x,y,b.polygon)) continue
      const bottom = b.bottom === undefined ? base : base + b.bottom
      if(b.volume){if(l11SolidHits(b as L11SolidCollider,x,y,.0001,z-base-.001,z-base+.001))return true;continue}
      // 前台的物理碰撞仍保持不可翻越，但它的可见模型最高仅约 1.22m；
      // 视线不应把柜台当成一堵通到天花板的墙，否则柜台后的 NPC 只有绕到侧面/贴脸才可交谈。
      const sightTop = s.kind === 'frontdesk' ? 1.24 : b.top
      if (z >= bottom - 0.04 && z <= base + sightTop + 0.04) return true
    }
  }
  return false
}

/** City interaction segments visit precise nearby solids once. In particular,
 * a 4mm window must block reaching through it between the regular LOS samples. */
export function l11InteractionBlocked(m:GameMap,from:SolidPoint,to:SolidPoint,band:FloorBand,target?:Structure):boolean {
  if(!m.inf)return false
  const nearby=new Set<Structure>(),x=(from[0]+to[0])/2,y=(from[2]+to[2])/2,r=Math.max(Math.abs(from[0]-to[0]),Math.abs(from[2]-to[2]))/2+.01
  for(let cy=Math.max(0,Math.floor(y-r));cy<=Math.min(m.h-1,Math.floor(y+r));cy++)for(let cx=Math.max(0,Math.floor(x-r));cx<=Math.min(m.w-1,Math.floor(x+r));cx++)for(const s of structsNear(m,cx,cy))if(s!==target&&s.solid&&s.data?.noSight!==1&&citySolid(s))nearby.add(s)
  for(const s of nearby){
    const base=colliderBase(s,m,band),a:SolidPoint=[from[0],from[1]-base,from[2]],b:SolidPoint=[to[0],to[1]-base,to[2]]
    for(const collider of collidersAt(s,m,x,y,r))if(collider.volume&&l11SolidSegmentHit(collider as L11SolidCollider,a,b))return true
  }
  return false
}

// 世界点 (x,y) 处可站立的结构顶面高度（无则 -Infinity；仅当玩家 z 已接近/高于顶面时生效，
// 与 structBlocksPoint 的放行条件衔接：能进入 footprint 即可落在顶面上，不会卡进家具内部）
export function structStandTopAt(m: GameMap, x: number, y: number, z: number, band: FloorBand, radius = .32): number {
  let best = -Infinity
  for(const b of l11BridgeCollidersAt(m,x,y,radius)){const h=l11SolidSurface(b,x+m.inf!.ox,y+m.inf!.oy,radius);if(h<=z+.225)best=Math.max(best,h)}
  // A foot can overlap a thin partition even when its centre is outside the tile.
  const center = structsNear(m, Math.floor(x), Math.floor(y))
  const city=!!l11MapSpace(m,x,y,0)||center.some(citySolid)
  const nearCubicles=city||m.tint[Math.floor(y)*m.w+Math.floor(x)]===51?new Set(center):null
  if(nearCubicles)for(const dx of [-radius,radius])for(const dy of [-radius,radius])
    for(const s of structsNear(m,Math.floor(x+dx),Math.floor(y+dy)))if(city||s.kind==='cubicle'&&s.data?.l4)nearCubicles.add(s)
  const arr=nearCubicles??center
  for (const s of arr) {
    if (!s.solid || (!citySolid(s) && (s.floor ?? 0) !== band)) continue
    const base = colliderBase(s,m,band)
    for (const b of collidersAt(s,m,x,y,radius)) {
      if (!b.stand) continue
      if(b.volume){const h=base+l11SolidSurface(b as L11SolidCollider,x,y,radius);if(h<=z+.225)best=Math.max(best,h);continue}
      if(s.kind==='cubicle'&&s.data?.l4){
        // Match the radius AND the conservative corner samples used by canOccupy.
        if(x+radius<b.x0||x-radius>b.x1||y+radius<b.y0||y-radius>b.y1)continue
      }else if (x < b.x0 || x > b.x1 || y < b.y0 || y > b.y1 || b.polygon&&!inPolygon(x,y,b.polygon)) continue
      if (base + b.top <= z + (s.kind==='cubicle'&&s.data?.l4 ? .06 : STEP_UP-.1)) best = Math.max(best, base + b.top)
    }
  }
  return best
}

/** Swept upward head collision against the same solids used for lateral and
 * landing contacts. World-height filtering also sees props on another floor. */
export function l11HeadCeilingAt(m:GameMap,x:number,y:number,feetBefore:number,head:number,r=.32):number {
  let ceiling=Infinity;const seen=new Set<Structure>()
  for(const b of l11BridgeCollidersAt(m,x,y,r)){const h=l11SolidSurface(b,x+m.inf!.ox,y+m.inf!.oy,r,false);if(h>=feetBefore+head-.035)ceiling=Math.min(ceiling,h)}
  for(const dx of [-r,0,r])for(const dy of [-r,0,r])for(const s of structsNear(m,x+dx,y+dy)){
    if(seen.has(s)||!s.solid||!citySolid(s))continue;seen.add(s)
    const base=colliderBase(s,m,s.floor??0)
    for(const b of collidersAt(s,m,x,y,r))if(b.volume){
      if(base+b.top<feetBefore+head-.035)continue
      const h=base+l11SolidSurface(b as L11SolidCollider,x,y,r,false)
      if(h>=feetBefore+head-.035)ceiling=Math.min(ceiling,h)
    }
  }
  return ceiling
}

// ================= v26：天花板碰撞 + 悬挂物依附 =================
// 瓦片是否有天花板（室内地板即有顶；室外/虚空/边界无顶）
export function hasCeiling(m: GameMap, tx: number, ty: number): boolean {
  if (tx < 0 || ty < 0 || tx >= m.w || ty >= m.h) return false
  const i = ty * m.w + tx
  return m.tiles[i] === 1 && m.outdoor[i] !== 1
}

// v46：挑高区顶高——多层（floors>1）时与上层天花板拉平（≥FLOOR_H+2.6），
// 消除「挑高天花 H*1.75 与夹楼天花 5.6 之间 0.35m 错层缝」（从二层望向挑空区，
// 低一截的挑高天花像一层漂浮在天花板下方的纹理——一层区域的顶只能有一层）
// v54：三层（floors>2）时与第三层天花拉平（≥2×FLOOR_H+2.6）
export function tallCeilH(m: GameMap, wallH: number): number {
  const t = wallH * 1.75
  if (m.floors > 2) return Math.max(t, 2 * FLOOR_H + 2.6)
  return m.floors > 1 ? Math.max(t, FLOOR_H + 2.6) : t
}

// v49：墙瓦片底/顶高计算（从 geometry 主墙循环抽出，单一事实源——渲染层与冒烟断言共用）：
// 非地板瓦片 8 邻接地板才成墙（否则返回 null）；底=相邻最低地面（低洼/水池/坡道下探），
// 顶=层高，邻挑高地板→挑高顶 tallCeilH（v46 拉平）、邻上层楼板→FLOOR_H+2.6（接到上层天花）；
// 只邻室外地板的外墙降为 1.1m 护墙（露出天空与远景剪影）
export function wallBaseTopAt(m: GameMap, x: number, y: number, wallH: number): { base: number; top: number } | null {
  if (x < 0 || y < 0 || x >= m.w || y >= m.h) return null
  if (m.tiles[y * m.w + x] === 1) return null
  const isFloor = (nx: number, ny: number) => nx >= 0 && ny >= 0 && nx < m.w && ny < m.h && m.tiles[ny * m.w + nx] === 1
  let adj = false, base = 0, top = wallH
  let nearIndoor = false, nearOutdoor = false
  for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1], [1, -1], [-1, 1]] as const) {
    const nx = x + dx, ny = y + dy
    if (!isFloor(nx, ny)) continue
    adj = true
    const ni = ny * m.w + nx
    if (m.outdoor[ni] === 1) nearOutdoor = true; else nearIndoor = true
    const st = m.step[ni]
    const s2 = m.stair[ni]
    const nh = (s2 & 7) ? ((s2 >> 3) & 0x3fff) / 100
      : (st & 7) ? Math.min(ELEV_H[(st >> 3) & 3], ELEV_H[(st >> 5) & 3])
        : m.liquid[ni] === 1 ? -(m.seaFloor[ni] || 1.7) : m.liquid[ni] === 2 ? ELEV_H[m.elev[ni]] - 0.25 : ELEV_H[m.elev[ni]]
    base = Math.min(base, nh)
    if (m.l1Architecture) top = Math.max(top, l1RoofAt(m,nx+.5,ny+.5,wallH))
    if (m.ceiling[ni] === 1 && m.outdoor[ni] !== 1) top = Math.max(top, tallCeilH(m, wallH)) // 邻挑高地板→顶=挑高顶
    if (m.up[ni] === 1 && m.outdoor[ni] !== 1) top = Math.max(top, FLOOR_H + 2.6) // 邻上层楼板→墙体接到上层天花板
    if (m.up2[ni] === 1 && m.outdoor[ni] !== 1) top = Math.max(top, 2 * FLOOR_H + 2.6) // v54：邻第三层楼板→接到三层天花
  }
  if (!adj) return null
  // L1 partitions use the same roof height as their visible/collidable neighbours.
  if (nearOutdoor && !nearIndoor) top = Math.min(top, 1.1) // 室外护墙/围栏
  // v54c 多层解耦：正上方压着上层楼板/上层墙（本格 up/up2/upWall）时，本墙止于楼板底——
  // 不再被邻格的上层楼板牵着升高（旧规则让 1F 间墙穿过上层地板，上层平面被 1F 轮廓牵死）
  const i0 = y * m.w + x
  if (m.up[i0] === 1 || m.upWall[i0] === 1) top = Math.min(top, FLOOR_H - 0.35)
  else if (m.up2[i0] === 1 || m.upWall2[i0] === 1) top = Math.min(top, 2 * FLOOR_H - 0.35)
  return { base, top }
}

// v49：低顶地板与挑高（ceiling=1）地板直接相邻（中间无墙瓦片）的「檐口」边界列表——
// 低层屋顶（wallH）到挑高顶（tallCeilH）之间原本是虚空（EL3A 迎宾廊口/东西门廊口、L274 前厅口、L5 大堂开口）。
// 通用规则：凡低顶地板 4 邻接挑高地板，渲染层（geometry）在分界线上从低顶到挑高顶填一段薄墙封住虚空。
// 低顶格定义：室内地板、非上层楼板（楼板盒侧面已封闭楼板底缝）、非风道（风道盒自填）、非挑高本身
export interface CeilStep { x: number; y: number; dir: number; lo: number; hi: number } // (x,y)=低顶格；dir=挑高侧方向（0北 1东 2南 3西）
export function ceilingSteps(m: GameMap, wallH: number): CeilStep[] {
  const out: CeilStep[] = []
  const tallH = tallCeilH(m, wallH)
  for (let y = 0; y < m.h; y++)
    for (let x = 0; x < m.w; x++) {
      const i = y * m.w + x
      if (m.tiles[i] !== 1 || m.outdoor[i] === 1 || m.up[i] === 1 || m.up2[i] === 1 || m.crawl[i] === 1 || m.ceiling[i] === 1) continue
      for (const [dx, dy, d] of [[0, -1, 0], [1, 0, 1], [0, 1, 2], [-1, 0, 3]] as const) {
        const nx = x + dx, ny = y + dy
        if (nx < 0 || ny < 0 || nx >= m.w || ny >= m.h) continue
        const ni = ny * m.w + nx
        if (m.tiles[ni] !== 1 || m.outdoor[ni] === 1 || m.up[ni] === 1 || m.crawl[ni] === 1) continue
        if (m.ceiling[ni] === 1) { out.push({ x, y, dir: d, lo: wallH, hi: tallH }); continue }
        // v54e：邻格为「仅 3F 板」挑空（up=0 且 up2=1，如 Gamma 前厅中庭）——低顶（wallH）到
        // 3F 板底（2×FLOOR_H−0.35）之间同样要填薄墙封边（门洞/窗格低顶格与挑空中庭直接相邻时的镂空黑洞）
        if (m.up2[ni] === 1) out.push({ x, y, dir: d, lo: wallH, hi: 2 * FLOOR_H - 0.35 })
      }
    }
  return out
}

// 世界点 (x,y) 的天花板底面高度（米；无天花板 = Infinity）
// wallH=本层层高；挑高区（ceiling=1）= tallCeilH；上层楼板下 = 楼板底 FLOOR_H-0.35；
// 蹲伏风道 = 风道底 1.15m；上层走 band=1/2 的对应层天花板（v54：band2=三层天花 2×FLOOR_H+2.6，
// band1 上方有三层楼板时=三层楼板底 2×FLOOR_H-0.35）；
// v46：楼梯坡道格=楼梯口上空（无楼板——坡道上段 up=1 是「上层可站」标记而非有楼板），
// 顶高取上层天花（此前误取楼板底 2.65，坡道中段起跳被看不见的「楼板」拦截——多层交界处无法跳跃）
export function ceilingHeightAt(m: GameMap, x: number, y: number, wallH: number, band: FloorBand = 0): number {
  // L11 uses actual slabs/roofs/canopies and stair holes, not 1m ceiling tiles.
  if(l11MapSpace(m,x,y,band))return band>=0||l11MetroRamp(x+m.inf!.ox,y+m.inf!.oy,m.inf!.seed)!==null?Infinity:L11_METRO_CEILING
  const tx = Math.floor(x), ty = Math.floor(y)
  if (tx < 0 || ty < 0 || tx >= m.w || ty >= m.h) return Infinity
  const i = ty * m.w + tx
  if (band === 0 && m.settlement) return settlementCeiling(m,x,y)
  if (band === -1) return m.dn[i] === 1 ? UNDER_CEIL : Infinity
  // 洞穴边界是连续体积，不服从「该瓦片中心是否为地板」；先取真实洞顶再走旧瓦片逻辑。
  if (band === 0 && m.caveVolumeId !== undefined) return caveCeilingAt(m, x, y)
  if (!hasCeiling(m, tx, ty)) return Infinity
  if(m.inf?.l0)return 2.7
  if (band === 0 && m.l1Architecture) return l1RoofAt(m,x,y,wallH,true)
  if (band === 0 && m.inf && [18,19,20,51].includes(m.tint[i])) return l3RoofAt(m,x,y)
  if (band === 0 && m.organicCave && m.caveCeil) return caveCeilingAt(m, x, y)
  if (band === 2) return m.ceiling[i] === 1 ? tallCeilH(m, wallH) : 2 * FLOOR_H + 2.6 // v54：三层天花
  if (band === 1) {
    if (m.ceiling[i] === 1) return tallCeilH(m, wallH)
    if ((m.stair[i] & 7) !== 0 && m.up2[i] === 1) return 2 * FLOOR_H + 2.6 // v54：2F→3F 坡道上空（up2=可站标记而非楼板）
    return m.up2[i] === 1 ? 2 * FLOOR_H - 0.35 : FLOOR_H + 2.6 // v54：上方有三层楼板时=其板底
  }
  if ((m.stair[i] & 7) !== 0) return m.ceiling[i] === 1 ? tallCeilH(m, wallH) : m.up[i] === 1 ? FLOOR_H + 2.6 : wallH
  if (m.up[i] === 1) return FLOOR_H - 0.35 // 上层楼板底面即本层天花板
  if (m.crawl[i] === 1) return 1.15 // 头顶风道（蹲伏通道）
  return m.ceiling[i] === 1 ? tallCeilH(m, wallH) : wallH
}

// 悬挂生成物（吊灯/荧光灯/指示灯排）——必须依附天花板放置；sconce 壁灯贴墙不在此列
export const HANGING_KINDS: readonly string[] = ['chandelier', 'hanglight', 'lightgrid', 'ceilvent']

// 悬挂物放置校验（生成后调用）：
// 1) 占据的每块瓦片都必须有天花板（非室外/非虚空）——否则尝试就近移位（2 格内有顶空位），失败则移除
// 2) 同一块天花板瓦片不重叠放置多个悬挂物——后放的就近移位，失败则移除
export function fixHanging(m: GameMap) {
  const taken = new Set<number>()
  const kept: Structure[] = []
  const fits = (s: Structure, nx: number, ny: number): boolean => {
    for (let ty = Math.floor(ny); ty < Math.floor(ny + s.h); ty++)
      for (let tx = Math.floor(nx); tx < Math.floor(nx + s.w); tx++) {
        if (!hasCeiling(m, tx, ty)) return false
        if (taken.has(ty * m.w + tx)) return false
      }
    return true
  }
  const occupy = (s: Structure) => {
    for (let ty = Math.floor(s.y); ty < Math.floor(s.y + s.h); ty++)
      for (let tx = Math.floor(s.x); tx < Math.floor(s.x + s.w); tx++) taken.add(ty * m.w + tx)
  }
  for (const s of m.structures) {
    if (!HANGING_KINDS.includes(s.kind)) { kept.push(s); continue }
    if (fits(s, s.x, s.y)) { occupy(s); kept.push(s); continue }
    // 就近移位：以原中心为圆心 2 格内找有顶且不冲突的位置
    let moved = false
    for (let r = 1; r <= 2 && !moved; r++) {
      for (let dy = -r; dy <= r && !moved; dy++)
        for (let dx = -r; dx <= r && !moved; dx++) {
          const nx = s.x + dx, ny = s.y + dy
          if (!fits(s, nx, ny)) continue
          s.x = nx; s.y = ny
          occupy(s); kept.push(s); moved = true
        }
    }
    // 移位失败：取消该悬挂物（不再悬空/嵌入/重叠）
  }
  m.structures = kept
}

// 任意结构（含非实心装饰/prefabmark）占据判定：室外改造挖区/砌墙时避让，防止压坏既有内容
function anyStructAt(m: GameMap, x: number, y: number): boolean {
  return m.structures.some((s) => x >= s.x && x < s.x + s.w && y >= s.y && y < s.y + s.h)
}

export function tileAt(m: GameMap, x: number, y: number): number {
  if (x < 0 || y < 0 || x >= m.w || y >= m.h) return 0
  const t = m.tiles[y * m.w + x]
  if (t !== 1) return t
  return isSolidStruct(m, x, y) ? 2 : 1
}

function carveRoom(m: GameMap, x: number, y: number, w: number, h: number) {
  for (let j = y; j < y + h; j++)
    for (let i = x; i < x + w; i++)
      if (i > 0 && j > 0 && i < m.w - 1 && j < m.h - 1) m.tiles[j * m.w + i] = 1
}

function carveH(m: GameMap, x1: number, x2: number, y: number, wdt = 1) {
  for (let x = Math.min(x1, x2); x <= Math.max(x1, x2); x++)
    for (let k = 0; k < wdt; k++) if (m.tiles[(y + k) * m.w + x] !== undefined) m.tiles[(y + k) * m.w + x] = 1
}
function carveV(m: GameMap, y1: number, y2: number, x: number, wdt = 1) {
  for (let y = Math.min(y1, y2); y <= Math.max(y1, y2); y++)
    for (let k = 0; k < wdt; k++) if (m.tiles[y * m.w + x + k] !== undefined) m.tiles[y * m.w + x + k] = 1
}

interface Room { x: number; y: number; w: number; h: number; cx: number; cy: number }

function genRooms(m: GameMap, rng: RNG, nRooms: number, minS: number, maxS: number, corrW = 1): Room[] {
  const rooms: Room[] = []
  for (let t = 0; t < nRooms * 4 && rooms.length < nRooms; t++) {
    const w = rng.int(minS, maxS)
    const h = rng.int(minS, maxS)
    const x = rng.int(1, m.w - w - 2)
    const y = rng.int(1, m.h - h - 2)
    if (rooms.some((r) => x < r.x + r.w + 2 && x + w + 2 > r.x && y < r.y + r.h + 2 && y + h + 2 > r.y)) continue
    carveRoom(m, x, y, w, h)
    rooms.push({ x, y, w, h, cx: x + (w >> 1), cy: y + (h >> 1) })
  }
  for (let i = 1; i < rooms.length; i++) {
    const a = rooms[i - 1]
    const b = rooms[i]
    if (rng.chance(0.5)) {
      carveH(m, a.cx, b.cx, a.cy, corrW)
      carveV(m, a.cy, b.cy, b.cx, corrW)
    } else {
      carveV(m, a.cy, b.cy, a.cx, corrW)
      carveH(m, a.cx, b.cx, b.cy, corrW)
    }
  }
  return rooms
}

// 宽走廊迷宫（L0）：格子间距 3、通路宽 2、墙厚 1，保持迷宫感但避免一格窄道
function wideMaze(m: GameMap, rng: RNG) {
  const step = 3
  const carve2 = (cx: number, cy: number) => {
    for (let j = 0; j < 2; j++)
      for (let i = 0; i < 2; i++) {
        const xx = cx + i, yy = cy + j
        if (xx > 0 && yy > 0 && xx < m.w - 1 && yy < m.h - 1) m.tiles[idx(m, xx, yy)] = 1
      }
  }
  for (let y = 1; y + 1 < m.h - 1; y += step)
    for (let x = 1; x + 1 < m.w - 1; x += step) {
      if (m.tiles[idx(m, x, y)] === 1) continue
      carve2(x, y)
      let cx = x, cy = y
      for (let s = 0; s < 50; s++) {
        const dirs = [[step, 0], [-step, 0], [0, step], [0, -step]].filter(([dx, dy]) => {
          const nx = cx + dx, ny = cy + dy
          return nx > 0 && ny > 0 && nx + 1 < m.w - 1 && ny + 1 < m.h - 1 && m.tiles[idx(m, nx, ny)] === 0
        })
        if (!dirs.length) break
        const [dx, dy] = rng.pick(dirs)
        if (dx !== 0) carve2(cx + Math.sign(dx), cy) // 中间连接格（2 宽）
        else carve2(cx, cy + Math.sign(dy))
        cx += dx; cy += dy
        carve2(cx, cy)
      }
    }
}



function randomFloor(m: GameMap, rng: RNG, margin = 0): { x: number; y: number } {
  for (let t = 0; t < 400; t++) {
    const x = rng.int(2, m.w - 3)
    const y = rng.int(2, m.h - 3)
    if (m.tiles[idx(m, x, y)] === 1 && !isSolidStruct(m, x, y)) {
      if (margin && m.spawn && Math.hypot(x - m.spawn.x, y - m.spawn.y) < margin) continue
      return { x, y }
    }
  }
  return { x: 2, y: 2 }
}

function place(m: GameMap, rng: RNG, kind: Structure['kind'], w: number, h: number, solid: boolean, data?: Structure['data']): Structure | null {
  for (let t = 0; t < 200; t++) {
    const x = rng.int(1, m.w - w - 1)
    const y = rng.int(1, m.h - h - 1)
    let ok = true
    for (let j = y - 1; j <= y + h && ok; j++)
      for (let i = x - 1; i <= x + w && ok; i++)
        if (m.tiles[idx(m, i, j)] !== 1 || isSolidStruct(m, i, j)) ok = false
    for (let j = y; j < y + h && ok; j++)
      for (let i = x; i < x + w && ok; i++)
        if (m.outdoor[idx(m, i, j)] === 1) ok = false // v8：室内家具不进室外
    if (!ok) continue
    const s: Structure = { kind, x, y, w, h, solid, data }
    m.structures.push(s)
    return s
  }
  return null
}

// 贴墙装饰放置：地板瓦片且至少一侧紧邻非地板（墙/虚空），供涂鸦/通风口等贴墙结构使用
function placeWallHug(m: GameMap, rng: RNG, kind: Structure['kind'], data?: Structure['data']): Structure | null {
  for (let t = 0; t < 400; t++) {
    const x = rng.int(1, m.w - 2)
    const y = rng.int(1, m.h - 2)
    if (m.tiles[idx(m, x, y)] !== 1 || m.outdoor[idx(m, x, y)] === 1 || isSolidStruct(m, x, y)) continue
    let hasWall = false
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
      const nx = x + dx, ny = y + dy
      if (nx >= 0 && ny >= 0 && nx < m.w && ny < m.h && m.tiles[idx(m, nx, ny)] !== 1) { hasWall = true; break }
    }
    if (!hasWall) continue
    const s: Structure = { kind, x, y, w: 1, h: 1, solid: false, data }
    m.structures.push(s)
    return s
  }
  return null
}

// ---------- v9：门朝向约定 ----------
// 门板平面与所在墙线平行：水平墙线（东西走向，W/E 邻为墙）→ 门板跨 X、面朝南北（默认构建，不旋转）；
// 垂直墙线（南北走向，N/S 邻为墙）→ 整体旋转 90°（门板跨 Z、面朝东西）。
// 双开门相邻的另一扇门视作墙。返回应施加在门组上的 rotation.y（0 或 π/2）。
export function doorNeedsRotate(m: GameMap, s: Structure): number {
  // v57m：多层门按所在楼层带读 up/upWall，否则 L7 2F 舱门会按一层全水面误判为侧向门
  const band = s.floor ?? 0
  const f = (x: number, y: number) => {
    if (x < 0 || y < 0 || x >= m.w || y >= m.h) return false
    const i = y * m.w + x
    if (band === 1) return m.up[i] === 1 && m.upWall[i] !== 1
    return m.tiles[i] === 1
  }
  const DOORS: readonly string[] = ['hoteldoor', 'rollerdoor', 'glassdoor', 'bargate'] // v51：bargate 栅栏门
  const ax = Math.floor(s.x + s.w / 2), ay = Math.floor(s.y + s.h / 2)
  const doorAt = (x: number, y: number) =>
    m.structures.some((o) => o !== s && DOORS.includes(o.kind) && (o.floor ?? 0) === band && Math.floor(o.x + o.w / 2) === x && Math.floor(o.y + o.h / 2) === y)
  const wallish = (x: number, y: number) => !f(x, y) || doorAt(x, y)
  const we = wallish(ax - 1, ay) && wallish(ax + 1, ay)
  const ns = wallish(ax, ay - 1) && wallish(ax, ay + 1)
  if (we && !ns) return 0 // 水平墙线：门板跨 X（面朝南北），法线沿 Z ⟂ 墙线
  if (ns && !we) return Math.PI / 2 // 垂直墙线：旋转后门板跨 Z（面朝东西），法线沿 X ⟂ 墙线
  // 退化情形（开阔门洞）：按通行方向推断——东西可通行 ⇒ 墙线南北走向 ⇒ 旋转
  return f(ax - 1, ay) && f(ax + 1, ay) ? Math.PI / 2 : 0
}

// ---------- 结构包围盒-墙体碰撞检查（防模型卡墙）----------
// 结构 3D 模型的世界轴对齐包围盒（米，瓦片坐标系）
export function structBBox(s: Structure): { x0: number; y0: number; x1: number; y1: number } {
  if (s.kind === 'door') {
    // 客房门模型锚点在房间东缘（renderer3d 特判）
    return { x0: s.x + s.w - 0.56, y0: s.y + s.h / 2 - 0.55, x1: s.x + s.w - 0.44, y1: s.y + s.h / 2 + 0.55 }
  }
  const inset = 0.06 // 模型相对瓦片矩形的标准内缩
  return { x0: s.x + inset, y0: s.y + inset, x1: s.x + s.w - inset, y1: s.y + s.h - inset }
}

// 包围盒是否与墙/虚空瓦片相交（卡墙判定）
export function structWallClip(m: GameMap, s: Structure): boolean {
  const b = structBBox(s)
  for (let y = Math.floor(b.y0); y <= Math.floor(b.y1 - 1e-6); y++)
    for (let x = Math.floor(b.x0); x <= Math.floor(b.x1 - 1e-6); x++)
      if (x < 0 || y < 0 || x >= m.w || y >= m.h || m.tiles[y * m.w + x] !== 1) return true
  return false
}

// 生成后修正：结构若卡墙（包围盒与墙/虚空瓦片相交），先在瓦片内微移（多档偏移），
// 仍卡墙则整体移除（视觉嵌墙比少一件装饰更糟）；门/窗类结构瓦片必为地板，不会走到移除。
function fixStructEmbedding(m: GameMap) {
  const KEEP: readonly string[] = ['hoteldoor', 'rollerdoor', 'glassdoor', 'glasswin', 'prefabmark']
  const removed: Structure[] = []
  for (const s of m.structures) {
    if (KEEP.includes(s.kind)) continue
    if (!structWallClip(m, s)) continue
    let fixed = false
    for (const [dx, dy] of [[0, 0], [0.12, 0], [-0.12, 0], [0, 0.12], [0, -0.12], [0.22, 0], [-0.22, 0], [0, 0.22], [0, -0.22], [0.12, 0.12], [-0.12, -0.12], [0.12, -0.12], [-0.12, 0.12]] as const) {
      s.x += dx; s.y += dy
      // 微移后不得与其他实心结构重叠
      const overlap = m.structures.some((o) => o !== s && o.solid && s.x < o.x + o.w && s.x + s.w > o.x && s.y < o.y + o.h && s.y + s.h > o.y)
      if (!overlap && !structWallClip(m, s)) { fixed = true; break }
      s.x -= dx; s.y -= dy
    }
    if (!fixed) removed.push(s)
  }
  if (removed.length) m.structures = m.structures.filter((s) => !removed.includes(s))
}

// 门依附墙线校验：1×1 门结构（hoteldoor/rollerdoor/glassdoor）与客房门锚点（door）
// 必须满足「一对侧是墙/虚空、另一对侧是地板」；不满足则移除门结构（保留门洞可通行）
function validateDoors(m: GameMap) {
  const f = (x: number, y: number) => x >= 0 && y >= 0 && x < m.w && y < m.h && m.tiles[y * m.w + x] === 1
  // 双开门配对：data.dbl 的门允许一侧为另一扇 dbl 门（共享门框，视作墙）
  const dblAt = (x: number, y: number) =>
    m.structures.some((o) => (o.kind === 'hoteldoor' || o.kind === 'glassdoor') && o.data?.dbl && x >= o.x && x < o.x + o.w && y >= o.y && y < o.y + o.h)
  // 卷帘门墙：相邻卷帘门锚点互认作墙（保险库式连续卷帘门排布——关上的卷帘门本身就是金属墙，
  // 与 doorNeedsRotate 的 doorAt 语义一致；两端仍须锚在真墙上，由 we/ns 的另一侧保证）
  const rdAt = (x: number, y: number, self: Structure) =>
    m.structures.some((o) => o !== self && o.kind === 'rollerdoor' && Math.floor(o.x + o.w / 2) === x && Math.floor(o.y + o.h / 2) === y)
  m.structures = m.structures.filter((s) => {
    let ax: number, ay: number
    if (s.kind === 'door') { ax = Math.floor(s.x + s.w - 0.5); ay = Math.floor(s.y + s.h / 2) }
    else if (s.kind === 'hoteldoor' || s.kind === 'rollerdoor' || s.kind === 'glassdoor') { ax = Math.floor(s.x + s.w / 2); ay = Math.floor(s.y + s.h / 2) }
    else return true
    if (s.kind === 'door' && !f(ax, ay)) return true // 门模型嵌在非地板（墙线）内：合规
    const wallish = (x: number, y: number) => !f(x, y) || (!!s.data?.dbl && dblAt(x, y)) || (s.kind === 'rollerdoor' && rdAt(x, y, s))
    const we = wallish(ax - 1, ay) && wallish(ax + 1, ay)
    const ns = wallish(ax, ay - 1) && wallish(ax, ay + 1)
    const weF = f(ax - 1, ay) && f(ax + 1, ay) && !dblAt(ax - 1, ay) && !dblAt(ax + 1, ay)
    const nsF = f(ax, ay - 1) && f(ax, ay + 1) && !dblAt(ax, ay - 1) && !dblAt(ax, ay + 1)
    return (we && nsF) || (ns && weF)
  })
}

// prefab 可达性校验：每个 prefabmark 记录的矩形内必须存在可达的开放地板；
// 不可达则先挖 2 宽走廊接入最近可达地板，仍失败则移除该 prefab 全部内容（结构/物品/灯）
function ensurePrefabsReachable(m: GameMap, reach: Uint8Array, bfs: () => void) {
  const size = m.w
  const marks = m.structures.filter((s) => s.kind === 'prefabmark' && typeof s.data?.rw === 'number')
  for (const mark of marks) {
    const rx = mark.data!.rx as number, ry = mark.data!.ry as number
    const rw = mark.data!.rw as number, rh = mark.data!.rh as number
    const openReachable = () => {
      for (let j = ry; j < ry + rh; j++)
        for (let i = rx; i < rx + rw; i++) {
          const ii = j * size + i
          if (m.tiles[ii] === 1 && reach[ii] && !isSolidStruct(m, i, j)) return true
        }
      return false
    }
    if (openReachable()) continue
    // 挖走廊：从矩形内地板（优先开放瓦片）向四方向找最近可达地板，挖 2 宽通道接入
    let best: { x: number; y: number; dx: number; dy: number; d: number } | null = null
    for (const needOpen of [true, false] as const) {
      if (best) break
      for (let j = ry; j < ry + rh; j++)
        for (let i = rx; i < rx + rw; i++) {
          if (m.tiles[j * size + i] !== 1) continue
          if (needOpen && isSolidStruct(m, i, j)) continue
          for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
            for (let d = 1; d <= 24; d++) {
              const nx = i + dx * d, ny = j + dy * d
              if (nx < 1 || ny < 1 || nx >= size - 1 || ny >= size - 1) break
              const ni = ny * size + nx
              if (m.tiles[ni] === 1 && reach[ni]) {
                if (!best || d < best.d) best = { x: i, y: j, dx, dy, d }
                break
              }
              if (m.tiles[ni] === 1 && !reach[ni]) break // 另一孤岛：穿过无意义
            }
          }
        }
    }
    if (best) {
      const { x, y, dx, dy, d } = best
      for (let k = 0; k <= d; k++) {
        const cx = x + dx * k, cy = y + dy * k
        m.tiles[cy * size + cx] = 1
        const px = dy !== 0 ? cx + 1 : cx, py = dx !== 0 ? cy + 1 : cy
        if (px < size - 1 && py < size - 1) m.tiles[py * size + px] = 1
      }
      bfs()
      if (openReachable()) continue
    }
    // 仍不可达：移除 prefab 内容（含标记本身），避免不可达孤岛
    m.structures = m.structures.filter((s) =>
      !(s.x + s.w > rx && s.x < rx + rw && s.y + s.h > ry && s.y < ry + rh))
    m.items = m.items.filter((it) => !(it.x >= rx && it.x < rx + rw && it.y >= ry && it.y < ry + rh))
    m.lights = m.lights.filter((l) => !(l.x >= rx && l.x < rx + rw && l.y >= ry && l.y < ry + rh))
  }
}

// 生成质量校验：狭窄通道比例 + 出生区开阔度，不达标则换种子重 roll（外部限次）
function validate(m: GameMap, def: LevelDef): boolean {
  // 出生区 5×5 内至少 13 格可走（合理开阔空间）
  let open = 0
  for (let j = -2; j <= 2; j++)
    for (let i = -2; i <= 2; i++)
      if (tileAt(m, m.spawn.x + i, m.spawn.y + j) === 1) open++
  if (open < 13) return false
  // 一格窄通道比例（某轴两侧均非地板即视为瓶颈点）
  let floor = 0, narrow = 0
  for (let y = 1; y < m.h - 1; y++)
    for (let x = 1; x < m.w - 1; x++) {
      if (m.tiles[idx(m, x, y)] !== 1) continue
      floor++
      const h = m.tiles[idx(m, x - 1, y)] === 1 || m.tiles[idx(m, x + 1, y)] === 1
      const v = m.tiles[idx(m, x, y - 1)] === 1 || m.tiles[idx(m, x, y + 1)] === 1
      if (!h || !v) narrow++
    }
  const ratio = floor ? narrow / floor : 1
  const limit: Record<string, number> = { rooms: 0.4, garage: 0.12, pipes: 0.3, grid: 0.3, office: 0.3, hotel: 0.3 }
  return ratio <= (limit[def.gen] ?? 0.3)
}

export function generateLevel(def: LevelDef, seed: number, firstVisit = true): GameMap {
  // v17：无限模式层级（L0/L1）走 chunk 流式生成路径，不做有限地图质量校验
  // v29：firstVisit=false 时跳过出生点物资散落（初始物资仅首次到层刷新）
  if (def.infinite) return generateInfinite(def, seed, firstVisit)
  // 质量校验重 roll（限 6 次，兜底返回最后一次结果；据点为手工布局，跳过校验）
  for (let attempt = 0; attempt < 6; attempt++) {
    const m = genOnce(def, seed + attempt * 10007)
    if (attempt === 5 || def.gen === 'outpost' || validate(m, def)) return m
  }
  return genOnce(def, seed)
}

function genOnce(def: LevelDef, seed: number): GameMap {
  const rng = new RNG(seed ^ (def.id * 0x9e3779b9))
  const size = def.size
  const m: GameMap = {
    w: size, h: size,
    tiles: new Uint8Array(size * size), // 全 0
    structures: [], items: [], lights: [], exits: [], entities: [],
    spawn: { x: 2, y: 2 },
    wet: new Uint8Array(size * size),
    elev: new Uint8Array(size * size),
    outdoor: new Uint8Array(size * size),
    step: new Uint8Array(size * size),
    crawl: new Uint8Array(size * size),
    ceiling: new Uint8Array(size * size),
    up: new Uint8Array(size * size),
    upWall: new Uint8Array(size * size),
    up2: new Uint8Array(size * size), // v54：三层楼板（缺省全 0=无三层）
    upWall2: new Uint8Array(size * size),
    stair: new Int32Array(size * size),
    liquid: new Uint8Array(size * size),
    seaFloor: new Float32Array(size * size).fill(POOL_DEPTH),
    floors: 1,
    tint: new Uint8Array(size * size),
    dn: new Uint8Array(size * size), // v56 九轮：地下平面（Level 6 -1F；其余层级全 0）
    dnWall: new Uint8Array(size * size), // v56 九轮：地下墙体（Level 6 -1F；其余层级全 0）
    hasUnderground: false,
    terrain: new Float32Array(size * size),
    l7SeaTerrain: def.id === 7,
    l10LakeTerrain: def.id === 10,
  }
  // 初始化为墙
  m.tiles.fill(2)
  for (let y = 1; y < size - 1; y++) for (let x = 1; x < size - 1; x++) m.tiles[idx(m, x, y)] = 0

  let rooms: Room[] = []
  switch (def.gen) {
    case 'rooms': {
      rooms = genRooms(m, rng, 12, 5, 10, 2) // 2 格宽连通走廊
      wideMaze(m, rng) // 宽走廊迷宫混合（通路宽 ≥2）
      break
    }
    case 'garage': {
      // 开阔大厅 + 规则柱网（房间化/方正布局）
      carveRoom(m, 3, 3, size - 6, size - 6)
      rooms = [{ x: 3, y: 3, w: size - 6, h: size - 6, cx: size >> 1, cy: size >> 1 }]
      // 分隔墙（带 3 格宽门洞），把大厅切分为方正停车区
      for (const wx of [size * 0.33 | 0, size * 0.66 | 0]) {
        const gap1 = rng.int(8, size - 12), gap2 = rng.int(8, size - 12)
        for (let y = 3; y < size - 3; y++) {
          if (Math.abs(y - gap1) < 2 || Math.abs(y - gap2) < 2) continue
          if (rng.chance(0.9)) m.tiles[idx(m, wx, y)] = 2
        }
      }
      // 柱网（避开分隔墙）
      for (let y = 8; y < size - 8; y += 7)
        for (let x = 8; x < size - 8; x += 7)
          if (m.tiles[idx(m, x, y)] === 1) m.structures.push({ kind: 'pillar', x, y, w: 1, h: 1, solid: true })
      // 车位线
      for (let y = 5; y < size - 5; y += 7)
        for (let x = 4; x < size - 6; x += 3)
          if (rng.chance(0.7)) m.tiles[idx(m, x, y)] = 1
      // 车辆集群
      for (let i = 0; i < 14; i++) {
        const horiz = rng.chance(0.5)
        place(m, rng, 'car', horiz ? 2 : 1, horiz ? 1 : 2, true, { loot: 1 })
      }
      place(m, rng, 'booth', 2, 2, true, { shelter: 1 })
      break
    }
    case 'pipes': {
      // v41：死代码——L2 已改无限 chunk 生成（infiniteL2.ts，def.infinite=true 时 genOnce 不会执行）；
      // 本分支及以下 'pipes' 相关分支仅保留作参考，不再被调用
      // 走廊网：主通道全部 ≥2 格宽
      rooms = genRooms(m, rng, 6, 4, 7, 2)
      let y = 4
      while (y < size - 6) {
        carveH(m, 3, size - 4, y, 2)
        y += rng.int(7, 12)
      }
      let x = 4
      while (x < size - 6) {
        carveV(m, 3, size - 4, x, 2)
        x += rng.int(8, 14)
      }
      // 阀门室
      for (let i = 0; i < 5; i++) place(m, rng, 'valve', 1, 1, false, { on: rng.chance(0.5) ? 1 : 0 })
      for (let i = 0; i < 8; i++) place(m, rng, 'gauge', 1, 1, false)
      for (let i = 0; i < 10; i++) place(m, rng, 'pipes', 1, 1, true)
      place(m, rng, 'boiler', 4, 4, true, { boss: 1 })
      break
    }
    case 'grid': {
      // 发电大厅网格：方正大房间 + 2 宽直连走廊 + 电缆沟
      rooms = genRooms(m, rng, 8, 7, 11, 2)
      for (let i = 0; i < 6; i++) {
        const x = rng.int(4, size - 6)
        carveV(m, 3, size - 4, x, 1)
        for (let yy = 3; yy < size - 4; yy++) if (rng.chance(0.15)) m.structures.push({ kind: 'trench', x, y: yy, w: 1, h: 1, solid: false })
      }
      for (let i = 0; i < 5; i++) place(m, rng, 'generator', 3, 2, true)
      for (let i = 0; i < 7; i++) place(m, rng, 'cabinet', 1, 1, true)
      break
    }
    case 'office': {
      // ===== v8 现实办公室布局 =====
      // 入口接待区（西）→ 开放式工位区（隔间矩阵，朝向一致）→ 沿墙独立办公室/会议室（带门）
      // → 茶水间/复印区角落；走廊笔直成网格（北/中/南横廊 × 西/中/东纵廊）
      // 网格：横廊 y 11..13 / 33..36 / 55..57；纵廊 x 11..13 / 33..36 / 55..57
      const wallRow = (yy: number, x0: number, x1: number) => { for (let x = x0; x <= x1; x++) m.tiles[idx(m, x, yy)] = 2 }
      const wallCol = (xx: number, y0: number, y1: number) => { for (let y = y0; y <= y1; y++) m.tiles[idx(m, xx, y)] = 2 }
      const doorAt = (x: number, y: number, locked = 0) => {
        m.tiles[idx(m, x, y)] = 1
        m.structures.push({ kind: 'hoteldoor', x, y, w: 1, h: 1, solid: true, data: { open: 0, locked } })
      }
      const solidFree = (x: number, y: number, w: number, h: number) =>
        !m.structures.some((s) => s.solid && x < s.x + s.w && x + w > s.x && y < s.y + s.h && y + h > s.y)
      carveRoom(m, 4, 4, size - 8, size - 8) // 整体开凿
      rooms = [{ x: 4, y: 25, w: 7, h: 19, cx: 7, cy: 34 }] // 出生=接待区

      // ---- 预制件预留虚空袋（两个随机象限中央不挖，供 megoutpost/blackwinroom 贴墙开洞）----
      const quads = [
        { x: 14, y: 14, w: 19, h: 19 }, { x: 37, y: 14, w: 18, h: 19 },
        { x: 14, y: 37, w: 19, h: 18 }, { x: 37, y: 37, w: 18, h: 18 },
      ]
      const pocketIdx = new Set<number>()
      while (pocketIdx.size < 2) pocketIdx.add(rng.int(0, 3))
      for (const pi of pocketIdx) {
        const q = quads[pi]
        const pw = rng.int(8, 11), ph = rng.int(7, 9)
        const px = q.x + ((q.w - pw) >> 1), py = q.y + ((q.h - ph) >> 1)
        for (let j = py; j < py + ph; j++)
          for (let i = px; i < px + pw; i++) m.tiles[idx(m, i, j)] = 0
      }

      // ---- 开放式工位区：整齐行列的隔间矩阵（2×1，朝向一致，行/列距 3）----
      for (let qi = 0; qi < 4; qi++) {
        const q = quads[qi]
        const density = rng.next() * 0.25 + 0.68
        for (let y = q.y + 1; y + 1 < q.y + q.h - 1; y += 3)
          for (let x = q.x + 1; x + 2 < q.x + q.w - 1; x += 3) {
            if (m.tiles[idx(m, x, y)] !== 1 || m.tiles[idx(m, x + 1, y)] !== 1) continue
            if (!rng.chance(density)) continue
            m.structures.push({ kind: 'cubicle', x, y, w: 2, h: 1, solid: true, data: { farm: 1 } })
          }
      }

      // ---- 沿墙独立办公室（北墙行 y=10 房深 4..9 / 南墙行 y=58 房深 59..65，带门）----
      const officeRow = (wallY: number, roomY0: number, roomY1: number) => {
        wallRow(wallY, 4, 65)
        let x = 4
        while (x < 62) {
          const w = rng.int(8, 12)
          const x1 = Math.min(x + w - 1, 65)
          const dx = x + ((x1 - x) >> 1)
          doorAt(dx, wallY)
          if (x1 + 1 <= 65) wallCol(x1 + 1, Math.min(roomY0, wallY), Math.max(roomY1, wallY))
          // 办公室家具：办公桌 + 概率文件柜/箱子（防重叠、避开门洞纵线）
          const deskX = x + rng.int(1, Math.max(1, x1 - x - 2))
          const deskY = roomY0 < wallY ? roomY0 + rng.int(1, 2) : roomY1 - rng.int(1, 2)
          if (Math.abs(deskX - dx) > 1 && solidFree(deskX, deskY, 2, 1)) {
            m.structures.push({ kind: 'desk', x: deskX, y: deskY, w: 2, h: 1, solid: true })
          }
          for (const [kind, chance, dy2] of [['cabinet', 0.5, roomY0 < wallY ? roomY1 - 1 : roomY0 + 1], ['crate', 0.3, roomY0 < wallY ? roomY0 + 1 : roomY1 - 1]] as const) {
            if (!rng.chance(chance)) continue
            for (let tr = 0; tr < 4; tr++) {
              const fx = x + rng.int(0, Math.max(0, x1 - x - 1))
              if (Math.abs(fx - dx) <= 1 || !solidFree(fx, dy2, 1, 1)) continue
              m.structures.push({ kind, x: fx, y: dy2, w: 1, h: 1, solid: true, data: kind === 'crate' ? { loot: 1 } : undefined })
              break
            }
          }
          x = x1 + 2
        }
      }
      officeRow(10, 4, 9)   // 北办公室排
      officeRow(58, 59, 65) // 南办公室排

      // ---- 西侧功能块：茶水间(北) / 接待区(中) / 复印区(南)，墙列 x=10，门朝纵廊 ----
      wallCol(10, 14, 54)
      wallRow(24, 4, 10); wallRow(44, 4, 10)
      doorAt(10, 19); doorAt(10, 34); doorAt(10, 49)
      // 茶水间 y 14..23
      m.structures.push({ kind: 'vending', x: 4, y: 15, w: 1, h: 2, solid: true, data: { trade: 1 } })
      m.structures.push({ kind: 'vending', x: 4, y: 18, w: 1, h: 2, solid: true, data: { trade: 1 } })
      m.structures.push({ kind: 'table', x: 6, y: 20, w: 1, h: 1, solid: true })
      if (rng.chance(0.7)) m.structures.push({ kind: 'table', x: 8, y: 16, w: 1, h: 1, solid: true })
      m.structures.push({ kind: 'crate', x: 8, y: 22, w: 1, h: 1, solid: true, data: { loot: 1 } })
      // 接待区 y 25..43：前台桌列 + 等候桌 + 售卖机
      m.structures.push({ kind: 'desk', x: 4, y: 31, w: 2, h: 1, solid: true })
      m.structures.push({ kind: 'desk', x: 4, y: 33, w: 2, h: 1, solid: true })
      m.structures.push({ kind: 'desk', x: 4, y: 35, w: 2, h: 1, solid: true })
      m.structures.push({ kind: 'table', x: 7, y: 29, w: 1, h: 1, solid: true })
      m.structures.push({ kind: 'table', x: 7, y: 39, w: 1, h: 1, solid: true })
      m.structures.push({ kind: 'vending', x: 4, y: 41, w: 1, h: 2, solid: true, data: { trade: 1 } })
      // 复印区 y 45..54
      m.structures.push({ kind: 'copier', x: 5, y: 47, w: 2, h: 2, solid: true, data: { loot: 1 } })
      m.structures.push({ kind: 'crate', x: 8, y: 52, w: 1, h: 1, solid: true, data: { loot: 1 } })
      m.structures.push({ kind: 'cabinet', x: 4, y: 52, w: 1, h: 1, solid: true })
      if (rng.chance(0.6)) m.structures.push({ kind: 'crate', x: 7, y: 45, w: 1, h: 1, solid: true, data: { loot: 1 } })

      // ---- 东侧功能块：会议室(北) / 机房(中,门禁) / 经理办公室(南)，墙列 x=58 ----
      wallCol(58, 14, 54)
      wallRow(24, 58, 65); wallRow(40, 58, 65)
      doorAt(58, 19); doorAt(58, 32, 1); doorAt(58, 47)
      // 会议室 y 14..23：长桌 + 白柜
      m.structures.push({ kind: 'table', x: 61, y: 17, w: 2, h: 1, solid: true })
      m.structures.push({ kind: 'table', x: 61, y: 19, w: 2, h: 1, solid: true })
      m.structures.push({ kind: 'cabinet', x: 64, y: 15, w: 1, h: 1, solid: true })
      // 机房 y 25..39：服务器阵列 + 机柜
      m.structures.push({ kind: 'server', x: 61, y: 30, w: 3, h: 3, solid: true, data: { locked: 1 } })
      m.structures.push({ kind: 'cabinet', x: 59, y: 26, w: 1, h: 1, solid: true })
      m.structures.push({ kind: 'cabinet', x: 59, y: 28, w: 1, h: 1, solid: true })
      if (rng.chance(0.7)) m.structures.push({ kind: 'cabinet', x: 59, y: 36, w: 1, h: 1, solid: true })
      // 经理办公室 y 41..54
      m.structures.push({ kind: 'desk', x: 60, y: 46, w: 2, h: 1, solid: true })
      m.structures.push({ kind: 'desk', x: 63, y: 50, w: 2, h: 1, solid: true })
      m.structures.push({ kind: 'dresser', x: 64, y: 42, w: 1, h: 1, solid: true, data: { loot: 1 } })
      if (rng.chance(0.5)) m.structures.push({ kind: 'crate', x: 59, y: 53, w: 1, h: 1, solid: true, data: { loot: 1 } })
      break
    }
    case 'hotel': {
      // ===== v8 现实酒店布局 =====
      // 中央大堂（前台/吊灯/休息区）→ 东侧笔直客房走廊（客房门等距相对排列 door stacks）
      // → 走廊尽头楼梯/电梯间 + 布草间；宴会厅独立区域带双开门（大堂南侧）；庭院在中部（玻璃门可达）
      const wallRow = (yy: number, x0: number, x1: number) => { for (let x = x0; x <= x1; x++) m.tiles[idx(m, x, yy)] = 2 }
      const wallCol = (xx: number, y0: number, y1: number) => { for (let y = y0; y <= y1; y++) m.tiles[idx(m, xx, y)] = 2 }

      // ---- 中央大堂 x4..21 y4..17（挑高由 applyElevation 加盖）----
      carveRoom(m, 4, 4, 18, 14)
      rooms = [{ x: 4, y: 4, w: 18, h: 14, cx: 13, cy: 11 }]
      m.structures.push({ kind: 'frontdesk', x: 6, y: 6, w: 4, h: 2, solid: true, data: { trade: 1 } })
      m.structures.push({ kind: 'chandelier', x: 13, y: 11, w: 1, h: 1, solid: false })
      // 休息区：沙发桌 + 镜子 + 壁灯
      m.structures.push({ kind: 'table', x: 17, y: 14, w: 1, h: 1, solid: true })
      m.structures.push({ kind: 'table', x: 19, y: 14, w: 1, h: 1, solid: true })
      m.structures.push({ kind: 'dresser', x: 5, y: 15, w: 1, h: 1, solid: true, data: { loot: 1 } })
      m.structures.push({ kind: 'mirror', x: 20, y: 5, w: 1, h: 2, solid: true })
      for (const [sx, sy] of [[4, 8], [4, 13], [21, 8], [21, 13]] as const)
        m.structures.push({ kind: 'sconce', x: sx, y: sy, w: 1, h: 1, solid: false })

      // ---- 东翼客房走廊 y10..11 x21..70（笔直）----
      carveRoom(m, 21, 10, 50, 2)
      wallRow(9, 22, 70)  // 北侧客房墙线
      wallRow(12, 22, 70) // 南侧客房墙线
      // 客房：宽 5、间距 6（1 格实墙相隔），北排 y4..8 门在 y=9，南排 y13..17 门在 y=12，门两两相对
      const guestRoom = (rx: number, ry2: number, doorX: number, doorY: number, side: 'n' | 's') => {
        carveRoom(m, rx, ry2, 5, 5)
        m.tiles[idx(m, doorX, doorY)] = 1 // 门洞瓦片开为地板
        m.structures.push({
          kind: 'hoteldoor', x: doorX, y: doorY, w: 1, h: 1, solid: true,
          data: { open: 0, stack: 1, locked: rng.chance(0.25) ? 1 : 0 },
        })
        // 客房布置：床(里侧) + 梳妆台 + 概率桌椅/窗
        const bedY = side === 'n' ? ry2 : ry2 + 3
        m.structures.push({ kind: 'bed', x: rx + rng.int(0, 1), y: bedY, w: 1, h: 2, solid: true })
        m.structures.push({ kind: 'dresser', x: rx + 4, y: bedY, w: 1, h: 1, solid: true, data: { loot: 1 } })
        if (rng.chance(0.5)) m.structures.push({ kind: 'table', x: rx + 3, y: side === 'n' ? ry2 + 3 : ry2 + 1, w: 1, h: 1, solid: true })
        if (rng.chance(0.4)) m.structures.push({ kind: 'hotelwindow', x: rx + 2, y: side === 'n' ? ry2 : ry2 + 4, w: 1, h: 1, solid: false })
        if (rng.chance(0.6)) m.structures.push({ kind: 'sconce', x: rx + 2, y: side === 'n' ? ry2 + 2 : ry2 + 2, w: 1, h: 1, solid: false })
      }
      // 南排在 x47..51 留 6 格缺口（庭院竖廊穿过），北排客房 9 间、南排 8 间随机 ±1
      for (let k = 0; k < 8; k++) {
        const rx = 23 + k * 6
        if (rx + 4 > 69) break
        const cx = rx + 2
        guestRoom(rx, 4, cx, 9, 'n')
        if (rx === 47) continue // 庭院竖廊缺口
        if (rng.chance(0.92)) guestRoom(rx, 13, cx, 12, 's')
        // 8% 概率缺一间南排房（墙线保持实墙，增加随机性）
      }

      // ---- 走廊尽头：楼梯/电梯间(北半) + 布草间(南半) x71..74 y4..17，双开门朝走廊 ----
      carveRoom(m, 71, 4, 4, 14)
      wallCol(70, 4, 17)
      m.tiles[idx(m, 70, 10)] = 1; m.tiles[idx(m, 70, 11)] = 1
      m.structures.push({ kind: 'hoteldoor', x: 70, y: 10, w: 1, h: 1, solid: true, data: { open: 0, dbl: 1 } })
      m.structures.push({ kind: 'hoteldoor', x: 70, y: 11, w: 1, h: 1, solid: true, data: { open: 0, dbl: 1 } })
      wallRow(9, 71, 74) // 内部分隔：北=楼梯间(y4..8) 南=布草间(y10..17)
      m.tiles[idx(m, 72, 9)] = 1 // 内部连通门洞
      // v54：楼梯间装饰梯删除（纯装饰不可交互——全游戏只保留 data.climb 攀爬梯）
      m.structures.push({ kind: 'sconce', x: 71, y: 7, w: 1, h: 1, solid: false })
      m.structures.push({ kind: 'dresser', x: 71, y: 13, w: 1, h: 1, solid: true, data: { loot: 1 } })
      m.structures.push({ kind: 'dresser', x: 73, y: 13, w: 1, h: 1, solid: true, data: { loot: 1 } })
      m.structures.push({ kind: 'crate', x: 72, y: 16, w: 1, h: 1, solid: true, data: { loot: 1 } })
      m.structures.push({ kind: 'table', x: 71, y: 16, w: 1, h: 1, solid: true })

      // ---- 宴会厅：大堂南侧独立区域 x4..21 y21..36，双开门经 2 宽门厅连通 ----
      carveRoom(m, 11, 18, 2, 3) // 门厅 y18..20
      carveRoom(m, 4, 21, 18, 16)
      m.structures.push({ kind: 'hoteldoor', x: 11, y: 20, w: 1, h: 1, solid: true, data: { open: 0, dbl: 1 } })
      m.structures.push({ kind: 'hoteldoor', x: 12, y: 20, w: 1, h: 1, solid: true, data: { open: 0, dbl: 1 } })
      m.structures.push({ kind: 'ballroom', x: 13, y: 29, w: 1, h: 1, solid: false, data: { horde: 1, rx: 4, ry: 21, rw: 18, rh: 16 } })
      m.structures.push({ kind: 'chandelier', x: 9, y: 27, w: 1, h: 1, solid: false })
      m.structures.push({ kind: 'chandelier', x: 17, y: 27, w: 1, h: 1, solid: false })
      // 宴会长桌沿墙 + 镜墙
      m.structures.push({ kind: 'table', x: 6, y: 22, w: 2, h: 1, solid: true })
      m.structures.push({ kind: 'table', x: 10, y: 22, w: 2, h: 1, solid: true })
      m.structures.push({ kind: 'table', x: 14, y: 22, w: 2, h: 1, solid: true })
      m.structures.push({ kind: 'mirror', x: 5, y: 35, w: 1, h: 2, solid: true })
      m.structures.push({ kind: 'mirror', x: 20, y: 35, w: 1, h: 2, solid: true })
      for (const [sx, sy] of [[4, 25], [4, 31], [21, 25], [21, 31]] as const)
        m.structures.push({ kind: 'sconce', x: sx, y: sy, w: 1, h: 1, solid: false })

      // ---- 中部庭院 x42..57 y21..34（户外泳池，玻璃门经竖廊 x48..49 可达）----
      carveRoom(m, 48, 12, 2, 9) // 竖廊 y12..20 接主廊 y10..11
      // 围墙环
      wallRow(21, 42, 57); wallRow(34, 42, 57); wallCol(42, 21, 34); wallCol(57, 21, 34)
      m.tiles[idx(m, 48, 21)] = 1 // 玻璃门洞
      m.structures.push({ kind: 'glassdoor', x: 48, y: 21, w: 1, h: 1, solid: true, data: { open: 0 } })
      for (let j = 22; j <= 33; j++)
        for (let i = 43; i <= 56; i++) {
          const ii = idx(m, i, j)
          m.tiles[ii] = 1; m.outdoor[ii] = 1; m.elev[ii] = 3
        }
      // 泳池（中央湿区）+ 庭院灯；v13：深水液体（可下沉游泳）
      for (let j = 25; j <= 29; j++)
        for (let i = 46; i <= 52; i++) { m.wet[idx(m, i, j)] = 1; m.liquid[idx(m, i, j)] = 1 }
      m.lights.push({ x: 44.5, y: 23.5, r: 6, color: '#ffd9a0', flickerSeed: rng.int(1, 999) })
      m.lights.push({ x: 55.5, y: 23.5, r: 6, color: '#ffd9a0', flickerSeed: rng.int(1, 999) })
      m.lights.push({ x: 49.5, y: 32.5, r: 6, color: '#8fb7ff', flickerSeed: rng.int(1, 999) })
      break
    }
    case 'outpost': {
      // v35：据点——完全手工布局（mapgenOutpost.ts），随后跳过 prefab/散点/自动出口等通用管线
      rooms = genOutpost(m, rng, def).map((c) => ({ x: c.cx - 1, y: c.cy - 1, w: 2, h: 2, cx: c.cx, cy: c.cy }))
      break
    }
    default: {
      // v23：Level 6–11 / Level 601 的地形生成器（mapgenDeep.ts）
      rooms = genDeep(m, rng, def, { idx, carveRoom, carveH, carveV, place, placeWallHug })
      break
    }
  }

  // Authored blueprints already contain every floor, room, fixture and exit. Generic BFS
  // uses closed-door edge footprints and would incorrectly fill controlled interiors.
  if (m.settlement) return m
  if (def.gen === 'outpost') appendLegacyStations(m)
  // ---- 预制结构（固定房间/区域，按层级概率植入；只向墙区开洞，不破坏既有通路）----
  placePrefabs(m, rng, def.id, def.skipPrefabs)

  // ---- v7：高度档/台阶/蹲伏通道（地形之后、连通校验之前执行）----
  applyElevation(m, rng, def, rooms.length ? { x: rooms[0].cx, y: rooms[0].cy } : { x: 2, y: 2 })
  // ---- v7：室外场景（小巷/通风井/窗景/庭院，同样在连通校验之前）----
  // v8：室外改造先于散点生成物执行——挖区/砌墙避让既有结构，散点随后避让室外瓦片
  applyOutdoor(m, rng, def, rooms.length ? { x: rooms[0].cx, y: rooms[0].cy } : { x: 2, y: 2 })

  // ---- 层级特色散点生成物（门/窗/桌/吊灯/柜等）----
  scatterFeatures(m, rng, def.id)

  // 通用结构（涂鸦/通风口贴墙放置，避免悬浮；v8：避让室外瓦片）
  // v23：Level 6–11 与 Level 601 的通用散点已由 genDeep 按层级铺设，这里只补少量涂鸦
  const DEEP_GENS: readonly string[] = ['darkhall', 'ocean', 'caves', 'suburb', 'field', 'city', 'library']
  // v54：装饰梯（不可交互）全部删除——uniCount 不再含 ladder；攀爬梯走 addClimbLadder（data.climb）
  const uniCount = def.gen === 'outpost'
    ? { graffiti: 0, crate: 0, corpse: 0, vent: 0 } // 据点：一切结构设计好，不走通用散点
    : DEEP_GENS.includes(def.gen)
    ? { graffiti: def.id === 8 ? 0 : 5, crate: 0, corpse: 0, vent: 0 }
    : { graffiti: 8, crate: 4, corpse: 3, vent: 3 }
  for (const [k, n] of Object.entries(uniCount)) {
    for (let i = 0; i < n; i++) {
      if (k === 'graffiti') placeWallHug(m, rng, 'graffiti', { lore: rng.int(0, 5) })
      else if (k === 'crate') place(m, rng, 'crate', 1, 1, true, { loot: 1 })
      else if (k === 'corpse') place(m, rng, 'corpse', 1, 1, false, { loot: 1 })
      else placeWallHug(m, rng, 'vent')
    }
  }
  // L0 荧光灯阵列 + 湿地毯
  if (def.gen === 'rooms') {
    for (let i = 0; i < 10; i++) place(m, rng, 'lightgrid', 2, 1, false)
    for (let i = 0; i < 14; i++) {
      const p = randomFloor(m, rng)
      for (let j = 0; j < 4; j++) {
        const wx = p.x + rng.int(-1, 1), wy = p.y + rng.int(-1, 1)
        if (m.tiles[idx(m, wx, wy)] === 1) m.wet[idx(m, wx, wy)] = 1
      }
    }
  }
  // 旱虾（Entity 20）：仅在 L1–L5 的潮湿地板上概率生成（L0 不生成）；
  // L3/L4 原本无湿区——各补 1–2 块湿地供其栖息
  if (def.id >= 3 && def.id <= 5) {
    if (def.id !== 5) {
      for (let i = 0, n = rng.int(1, 2); i < n; i++) {
        const p = randomFloor(m, rng)
        for (let j = 0; j < 5; j++) {
          const wx = p.x + rng.int(-1, 1), wy = p.y + rng.int(-1, 1)
          if (m.tiles[idx(m, wx, wy)] === 1) m.wet[idx(m, wx, wy)] = 1
        }
      }
    }
    if (rng.chance(0.6)) {
      const wets: { x: number; y: number }[] = []
      for (let y = 0; y < m.h; y++)
        for (let x = 0; x < m.w; x++)
          if (m.tiles[idx(m, x, y)] === 1 && m.wet[idx(m, x, y)] === 1) wets.push({ x, y })
      for (let k = 0, n = Math.min(wets.length, rng.int(1, 2)); k < n; k++) {
        const s = wets[rng.int(0, wets.length - 1)]
        m.entities.push(makeEntity('dryshrimp', s.x + 0.5, s.y + 0.5))
      }
    }
  }
  // 火盐晶体（Object 15）：前五个层级（L0–L4）的角落产生；有限层 L3/L4 在此放置（L0–L2 由各自无限生成器负责）
  if (def.id >= 3 && def.id <= 4 && rng.chance(0.35)) {
    for (let t = 0; t < 40; t++) {
      const x = rng.int(2, m.w - 3), y = rng.int(2, m.h - 3)
      if (m.tiles[idx(m, x, y)] !== 1) continue
      const walls =
        (m.tiles[idx(m, x + 1, y)] !== 1 ? 1 : 0) + (m.tiles[idx(m, x - 1, y)] !== 1 ? 1 : 0) +
        (m.tiles[idx(m, x, y + 1)] !== 1 ? 1 : 0) + (m.tiles[idx(m, x, y - 1)] !== 1 ? 1 : 0)
      if (walls < 2) continue
      m.items.push({ id: Date.now() % 100000 + rng.next(), type: 'firesalt', x: x + 0.5, y: y + 0.5 })
      break
    }
  }

  // 出生点（强制正常高度室内可达区）
  const sp = rooms.length ? { x: rooms[0].cx, y: rooms[0].cy } : randomFloor(m, rng)
  m.spawn = sp
  let guard = 0
  while (tileAt(m, m.spawn.x, m.spawn.y) !== 1 && guard++ < 50) {
    m.spawn.x++
    if (m.spawn.x >= m.w - 2) { m.spawn = randomFloor(m, rng); break }
  }
  if (tileAt(m, m.spawn.x, m.spawn.y) !== 1) m.spawn = randomFloor(m, rng)
  // 出生瓦片必须是正常高度室内地板；不满足则螺旋外扩找最近合规瓦片
  if (m.elev[idx(m, m.spawn.x, m.spawn.y)] !== 0 || m.outdoor[idx(m, m.spawn.x, m.spawn.y)] !== 0 || tileAt(m, m.spawn.x, m.spawn.y) !== 1) {
    let found = false
    for (let r = 1; r < 14 && !found; r++)
      for (let j = -r; j <= r && !found; j++)
        for (let i = -r; i <= r && !found; i++) {
          const x = m.spawn.x + i, y = m.spawn.y + j
          if (x < 1 || y < 1 || x >= m.w - 1 || y >= m.h - 1) continue
          const ii = idx(m, x, y)
          if (m.tiles[ii] === 1 && m.elev[ii] === 0 && m.outdoor[ii] === 0 && !isSolidStruct(m, x, y)) {
            m.spawn = { x, y }; found = true
          }
        }
    if (!found) { m.elev[idx(m, m.spawn.x, m.spawn.y)] = 0; m.outdoor[idx(m, m.spawn.x, m.spawn.y)] = 0; m.step[idx(m, m.spawn.x, m.spawn.y)] = 0 }
  }

  // 连通性：从出生点 BFS（含台阶/跳跃通行规则：上行 ≤1.35m 可达，下行任意）
  const reach = new Uint8Array(size * size)
  const bfs = () => {
    // Only the main floor blocks this flood. Recompute on every invocation:
    // flattening/repairing terrain can also change nearby door colliders.
    const blocked = Number.isInteger(m.spawn.x) && Number.isInteger(m.spawn.y)
      ? generationObstacles(size, size, m.structures, 0, s => structColliders(s, m)) : null
    reach.fill(0)
    const q: [number, number][] = [[m.spawn.x, m.spawn.y]]
    reach[m.spawn.y * size + m.spawn.x] = 1
    while (q.length) {
      const [x, y] = q.pop()!
      const h0 = tileH(m, x, y)
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
        const nx = x + dx, ny = y + dy, ii = ny * size + nx
        if (nx < 0 || ny < 0 || nx >= size || ny >= size || reach[ii]) continue
        if (m.tiles[ii] !== 1 || (blocked ? blocked[ii] !== 0 : solidStructAtFloor(m, nx, ny, 0)
          && !m.structures.some(s => s.solid && (s.floor ?? 0) === 0 && ['hoteldoor', 'rollerdoor', 'glassdoor', 'bargate'].includes(s.kind)
            && nx >= s.x && nx < s.x + s.w && ny >= s.y && ny < s.y + s.h))) continue
        if (tileH(m, nx, ny) - h0 > JUMP_REACH) continue // 高差>跳跃能力 不可达
        reach[ii] = 1; q.push([nx, ny])
      }
    }
  }
  bfs()
  // 高台/低洼孤岛回填：不可达的非正常高度瓦片压平为正常高度后重算连通
  {
    let flattened = false
    for (let i = 0; i < size * size; i++) {
      if (m.tiles[i] === 1 && !reach[i] && (m.elev[i] === 1 || m.elev[i] === 2 || m.step[i] !== 0)) {
        m.elev[i] = 0; m.step[i] = 0; m.crawl[i] = 0; flattened = true
      }
    }
    if (flattened) bfs()
  }
  // v25：返回 null 版本（供栖息地过滤判定「无符合瓦片」），reachFloor 保留出生点兜底
  const reachFloorTry = (margin = 0, opts: { indoor?: boolean; outdoor?: boolean; anyHabitat?: boolean; waterOk?: boolean } = {}): { x: number; y: number } | null => {
    for (let t = 0; t < 600; t++) {
      const x = rng.int(1, size - 2), y = rng.int(1, size - 2)
      const ii = y * size + x
      if (reach[ii] && tileAt(m, x, y) === 1) {
        if (m.stair[ii] !== 0 || (m.liquid[ii] !== 0 && !opts.waterOk)) continue // v13：楼梯坡道/液体上不放置出口/实体/物品（v25：水生实体豁免水域）
        if (opts.indoor && (m.elev[ii] !== 0 || m.outdoor[ii] !== 0 || m.crawl[ii] !== 0)) continue
        // v25：室外栖息地（小巷/街道/田野，outdoor=1）；水生实体额外接受水域（liquid≠0，如 L7 海面）
        if (opts.outdoor && m.outdoor[ii] !== 1 && !(opts.waterOk && m.liquid[ii] !== 0)) continue
        // v25：any 栖息地=室内正常高度 + 室外地面皆可，但不上高台/低洼/蹲伏通道
        if (opts.anyHabitat && ((m.elev[ii] !== 0 && m.elev[ii] !== 3) || m.crawl[ii] !== 0)) continue
        if (margin && Math.hypot(x - m.spawn.x, y - m.spawn.y) < margin) continue
        return { x, y }
      }
    }
    return null
  }
  const reachFloor = (margin = 0, opts: { indoor?: boolean; outdoor?: boolean; anyHabitat?: boolean; waterOk?: boolean } = {}): { x: number; y: number } =>
    reachFloorTry(margin, opts) ?? { ...m.spawn }
  // v8：先校验 prefab 可达性（此时房间开放地板仍在，走廊补救有效），再做孤岛回填
  ensurePrefabsReachable(m, reach, bfs)

  // 未能连通的孤立地板填成墙，避免误生成内容（室外景观保留）；
  // v8 修复：任何结构占据的瓦片一律跳过——BFS 不会踏入实心结构瓦片（reach=0），
  // 若回填会把箱子/前台/立柱等脚下地板变成墙，造成视觉嵌墙与 prefab 孤岛。
  const structMark = new Uint8Array(size * size)
  for (const s of m.structures) {
    for (let j = Math.max(0, Math.floor(s.y)); j <= Math.min(size - 1, Math.floor(s.y + s.h - 1e-6)); j++)
      for (let i = Math.max(0, Math.floor(s.x)); i <= Math.min(size - 1, Math.floor(s.x + s.w - 1e-6)); i++)
        structMark[j * size + i] = 1
  }
  for (let i = 0; i < size * size; i++) {
    // v54：楼梯坡道格不回填——2F→3F 坡道（base=FLOOR_H）的瓦片在 2D 主层 BFS 里必然不可达
    //（坡道高度 >JUMP_REACH），回填会把坡道填成墙、毁掉三层楼梯间（Gamma 基地）
    if (m.tiles[i] === 1 && !reach[i] && m.outdoor[i] === 0 && !structMark[i] && m.stair[i] === 0) m.tiles[i] = 2
  }
  // 回填后重算连通（结构瓦片已保全），供出口/实体/物品选址
  bfs()

  // 结构包围盒-墙体碰撞修正（防容器/收纳箱卡墙；v8：微移失败则移除）
  fixStructEmbedding(m)

  // 门必须依附墙线（两侧墙/两侧地板）；不满足的门结构移除（保留门洞通行）
  validateDoors(m)

  // v55（任务8）：床类床头靠墙——bed/bunkbed/hospitalbed 未显式 data.deg 的，
  // 按床格短端邻墙自动补朝向（楼层带感知：1F/2F 床查对应 upWall/upWall2）
  for (const s of m.structures) {
    if (s.kind !== 'bed' && s.kind !== 'bunkbed' && s.kind !== 'hospitalbed') continue
    if (s.data?.deg !== undefined) continue
    const wa = s.floor === 1 ? m.upWall : s.floor === 2 ? m.upWall2 : null
    const isWall = (tx: number, ty: number) =>
      tx < 0 || ty < 0 || tx >= m.w || ty >= m.h ? false : wa ? wa[ty * m.w + tx] === 1 : m.tiles[ty * m.w + tx] !== 1
    const d = bedHeadDeg(isWall, s.x, s.y, s.w, s.h)
    if (d !== null) s.data = { ...s.data, deg: d }
  }

  // ---- v13：多层结构（楼梯/电梯/梯子/上层房间）+ 浅水洼；含跨层连通校验与回滚 ----
  applyMultiFloor(m, rng, def)

  // v29a：水生层（L7 海洋）——生成点位接受水域瓦片。
  // 此前 reachFloorTry 一律排除 liquid 瓦片，而 L7 全图 97% 是海：出口/物品/光源全部走出生点兜底，
  // 堆叠在同一格（坐标完全相同的「生成堆积」）；水生层改为允许水上点位，分布均匀且贴海。
  const aquaticLv = def.aquatic === true

  // 出口（随机选 1 个主要出口 + 偶尔第二个；据点跳过——出口由生成器手工布置）
  // v51：回程电梯（elevatorshaft →L3）从正常掷骰中剔除，作为额外出口单独放置——绝不挤占进程出口
  const liftBack = def.exits.filter((e) => e.kind === 'elevatorshaft' && e.dest === 3)
  // L11 的乡间小路是确定性的边缘入口，不参与普通出口抽签；下方会在城市南缘雕出实际小径。
  const normalExitDefs = def.exits.filter((e) =>
    !(e.kind === 'elevatorshaft' && e.dest === 3)
    && !(def.id === 11 && e.kind === 'countrypath'))
  const exitDefs = def.allExits ? [...normalExitDefs] : rng.shuffle([...normalExitDefs])
  // v23：结局层（Level 601）必须真假两扇门同时存在
  const nExits = def.gen === 'outpost' ? 0 : def.allExits ? exitDefs.length : (rng.chance(0.35) ? 2 : 1)
  for (let i = 0; i < nExits; i++) {
    const p = reachFloor(12, { indoor: true, waterOk: aquaticLv }) // 出口强制正常高度室内可达区（水生层可落于开阔海面）
    m.exits.push({ def: exitDefs[i], x: p.x, y: p.y, discovered: false })
  }
  if (def.id === 11) {
    const country = def.exits.find((e) => e.kind === 'countrypath')
    if (country) {
      // genCity 的最后一排建筑止于 y=74；在南缘清出一条真正连到地图边界的 5m 宽乡间小径。
      const px = Math.floor(size / 2), y0 = size - 13, y1 = size - 3
      m.structures = m.structures.filter((s) =>
        s.x + s.w <= px - 2 || s.x >= px + 3 || s.y + s.h <= y0 || s.y >= size)
      for (let y = y0; y <= y1; y++) for (let x = px - 2; x <= px + 2; x++) {
        const ii = y * size + x
        m.tiles[ii] = 1; m.outdoor[ii] = 1; m.elev[ii] = 3
        m.wet[ii] = 0; m.liquid[ii] = 0; m.step[ii] = 0; m.crawl[ii] = 0
      }
      m.exits.push({ def: country, x: px, y: y1, discovered: false })
    }
  }
  if (def.gen !== 'outpost') // v51：额外回程电梯（普通地面放置，L4/L5 侧无嵌墙要求）
    for (const elev of liftBack) {
      const p = reachFloor(12, { indoor: true, waterOk: aquaticLv })
      m.exits.push({ def: elev, x: p.x, y: p.y, discovered: false })
    }

  // 光源
  const lightCount = Math.floor(size * size * def.lightDensity * (1 + rng.next()))
  for (let i = 0; i < lightCount; i++) {
    const p = aquaticLv ? reachFloor(0, { waterOk: true }) : reachFloor()
    m.lights.push({ x: p.x + 0.5, y: p.y + 0.5, r: rng.range(3, 5.5), color: def.palette.light, flickerSeed: rng.next() * 100 })
  }
  // 出口光源
  // v54：设计模式重制的据点可能已把出口灯拖到自定义位置（applyDesignPatch 移动出口后，
  // 玩家拖过的出口灯随 lightAdd 落地）——出口 1.5 格内已有同色出口灯时跳过自动补灯，避免重复
  for (const e of m.exits) {
    if (m.lights.some((l) => l.color === '#f5e37a' && Math.hypot(l.x - (e.x + 0.5), l.y - (e.y + 0.5)) < 1.5)) continue
    m.lights.push({ x: e.x + 0.5, y: e.y + 0.5, r: 3, color: '#f5e37a', flickerSeed: rng.next() * 100 })
  }
  // 壁灯/灯阵附加光
  for (const s of m.structures) {
    if (s.kind === 'sconce' || s.kind === 'lightgrid')
      m.lights.push({ x: s.x + s.w / 2, y: s.y + s.h / 2, r: 3.5, color: def.palette.light, flickerSeed: rng.next() * 100 })
  }

  // L0 特殊房间：停电区（抹除区域灯光）+ 红房间（灯光染红）
  if (def.gen === 'rooms') {
    const bc = reachFloor(6)
    m.lights = m.lights.filter((l) => Math.hypot(l.x - bc.x, l.y - bc.y) > 5.5)
    const rc = reachFloor(8)
    let touched = false
    for (const l of m.lights) if (Math.hypot(l.x - rc.x, l.y - rc.y) < 4.5) { l.color = '#ff2a1a'; touched = true }
    if (!touched) m.lights.push({ x: rc.x + 0.5, y: rc.y + 0.5, r: 4, color: '#ff2a1a', flickerSeed: rng.next() * 100 })
  }

  // 实体（黑暗伏击者优先生成在无光角落；趋光者生成在远离光源处）
  // v25：按 EntityDef.habitat 过滤候选瓦片——indoor=室内（outdoor=0 且正常高度）、outdoor=室外（outdoor=1）、
  // any=随意（仅排除楼梯坡道/液体）。无符合瓦片时降级 any 并在 m.habitatFallback 计数告警。
  const habMiss: Record<string, number> = {}
  for (const se of def.entities) {
    const n = rng.int(se.min, se.max)
    const edef = ENTITIES[se.type]
    const hab = edef?.habitat ?? 'any'
    const habOpts = hab === 'indoor' ? { indoor: true as const } : hab === 'outdoor' ? { outdoor: true as const, waterOk: edef?.aquatic === true } : { anyHabitat: true as const, waterOk: aquaticLv }
    const pickSpot = (): { x: number; y: number } => {
      let p = reachFloorTry(10, habOpts)
      if (!p && hab !== 'any') { // 降级：本层无符合栖息地的瓦片（如车库小巷生成失败）
        const key = `${se.type}:${hab}`
        habMiss[key] = (habMiss[key] ?? 0) + 1
        p = reachFloorTry(10, { anyHabitat: true }) ?? reachFloorTry(10, { indoor: true })
      }
      return p ?? { ...m.spawn }
    }
    for (let i = 0; i < n; i++) {
      let p = pickSpot()
      if (edef?.darkAmbusher) {
        for (let t = 0; t < 14; t++) {
          const q = pickSpot()
          const dark = !m.lights.some((l) => Math.hypot(l.x - q.x - 0.5, l.y - q.y - 0.5) < l.r)
          if (dark) { p = q; break }
        }
      }
      m.entities.push(makeEntity(se.type, p.x + 0.5, p.y + 0.5))
    }
    // 派对客永不落单：同一批生成的 2–4 只聚成一群，并在群边布置诱饵（蛋糕/海报/大红旗）。
    // 只用独立的确定性小 RNG（按领头者坐标派生），不消耗主 rng——本层其余生成结果与旧版完全一致。
    if (se.type === 'partygoer' && n > 0) placePartyPack(m, m.entities.slice(-n))
  }
  if (Object.keys(habMiss).length > 0) {
    m.habitatFallback = habMiss
    console.warn(`[habitat] L${def.id} 无符合瓦片，降级 any：${Object.entries(habMiss).map(([k, v]) => `${k}×${v}`).join(' ')}`)
  }

  // 物品（独特 + 通用混合）
  // v23 容器化：itemCount 的一部分不再直接丢在地上，而是预先装进本层的容器
  // （箱子/柜子/储物柜/工具箱/行李箱/冰箱/信箱/木桶/保险箱……），需要搜索才能拿到。
  const nItems = rng.int(def.itemCount[0], def.itemCount[1])
  const pool = [...def.items, ...UNIVERSAL_ITEMS]
  let iid = 1
  const bias = def.containerBias ?? 0.45
  const containers = m.structures.filter((s) => s.data?.loot === 1 && CONTAINER_KINDS.includes(s.kind))
  const nInContainer = containers.length ? Math.min(Math.round(nItems * bias), containers.length * 3) : 0
  for (let i = 0; i < nItems - nInContainer; i++) {
    const t0 = rng.weighted(pool.map((p) => ({ v: p.type, w: p.w })))
    const t = t0 === 'almond' && rng.chance(0.1) ? 'cashew' : t0 // v32：腰果水 1/10 概率替代杏仁水
    const p = reachFloor(3, aquaticLv ? { waterOk: true } : {})
    m.items.push({ id: iid++, type: t, x: p.x + 0.5, y: p.y + 0.5, z: waterItemZ(m, p.x, p.y, t) })
  }
  for (let i = 0; i < nInContainer; i++) {
    const t0 = rng.weighted(pool.map((p) => ({ v: p.type, w: p.w })))
    const t = t0 === 'almond' && rng.chance(0.1) ? 'cashew' : t0 // v32：腰果水 1/10 概率替代杏仁水
    const c = containers[rng.int(0, containers.length - 1)]
    const cur = Array.isArray(c.data!.lootItems) ? (c.data!.lootItems as string[]) : []
    if (cur.length >= 4) continue
    c.data = { ...c.data, lootItems: [...cur, t] }
  }
  // 保证每层至少 1 盘磁带（据点除外：无任何凭空物品）
  if (def.gen !== 'outpost' && !m.items.some((it) => it.type === 'tape')) {
    const p = reachFloor(8, { indoor: true, waterOk: aquaticLv })
    m.items.push({ id: iid++, type: 'tape', x: p.x + 0.5, y: p.y + 0.5, z: waterItemZ(m, p.x, p.y, 'tape') })
  }

  // v26：悬挂生成物放置校验——必须依附有天花板的瓦片，同瓦片不重叠（冲突就近移位或取消）
  fixHanging(m)

  return m
}

// ================= v7：高度档 / 台阶坡道 / 蹲伏低通道 =================
// 在基础地形、预制结构与散点生成物之后、连通校验之前执行。
// 层级主题：L1 下沉检修沟+高台车位；L2 蹲伏低通道+高维修平台；L3 电缆沟+发电机高台；
//           L4 高文件柜顶（跳上）；L5 大堂挑高+下沉舞池；L0 平地。

const encStep = (dir: number, lo: number, hi: number) => dir | (lo << 3) | (hi << 5)

function floorNoStruct(m: GameMap, x: number, y: number): boolean {
  return x >= 0 && y >= 0 && x < m.w && y < m.h && m.tiles[idx(m, x, y)] === 1 && !isSolidStruct(m, x, y)
}

// 在地图开阔区找 w×h 全地板（无实心结构）矩形；ring=true 时外圈 1 格也须全地板（保证台阶外侧衔接）
function findOpenRect(m: GameMap, rng: RNG, w: number, h: number, ring = false): { x: number; y: number } | null {
  for (let t = 0; t < 500; t++) {
    const x = rng.int(2, m.w - w - 2)
    const y = rng.int(2, m.h - h - 2)
    let ok = true
    for (let j = y - (ring ? 1 : 0); j < y + h + (ring ? 1 : 0) && ok; j++)
      for (let i = x - (ring ? 1 : 0); i < x + w + (ring ? 1 : 0) && ok; i++)
        if (!floorNoStruct(m, i, j)) ok = false
    if (ok) return { x, y }
  }
  return null
}

// 区域盖章高度档（允许覆盖结构瓦片：结构模型按地面高度偏移渲染）
function stampElev(m: GameMap, x: number, y: number, w: number, h: number, e: number) {
  for (let j = y; j < y + h; j++)
    for (let i = x; i < x + w; i++)
      if (m.tiles[idx(m, i, j)] === 1) m.elev[idx(m, i, j)] = e
}

// 下沉沟（1 格宽，两端台阶平滑连接正常地面）
function stampTrench(m: GameMap, rng: RNG, lenMin: number, lenMax: number) {
  const horiz = rng.chance(0.5)
  const len = rng.int(lenMin, lenMax)
  const spot = findOpenRect(m, rng, horiz ? len + 2 : 1, horiz ? 1 : len + 2)
  if (!spot) return false
  const { x, y } = spot
  if (horiz) {
    stampElev(m, x + 1, y, len, 1, 1)
    m.step[idx(m, x, y)] = encStep(2, 1, 0) // 西端：向 -x 上坡（低侧=沟）
    m.step[idx(m, x + len + 1, y)] = encStep(1, 1, 0) // 东端：向 +x 上坡
  } else {
    stampElev(m, x, y + 1, 1, len, 1)
    m.step[idx(m, x, y)] = encStep(4, 1, 0) // 北端：向 -y 上坡
    m.step[idx(m, x, y + len + 1)] = encStep(3, 1, 0) // 南端：向 +y 上坡
  }
  return true
}

// 高台（边缘一枚台阶，台面上放一件奖励品）
function stampPlatform(m: GameMap, rng: RNG, wMin: number, wMax: number, hMin: number, hMax: number, loots: string[]) {
  const w = rng.int(wMin, wMax), h = rng.int(hMin, hMax)
  // 优先带 1 格地板外圈的位置（台阶衔接更自然），找不到则放宽
  const spot = findOpenRect(m, rng, w, h, true) ?? findOpenRect(m, rng, w, h, false)
  if (!spot) return false
  const { x, y } = spot
  stampElev(m, x, y, w, h, 2)
  // 台阶放在西边缘中点（向 +x 上坡到台面，西缘衔接室外平地）
  m.step[idx(m, x, y + (h >> 1))] = encStep(1, 0, 2)
  // 台面奖励（高台专属战利品，引诱跳跃）
  const t = rng.pick(loots)
  m.items.push({ id: 950000 + m.items.length * 7, type: t, x: x + w / 2, y: y + h / 2 })
  return true
}

// 跳跃孤岛高台（无台阶，仅跳跃可上：L4 文件柜顶）
function stampJumpIsle(m: GameMap, rng: RNG, loots: string[]) {
  const w = rng.chance(0.4) ? 2 : 1
  const spot = findOpenRect(m, rng, w, 1, true) ?? findOpenRect(m, rng, w, 1, false)
  if (!spot) return false
  stampElev(m, spot.x, spot.y, w, 1, 2)
  const t = rng.pick(loots)
  m.items.push({ id: 950000 + m.items.length * 7, type: t, x: spot.x + w / 2, y: spot.y + 0.5 })
  return true
}

// 蹲伏低通道：走廊段盖章 crawl（头顶风道，未蹲伏不可进入；2 格宽走廊同样适用）
function markCrawlSegment(m: GameMap, rng: RNG): boolean {
  const isFloor = (x: number, y: number) => m.tiles[idx(m, x, y)] === 1
  for (let t = 0; t < 80; t++) {
    const x = rng.int(2, m.w - 5)
    const y = rng.int(2, m.h - 3)
    if (!floorNoStruct(m, x, y) || m.elev[idx(m, x, y)] !== 0 || m.crawl[idx(m, x, y)]) continue
    const horiz = isFloor(x - 1, y) && isFloor(x + 1, y)
    const vert = !horiz && isFloor(x, y - 1) && isFloor(x, y + 1)
    if (!horiz && !vert) continue
    const len = rng.int(2, 3)
    let ok = true
    for (let k = 1; k < len; k++) {
      const nx = horiz ? x + k : x, ny = horiz ? y : y + k
      if (!floorNoStruct(m, nx, ny) || m.elev[idx(m, nx, ny)] !== 0) { ok = false; break }
    }
    if (!ok) continue
    for (let k = 0; k < len; k++) m.crawl[idx(m, horiz ? x + k : x, horiz ? y : y + k)] = 1
    return true
  }
  return false
}

function applyElevation(m: GameMap, rng: RNG, def: LevelDef, spawnCand: { x: number; y: number }) {
  switch (def.gen) {
    case 'rooms': break // L0 平地
    case 'garage': { // L1：下沉检修沟 ×3 + 高台车位 ×2
      for (let i = 0; i < 3; i++) stampTrench(m, rng, 8, 14)
      for (let i = 0; i < 2; i++) stampPlatform(m, rng, 3, 4, 2, 3, ['battery', 'canned', 'bandage', 'gas'])
      break
    }
    case 'pipes': { // L2：蹲伏低通道 ×3 + 高维修平台 ×3（v41：死代码——L2 已无限化，见 genOnce 同名分支注）
      for (let i = 0; i < 3; i++) markCrawlSegment(m, rng)
      for (let i = 0; i < 3; i++) stampPlatform(m, rng, 2, 3, 2, 3, ['wrench', 'battery', 'bandage'])
      break
    }
    case 'grid': { // L3：电缆沟 ×3（长）+ 发电机高台 ×2
      for (let i = 0; i < 3; i++) stampTrench(m, rng, 10, 18)
      for (let i = 0; i < 2; i++) stampPlatform(m, rng, 3, 4, 2, 2, ['fuse', 'battery', 'capacitor'])
      break
    }
    case 'office': { // L4：少量高文件柜顶（无台阶，跳跃可上）
      for (let i = 0; i < 6; i++) stampJumpIsle(m, rng, ['almond', 'stapler', 'coffee'])
      break
    }
    case 'hotel': { // L5：大堂挑高 + 下沉舞池（舞池边缘台阶；布局由 gen 固定，读 ballroom 标记矩形）
      // 大堂挑高（gen 'hotel' 固定大堂 4,4,18,14）
      for (let j = 4; j < 18; j++)
        for (let i = 4; i < 22; i++)
          if (m.tiles[idx(m, i, j)] === 1) m.ceiling[idx(m, i, j)] = 1
      // 下沉舞池：读 gen 放置的 ballroom 标记矩形（宴会厅内缩 2 圈作池，北缘近双开门处台阶）
      const br = m.structures.find((s) => s.kind === 'ballroom' && typeof s.data?.rw === 'number')
      if (br) {
        const bx = br.data!.rx as number, by = br.data!.ry as number
        const bw = br.data!.rw as number, bh = br.data!.rh as number
        // 北缘留 2 排门厅平地、南缘留 1 排（镜墙），池区 = 内缩
        const px = bx + 1, py = by + 3, pw = bw - 2, ph = bh - 5
        let ok = true
        for (let j = py; j < py + ph && ok; j++)
          for (let i = px; i < px + pw && ok; i++)
            if (m.tiles[idx(m, i, j)] !== 1 || isSolidStruct(m, i, j)) ok = false
        if (ok) {
          stampElev(m, px, py, pw, ph, 1)
          // 北缘台阶 ×2（向 -y 上坡出池，近双开门纵线 x11..15）
          for (const sx2 of [bx + 7, bx + 11]) {
            if (floorNoStruct(m, sx2, py)) m.step[idx(m, sx2, py)] = encStep(4, 1, 0)
          }
        }
      }
      void spawnCand
      break
    }
  }
}

// ================= v7：室外场景 =================
// L1 卷帘门外小巷（可经门到达）；L2 蹲伏管道通通风井露天；L4 半透玻璃窗外雾中城市（仅观察）；
// L5 庭院泳池（玻璃门可达）+ 客房窗夜景（仅观察）。
// 室外瓦片：outdoor=1, elev=3；无天花板、天空盒、远景楼群剪影由渲染层处理。

// 在室内开阔区圈出一块室外院落：内 rect 变室外地板，外圈砌墙，南侧中点开一扇门（可交互）
function outdoorRoom(m: GameMap, rng: RNG, w: number, h: number, doorKind: 'rollerdoor' | 'glassdoor', lampColor: string, lamps: number, spawnCand: { x: number; y: number }): boolean {
  for (let t = 0; t < 600; t++) {
    const x = rng.int(3, m.w - w - 5)
    const y = rng.int(3, m.h - h - 5)
    let ok = true
    for (let j = y - 1; j < y + h + 1 && ok; j++)
      for (let i = x - 1; i < x + w + 1 && ok; i++) {
        if (m.tiles[idx(m, i, j)] !== 1) { ok = false; break }
        if (anyStructAt(m, i, j)) { ok = false; break } // v8：含非实心装饰/prefabmark
      }
    if (!ok) continue
    // 避开出生区（8 格内）
    const cx = x + w / 2, cy = y + h / 2
    if (Math.hypot(cx - spawnCand.x, cy - spawnCand.y) < 9) continue
    // 外圈砌墙（保留既有结构瓦片不挖）
    for (let j = y - 1; j < y + h + 1; j++)
      for (let i = x - 1; i < x + w + 1; i++) {
        const isRing = j === y - 1 || j === y + h || i === x - 1 || i === x + w
        if (isRing) m.tiles[idx(m, i, j)] = 2
      }
    // 内 rect：室外地面
    for (let j = y; j < y + h; j++)
      for (let i = x; i < x + w; i++) {
        const ii = idx(m, i, j)
        m.tiles[ii] = 1; m.outdoor[ii] = 1; m.elev[ii] = 3; m.wet[ii] = 0
      }
    // 门：南侧墙中点（1 格，可交互开关）
    const dx = x + (w >> 1), dy = y + h
    m.tiles[idx(m, dx, dy)] = 1
    m.outdoor[idx(m, dx, dy)] = 0
    m.elev[idx(m, dx, dy)] = 0
    m.structures.push({ kind: doorKind, x: dx, y: dy, w: 1, h: 1, solid: true, data: { open: 0 } })
    // 路灯/霓虹灯
    for (let n = 0; n < lamps; n++) {
      const lx = x + 1.5 + rng.next() * (w - 3), ly = y + 1.5 + rng.next() * (h - 3)
      m.lights.push({ x: lx, y: ly, r: 7, color: lampColor, flickerSeed: rng.int(1, 999) })
    }
    return true
  }
  return false
}

// L2：蹲伏管道 → 通风井露天。从任意走廊瓦片向墙侧（虚空）挖 crawl 管道，尽头开 3×3 露天井
function ventShaft(m: GameMap, rng: RNG): boolean {
  const nonFloor = (x: number, y: number) => x < 0 || y < 0 || x >= m.w || y >= m.h || m.tiles[idx(m, x, y)] !== 1
  for (let t = 0; t < 600; t++) {
    const x = rng.int(3, m.w - 9)
    const y = rng.int(5, m.h - 6)
    if (m.tiles[idx(m, x, y)] !== 1 || m.elev[idx(m, x, y)] !== 0 || m.outdoor[idx(m, x, y)] === 1 || anyStructAt(m, x, y)) continue
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
      // (dx,dy) 侧为墙，管道 2 格 + 井区（3×3 + 外围 1 格）必须全是非地板（挖入虚空，不破坏既有地形）
      if (!nonFloor(x + dx, y + dy)) continue
      let ok = true
      for (let k = 1; k <= 2 && ok; k++) if (!nonFloor(x + dx * k, y + dy * k)) ok = false
      const sx = x + dx * 3, sy = y + dy * 3
      for (let j = sy - 2; j <= sy + 2 && ok; j++)
        for (let i = sx - 2; i <= sx + 2 && ok; i++)
          if (!nonFloor(i, j)) ok = false
      if (!ok) continue
      // 挖蹲伏管道（crawl=1，未蹲伏不可通过）
      for (let k = 1; k <= 2; k++) {
        const ii = idx(m, x + dx * k, y + dy * k)
        m.tiles[ii] = 1; m.crawl[ii] = 1
      }
      // 挖露天通风井
      for (let j = sy - 1; j <= sy + 1; j++)
        for (let i = sx - 1; i <= sx + 1; i++) {
          const ii = idx(m, i, j)
          m.tiles[ii] = 1; m.outdoor[ii] = 1; m.elev[ii] = 3
        }
      m.lights.push({ x: sx + 0.5, y: sy + 0.5, r: 6, color: '#b8c4cc', flickerSeed: rng.int(1, 999) })
      return true
    }
  }
  return false
}

// 观察窗外景：找一条室内墙线（一侧室内地板、另一侧 ≥3 格虚空），
// 开 n 扇半透玻璃窗（实心不可通过），窗外挖 3 深室外条带（不可达，作城市/夜景剪影背景）
// v8：全量扫描候选墙线再随机挑选（密集办公室布局下纯随机采样经常找不到合规墙线）；
//     水平/垂直墙线分别扫描（旧版 (±1,0) 方向把条带挖进墙线自身，从未生效）
function windowStrip(m: GameMap, rng: RNG, wins: number, lampColor: string | null): boolean {
  // 候选：墙线起点 (x,y)、走向 (ax,ay)（|a|=1 沿墙）、室内侧法向 (dx,dy)
  const cands: { x: number; y: number; ax: number; ay: number; dx: number; dy: number }[] = []
  const structBlocks = (x: number, y: number) =>
    m.structures.some((s) => (s.solid || s.kind === 'prefabmark') && x >= s.x && x < s.x + s.w && y >= s.y && y < s.y + s.h)
  const nonFloor = (x: number, y: number) => x < 1 || y < 1 || x >= m.w - 1 || y >= m.h - 1 || m.tiles[idx(m, x, y)] !== 1
  const indoorFloor = (x: number, y: number) =>
    x >= 1 && y >= 1 && x < m.w - 1 && y < m.h - 1 && m.tiles[idx(m, x, y)] === 1 && m.outdoor[idx(m, x, y)] !== 1 && !structBlocks(x, y)
  for (let y = 4; y < m.h - 5; y++) {
    for (let x = 4; x < m.w - 5; x++) {
      for (const [ax, ay] of [[1, 0], [0, 1]] as const) { // 墙线走向：水平/垂直
        for (const [dx, dy] of ay === 0 ? [[0, 1], [0, -1]] as const : [[1, 0], [-1, 0]] as const) {
          // 墙线瓦片 (x + k*ax, y + k*ay)，k = -1..wins（两端各多 1 格实墙）
          let ok = true
          for (let k = -1; k <= wins && ok; k++) {
            const wx = x + k * ax, wy = y + k * ay
            if (wx < 2 || wy < 2 || wx >= m.w - 2 || wy >= m.h - 2) { ok = false; break }
            if (m.tiles[idx(m, wx, wy)] === 1) { ok = false; break } // 墙线本身非地板
            // 室内侧：连续地板无实心结构/prefabmark
            if (!indoorFloor(wx + dx, wy + dy)) { ok = false; break }
            // 室外侧 4 格全非地板（3 深条带 + 1 格隔离，保证窗区不可绕行到达）；
            // 条带（d≤3）必须在地图内层，不得压边界墙
            for (let d = 1; d <= 4; d++) {
              const ox = wx - dx * d, oy = wy - dy * d
              if (d <= 3 && (ox < 1 || oy < 1 || ox >= m.w - 1 || oy >= m.h - 1)) { ok = false; break }
              if (!nonFloor(ox, oy)) { ok = false; break }
            }
            if (!ok) break
          }
          // 条带端缘之外（沿轴 k=-2 / k=wins+1）在条带深度内必须全非地板（防止从端部绕入）
          for (const k of [-2, wins + 1]) {
            const ex = x + k * ax, ey = y + k * ay
            for (let d = 0; d <= 3 && ok; d++)
              if (!nonFloor(ex - dx * d, ey - dy * d)) ok = false
          }
          if (ok) cands.push({ x, y, ax, ay, dx, dy })
        }
      }
    }
  }
  if (!cands.length) return false
  const c = rng.pick(cands)
  // 开窗（k = 0..wins-1）
  for (let k = 0; k < wins; k++) {
    const wx = c.x + k * c.ax, wy = c.y + k * c.ay
    m.tiles[idx(m, wx, wy)] = 1
    m.structures.push({ kind: 'glasswin', x: wx, y: wy, w: 1, h: 1, solid: true, data: { view: 1 } })
  }
  // 窗外条带（3 深，含两端各多 1 格）：室外地面，玻璃阻隔不可达
  for (let k = -1; k <= wins; k++)
    for (let d = 1; d <= 3; d++) {
      const ox = c.x + k * c.ax - c.dx * d, oy = c.y + k * c.ay - c.dy * d
      const ii = idx(m, ox, oy)
      m.tiles[ii] = 1; m.outdoor[ii] = 1; m.elev[ii] = 3
    }
  if (lampColor) m.lights.push({ x: c.x + c.ax * wins / 2 - c.dx * 2 + 0.5, y: c.y + c.ay * wins / 2 - c.dy * 2 + 0.5, r: 6, color: lampColor, flickerSeed: rng.int(1, 999) })
  return true
}

function applyOutdoor(m: GameMap, rng: RNG, def: LevelDef, spawnCand: { x: number; y: number }) {
  switch (def.gen) {
    case 'garage': // L1：卷帘门外小巷（灰黄霾天空/路灯，可经门到达）
      if (!outdoorRoom(m, rng, 12, 6, 'rollerdoor', '#ffd28a', 2, spawnCand))
        outdoorRoom(m, rng, 8, 4, 'rollerdoor', '#ffd28a', 1, spawnCand)
      break
    case 'pipes': // L2：蹲伏管道通通风井露天（v41：死代码——L2 已无限化，见 genOnce 同名分支注）
      ventShaft(m, rng)
      break
    case 'office': // L4：半透玻璃窗外雾中城市剪影（仅观察不可达）
      windowStrip(m, rng, 4, null)
      break
    case 'hotel': { // L5：庭院泳池已内置于 gen（玻璃门可达）；此处仅客房窗外夜景（仅观察）
      windowStrip(m, rng, 3, '#3a5a9a')
      break
    }
  }
}

// ================= v13：多层结构（真·楼上楼下）+ 液体浅水洼 =================
// 高度带模型：同一瓦片可同时存在主层地板（tiles=1, z≈0）与上层地板（up=1, z=FLOOR_H）。
// 玩家/实体按脚底 z 所在高度带（bandOfZ）分别碰撞；楼梯（stair 连续坡道）、
// 电梯（lift 交互垂直送达）、梯子（climb 攀爬链接）跨层连接。

// 找一块 w×h 全平地（tiles=1/elev=0/室内/非低通道/非坡道）矩形作为上层楼基；
// 外圈 1 格内不得有 prefabmark（避免压预制结构虚空袋），中心距出生点 ≥ spawnDist
function findZone(m: GameMap, rng: RNG, w: number, h: number, spawnDist: number): { x: number; y: number } | null {
  const cands: { x: number; y: number }[] = []
  for (let y = 2; y + h < m.h - 2; y++)
    for (let x = 2; x + w < m.w - 2; x++) {
      let ok = true
      for (let j = y; j < y + h && ok; j++)
        for (let i = x; i < x + w && ok; i++) {
          const ii = idx(m, i, j)
          if (m.tiles[ii] !== 1 || m.elev[ii] !== 0 || m.outdoor[ii] !== 0 || m.crawl[ii] !== 0 || m.step[ii] !== 0) ok = false
        }
      if (!ok) continue
      for (const s of m.structures) {
        if (s.kind !== 'prefabmark') continue
        if (s.x + s.w > x - 1 && s.x < x + w + 1 && s.y + s.h > y - 1 && s.y < y + h + 1) { ok = false; break }
      }
      if (!ok) continue
      if (Math.hypot(x + w / 2 - m.spawn.x, y + h / 2 - m.spawn.y) < spawnDist) continue
      cands.push({ x, y })
    }
  return cands.length ? rng.pick(cands) : null
}

// 铺设直线楼梯跑道：从 (x,y) 起沿 dir 铺 n 格，从 base 爬到 base+FLOOR_H（每格升 FLOOR_H/n，≤0.65 可直接走上）
// 返回顶端 landing 格坐标（跑道尽头前一格，调用方保证其上一层楼板=1）。
// 跑道格 hi 越过对应带中线的标记该层可站（base=0→up，base=FLOOR_H→up2[v54]：2F→3F 坡道）。
// v54：base 参数支持 2F→3F 坡道（坡道从 2F 楼板起坡：全程 up=1 保留，up2 仅上段标记）
export function stampStairRun(m: GameMap, x: number, y: number, dir: 1 | 2 | 3 | 4, n: number, base = 0): { lx: number; ly: number } {
  const dx = dir === 1 ? 1 : dir === 2 ? -1 : 0
  const dy = dir === 3 ? 1 : dir === 4 ? -1 : 0
  const stepCm = Math.round((FLOOR_H * 100) / n)
  for (let k = 0; k < n; k++) {
    const sx = x + dx * k, sy = y + dy * k
    const ii = idx(m, sx, sy)
    m.tiles[ii] = 1
    m.stair[ii] = encStair(dir, Math.round(base * 100) + stepCm * k, Math.round(base * 100) + stepCm * (k + 1))
    m.step[ii] = 0; m.crawl[ii] = 0; m.elev[ii] = 0
    if (base === 0) {
      if (stepCm * (k + 1) / 100 > BAND_MID) m.up[ii] = 1 // 坡道上半段：上层可行走
      else m.up[ii] = 0
    } else {
      // 2F→3F 坡道（v54）：可站标记按坡道面实际高度带分段——下段（lo<4.5）2F 可站、上段（hi>4.5）3F 可站，
      // 交界格两带均可站（换带连续）；上段不再标记 up=1（其表面已在 3F 高度带，2F 走不上去）
      if (base + stepCm * k / 100 < FLOOR_H + BAND_MID) m.up[ii] = 1
      else m.up[ii] = 0
      if (base + stepCm * (k + 1) / 100 > FLOOR_H + BAND_MID) m.up2[ii] = 1
      else m.up2[ii] = 0
    }
  }
  return { lx: x + dx * n, ly: y + dy * n }
}

// 攀爬梯子：base（主层）↔ top（上层，up=1）。结构非实心，引擎做贴近按住前进的竖直攀爬
function addClimbLadder(m: GameMap, baseX: number, baseY: number, topX: number, topY: number): boolean {
  if (m.tiles[idx(m, baseX, baseY)] !== 1 || isSolidStruct(m, baseX, baseY)) return false
  if (m.up[idx(m, topX, topY)] !== 1) return false
  m.structures.push({
    kind: 'ladder', x: baseX, y: baseY, w: 1, h: 1, solid: false,
    data: { climb: 1, tx: topX, ty: topY },
  })
  return true
}

// ---- L4 废弃办公室：主层 + 上层办公室/档案夹层（楼梯间 + 电梯）----
function buildOfficeUpper(m: GameMap, rng: RNG): boolean {
  let zone: { x: number; y: number } | null = null
  let w = 0, h = 0
  for (const [zw, zh, sd] of [[14, 12, 10], [12, 10, 9], [10, 9, 8]] as const) {
    zone = findZone(m, rng, zw, zh, sd)
    if (zone) { w = zw; h = zh; break }
  }
  if (!zone) return false
  const { x: zx, y: zy } = zone
  for (let j = zy; j < zy + h; j++)
    for (let i = zx; i < zx + w; i++) m.up[idx(m, i, j)] = 1
  for (let i = zx; i < zx + w; i++) { m.upWall[idx(m, i, zy)] = 1; m.upWall[idx(m, i, zy + h - 1)] = 1 }
  for (let j = zy; j < zy + h; j++) { m.upWall[idx(m, zx, j)] = 1; m.upWall[idx(m, zx + w - 1, j)] = 1 }
  // 楼梯间：zone 内沿西墙跑道（+x 上坡 5 格，每格 0.6m），顶到 landing
  let stairOk = false
  let landing: { lx: number; ly: number } | null = null
  for (let ty = zy + 2; ty < zy + h - 2 && !stairOk; ty++) {
    let ok = true
    for (let k = 0; k <= 6; k++) { // 跑道 5 格 + landing 1 格，下层须无实心结构
      if (isSolidStruct(m, zx + 1 + k, ty)) { ok = false; break }
    }
    if (!ok) continue
    landing = stampStairRun(m, zx + 1, ty, 1, 5)
    m.up[idx(m, landing.lx, landing.ly)] = 1
    stairOk = true
  }
  if (!stairOk || !landing) { // 回滚楼板
    for (let j = zy; j < zy + h; j++) for (let i = zx; i < zx + w; i++) { m.up[idx(m, i, j)] = 0; m.upWall[idx(m, i, j)] = 0 }
    return false
  }
  // 内部隔墙：上层两个独立房间（办公室 / 档案室），留 1 格门洞；须在楼梯 landing 以东
  if (w >= 12) {
    const partX = zx + Math.max(w >> 1, 7)
    if (partX < zx + w - 2) {
      const doorY = zy + 2 + rng.int(0, h - 5)
      for (let j = zy + 1; j < zy + h - 1; j++) if (j !== doorY) m.upWall[idx(m, partX, j)] = 1
    }
  }
  // 电梯：zone 内找下层无实心结构格（轿厢 1×1，lift 跨层），不在跑道/landing 上
  for (let t = 0; t < 80; t++) {
    const ex = zx + 1 + rng.int(0, w - 2)
    const ey = zy + 1 + rng.int(0, h - 2)
    if (isSolidStruct(m, ex, ey) || m.stair[idx(m, ex, ey)] !== 0) continue
    if (m.upWall[idx(m, ex, ey)] === 1) continue
    // 邻格须能走出（zone 内非 upWall 非跑道）
    let open = 0
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const)
      if (m.upWall[idx(m, ex + dx, ey + dy)] !== 1 && m.stair[idx(m, ex + dx, ey + dy)] === 0
        && m.up[idx(m, ex + dx, ey + dy)] === 1) open++
    if (open < 2) continue
    m.structures.push({ kind: 'lift', x: ex, y: ey, w: 1, h: 1, solid: false, data: { car: 0, carZ: 0 } })
    return true
  }
  return false // 电梯放不下则整层回滚由调用方处理
}

// ---- L5 恐怖酒店：大堂二楼回廊（楼梯上）+ 布草间夹层（梯子）----
function buildHotelUpper(m: GameMap, rng: RNG): boolean {
  let any = false
  // 大堂 x4..21 y4..17（gen 固定），回廊 = 内圈 2 宽沿墙
  const inLobby = (x: number, y: number) => x >= 4 && x <= 21 && y >= 4 && y <= 17
  // 楼梯跑道：东墙 x20，自 y16 向 -y 爬 5 格至 y12，landing (20,11)
  let stairOk = true
  for (let k = 0; k <= 5; k++) if (isSolidStruct(m, 20, 16 - k)) { stairOk = false; break }
  if (stairOk) {
    for (let y = 4; y <= 17; y++)
      for (let x = 4; x <= 21; x++) {
        const edge = x <= 5 || x >= 20 || y <= 5 || y >= 16
        if (edge) m.up[idx(m, x, y)] = 1
      }
    const land = stampStairRun(m, 20, 16, 4, 5)
    if (inLobby(land.lx, land.ly)) m.up[idx(m, land.lx, land.ly)] = 1
    any = true
  }
  // 布草间夹层：x71..74 y14..17，梯子 base(72,13) → top(72,14)
  const bx0 = 71, by0 = 14
  let linenOk = true
  for (let j = by0; j <= 17 && linenOk; j++)
    for (let i = bx0; i <= 74 && linenOk; i++)
      if (m.tiles[idx(m, i, j)] !== 1) linenOk = false
  if (linenOk && m.tiles[idx(m, 72, 13)] === 1 && !isSolidStruct(m, 72, 13)) {
    for (let j = by0; j <= 17; j++) for (let i = bx0; i <= 74; i++) m.up[idx(m, i, j)] = 1
    if (addClimbLadder(m, 72, 13, 72, 14)) any = true
    else for (let j = by0; j <= 17; j++) for (let i = bx0; i <= 74; i++) m.up[idx(m, i, j)] = 0
  }
  void rng
  return any
}

// ---- L3 电站：高处维修平台（梯子上下）----
function buildGridUpper(m: GameMap, rng: RNG): boolean {
  const zone = findZone(m, rng, 4, 3, 6)
  if (!zone) return false
  // 西邻格作为梯子底（须在楼层地板上且无结构）
  const bx = zone.x - 1, by = zone.y + 1
  if (m.tiles[idx(m, bx, by)] !== 1 || isSolidStruct(m, bx, by)) return false
  for (let j = zone.y; j < zone.y + 3; j++)
    for (let i = zone.x; i < zone.x + 4; i++) m.up[idx(m, i, j)] = 1
  if (!addClimbLadder(m, bx, by, zone.x, by)) {
    for (let j = zone.y; j < zone.y + 3; j++) for (let i = zone.x; i < zone.x + 4; i++) m.up[idx(m, i, j)] = 0
    return false
  }
  return true
}

// ---- L2 管道走廊：浅水洼（不沉没，仅减速+涟漪）----
function addShallowPuddles(m: GameMap, rng: RNG) {
  for (let n = 0; n < 3; n++) {
    for (let t = 0; t < 120; t++) {
      const x = rng.int(2, m.w - 4), y = rng.int(2, m.h - 4)
      let ok = true
      for (let j = y; j < y + 2 && ok; j++)
        for (let i = x; i < x + 2 && ok; i++) {
          const ii = idx(m, i, j)
          if (m.tiles[ii] !== 1 || m.elev[ii] !== 0 || m.outdoor[ii] !== 0 || m.crawl[ii] !== 0
            || m.step[ii] !== 0 || m.liquid[ii] !== 0 || isSolidStruct(m, i, j)) ok = false
        }
      if (!ok) continue
      for (let j = y; j < y + 2; j++) for (let i = x; i < x + 2; i++) m.liquid[idx(m, i, j)] = 2
      break
    }
  }
}

// ---------- 跨层连通 BFS（状态 = 瓦片 × 楼层带）----------
// band0：主层地板（含楼梯坡道）；band1：上层楼板（up=1 且非 upWall）；band2：三层楼板（up2=1 且非 upWall2，v54）。
// 同层四向通行遵守 JUMP_REACH 高差规则；楼梯格可在坡道到达的楼层带间自由切换（连续坡道）；
// lift 格 0↔1 两层互通（电梯交互）；climb 梯子 base↔top 直连。
// v54：步长 S = 楼层数（三层地图 reach 下标 i*3+b；双层保持 i*2+b——EL3A 既有断言不受影响）
export function bfs3D(m: GameMap): Uint8Array {
  const W = m.w, H = m.h
  const S = (m.floors ?? 1) >= 3 ? 3 : 2 // v54：状态步长
  const reach = new Uint8Array(W * H * S)
  const OPENABLE: readonly string[] = ['hoteldoor', 'rollerdoor', 'glassdoor', 'bargate'] // v51：bargate 栅栏门
  const openable = (x: number, y: number, floor: 0 | 1 | 2) =>
    m.structures.some((s) => s.solid && OPENABLE.includes(s.kind) && (s.floor ?? 0) === floor && x >= s.x && x < s.x + s.w && y >= s.y && y < s.y + s.h)
  // During generation geometry is stable for this single flood. Public calls
  // on runtime maps keep their existing spatial-index query semantics.
  const obstacles = !m.inf && !runtimeStructGridMaps.has(m)
    ? ([0, 1, 2] as const).map(band => generationObstacles(W, H, m.structures, band, s => structColliders(s, m))) : null
  const blockedAt = (x: number, y: number, band: 0 | 1 | 2) => obstacles && Number.isInteger(x) && Number.isInteger(y)
    ? obstacles[band][y * W + x] !== 0 : solidStructAtFloor(m, x, y, band) && !openable(x, y, band)
  // 行走高度（null=该层带不可站立）
  const walkH = (x: number, y: number, band: 0 | 1 | 2): number | null => {
    if (x < 0 || y < 0 || x >= W || y >= H) return null
    const i = y * W + x
    const s2 = m.stair[i]
    if (s2 & 7) {
      // v54：上层带走坡道需「坡道服务该带 + 该层楼板可站标记」；主层带不限（高差规则自然拦截悬梯段）
      if (band >= 1 && (!stairServesBand(s2, band, JUMP_REACH) || upAt(m, band as 1 | 2)[i] !== 1)) return null
      if (blockedAt(x, y, band)) return null
      return (((s2 >> 3) & 0x3fff) + ((s2 >> 17) & 0x3fff)) / 200
    }
    if (band === 0) {
      if (m.tiles[i] !== 1) return null
      if (blockedAt(x, y, 0)) return null
      return tileH(m, x, y)
    }
    if (band === 2) { // v54：三层楼板
      if (m.up2[i] !== 1 || m.upWall2[i] === 1) return null
      if (blockedAt(x, y, 2)) return null
      return 2 * FLOOR_H
    }
    if (m.up[i] !== 1 || m.upWall[i] === 1) return null
    if (blockedAt(x, y, 1)) return null
    return FLOOR_H
  }
  const lifts = m.structures.filter((s) => s.kind === 'lift')
  const ladders = m.structures.filter((s) => s.kind === 'ladder' && s.data?.climb)
  const q: [number, number, 0 | 1 | 2][] = [[m.spawn.x, m.spawn.y, 0]]
  reach[(m.spawn.y * W + m.spawn.x) * S] = 1
  while (q.length) {
    const [x, y, b] = q.pop()!
    const h0 = walkH(x, y, b)
    if (h0 === null) continue
    const push = (nx: number, ny: number, nb: 0 | 1 | 2) => {
      const ii = (ny * W + nx) * S + nb
      if (reach[ii]) return
      const nh = walkH(nx, ny, nb)
      if (nh === null || Math.abs(nh - h0) > JUMP_REACH) return
      reach[ii] = 1; q.push([nx, ny, nb])
    }
    // 垂直连接物直达（电梯轿厢/梯子攀爬/楼梯坡道带切换，不受 JUMP_REACH 高差限制）
    const link = (nx: number, ny: number, nb: 0 | 1 | 2) => {
      const ii = (ny * W + nx) * S + nb
      if (reach[ii] || walkH(nx, ny, nb) === null) return
      reach[ii] = 1; q.push([nx, ny, nb])
    }
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) push(x + dx, y + dy, b)
    // 楼梯格：坡道到达的楼层带间自由切换（v54：三段坡道可切 1↔2，一段坡道 0↔1，不跨段）
    if (m.stair[y * W + x] & 7) for (const nb of [0, 1, 2] as const) if (nb !== b) link(x, y, nb)
    // 电梯：同格两层互通
    if (lifts.some((s) => Math.floor(s.x) === x && Math.floor(s.y) === y)) link(x, y, b === 0 ? 1 : 0)
    // 梯子：base↔top
    for (const s of ladders) {
      const tx = s.data!.tx as number, ty = s.data!.ty as number
      if (x === Math.floor(s.x) && y === Math.floor(s.y) && b === 0) link(tx, ty, 1)
      if (x === tx && y === ty && b === 1) link(Math.floor(s.x), Math.floor(s.y), 0)
    }
  }
  return reach
}

// 上层内容（楼板/连通校验通过后放置）：独立房间家具、物品、实体、灯
function placeUpperContent(m: GameMap, rng: RNG, def: LevelDef) {
  const reach = bfs3D(m)
  // 放置前所有可达上层格（放置实心家具不得使其中任何格失联——防止堵死隔墙门洞）
  const prevReachable = new Set<number>()
  for (let i = 0; i < m.w * m.h; i++)
    if (m.up[i] === 1 && m.upWall[i] !== 1 && m.stair[i] === 0 && reach[i * 2 + 1] === 1) prevReachable.add(i)
  const stillConnected = () => {
    const r2 = bfs3D(m)
    for (const i of prevReachable)
      if (!m.structures.some((s) => s.solid && (s.floor ?? 0) === 1 && (i % m.w) >= s.x && (i % m.w) < s.x + s.w && Math.floor(i / m.w) >= s.y && Math.floor(i / m.w) < s.y + s.h)
        && r2[i * 2 + 1] !== 1) return false
    return true
  }
  const freeUp = (x: number, y: number) =>
    m.up[idx(m, x, y)] === 1 && m.upWall[idx(m, x, y)] !== 1 && m.stair[idx(m, x, y)] === 0
    && !m.structures.some((s) => (s.floor ?? 0) === 1 && x >= s.x && x < s.x + s.w && y >= s.y && y < s.y + s.h)
    && reach[(y * m.w + x) * 2 + 1] === 1
  const spots: { x: number; y: number }[] = []
  for (let y = 1; y < m.h - 1; y++)
    for (let x = 1; x < m.w - 1; x++)
      if (freeUp(x, y) && !m.structures.some((s) => s.kind === 'lift' && Math.abs(s.x - x) <= 1 && Math.abs(s.y - y) <= 1)) spots.push({ x, y })
  if (spots.length < 6) return
  const take = () => spots.splice(rng.int(0, spots.length - 1), 1)[0]
  // 上层房间家具（L4 档案夹层=文件柜/桌；L5 回廊/夹层=柜/箱；L3 平台=箱）
  const kinds: [Structure['kind'], number, number, number][] = // [kind, w, h, count]
    def.gen === 'office' ? [['desk', 2, 1, 2], ['cabinet', 1, 1, 2], ['crate', 1, 1, 1]]
      : def.gen === 'hotel' ? [['dresser', 1, 1, 1], ['crate', 1, 1, 1], ['table', 1, 1, 1]]
        : [['crate', 1, 1, 1]]
  for (const [kind, w, h, count] of kinds) {
    for (let n = 0; n < count && spots.length > 4; n++) {
      const p = take()
      if (!p) break
      let ok = w === 1
      if (!ok) { // 2×1 需东侧邻格也空
        ok = spots.some((q) => q.x === p.x + 1 && q.y === p.y)
        if (ok) spots.splice(spots.findIndex((q) => q.x === p.x + 1 && q.y === p.y), 1)
      }
      if (!ok) continue
      m.structures.push({ kind, x: p.x, y: p.y, w, h, solid: true, floor: 1, data: kind === 'crate' || kind === 'dresser' ? { loot: 1 } : undefined })
      if (!stillConnected()) m.structures.pop() // 堵门/断路则撤回该家具
    }
  }
  // 上层物品 ×2-3（z=FLOOR_H 悬浮旋转展示）
  const upItems = def.gen === 'office' ? ['almond', 'coffee', 'stapler', 'tape'] : def.gen === 'hotel' ? ['silverware', 'sedative', 'almond'] : ['fuse', 'battery']
  for (let n = 0; n < 3 && spots.length > 2; n++) {
    const p = take()
    if (!p) break
    m.items.push({ id: 970000 + m.items.length * 13, type: rng.pick(upItems), x: p.x + 0.5, y: p.y + 0.5, z: FLOOR_H })
  }
  // 上层实体 ×1（上层房间有独立威胁；v25：上层房间属室内，跳过 outdoor 栖息地的实体）
  const se = def.entities.find((e) => (ENTITIES[e.type]?.habitat ?? 'any') !== 'outdoor') ?? def.entities[0]
  if (se && spots.length > 1) {
    const p = take()
    if (p) m.entities.push(makeEntity(se.type, p.x + 0.5, p.y + 0.5, FLOOR_H))
  }
  // 上层灯 ×2
  for (let n = 0; n < 2 && spots.length > 0; n++) {
    const p = take()
    if (!p) break
    m.lights.push({ x: p.x + 0.5, y: p.y + 0.5, r: 4, color: def.palette.light, flickerSeed: rng.next() * 100, z: FLOOR_H })
  }
}

function applyMultiFloor(m: GameMap, rng: RNG, def: LevelDef) {
  if (def.gen === 'pipes') addShallowPuddles(m, rng) // v41：死代码——L2 已无限化（见 genOnce 'pipes' 分支注）
  let built = false
  if (def.gen === 'office') built = buildOfficeUpper(m, rng)
  else if (def.gen === 'hotel') built = buildHotelUpper(m, rng)
  else if (def.gen === 'grid') built = buildGridUpper(m, rng)
  if (!built) return
  // 跨层连通校验：所有上层可走格（up=1 非 upWall）必须在 band1 可达；失败则整体回滚
  const reach = bfs3D(m)
  let ok = true, upTiles = 0
  for (let i = 0; i < m.w * m.h; i++) {
    if (m.up[i] === 1 && m.upWall[i] !== 1 && m.stair[i] === 0) {
      upTiles++
      if (!reach[i * 2 + 1]) { ok = false; break }
    }
  }
  if (!ok || upTiles < 8) {
    if ((globalThis as { __DBG_MF?: boolean }).__DBG_MF) {
      const bad: string[] = []
      for (let i = 0; i < m.w * m.h; i++)
        if (m.up[i] === 1 && m.upWall[i] !== 1 && m.stair[i] === 0 && !reach[i * 2 + 1]) bad.push(`${i % m.w},${Math.floor(i / m.w)}`)
      console.warn(`[multifloor] L${def.id} 回滚: ok=${ok} upTiles=${upTiles} bad=${bad.length} ${bad.slice(0, 12).join(' ')}`)
    }
    m.up.fill(0); m.upWall.fill(0); m.stair.fill(0)
    m.structures = m.structures.filter((s) => (s.floor ?? 0) === 0 && s.kind !== 'lift' && !(s.kind === 'ladder' && s.data?.climb))
    m.floors = 1
    return
  }
  m.floors = 2
  placeUpperContent(m, rng, def)
}






