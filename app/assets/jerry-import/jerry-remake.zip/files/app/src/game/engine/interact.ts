import { actualRank, fieldTargets, recordField } from './career'
import {bntgDoorAllowed} from './bntg'
import {TRADE_DEFS} from '../content/tradeDecor'
import type { CareerId } from '../content/settlementTypes'
// v53：交互（scanInteract/doInteract/容器搜索/战利品面板/结构触发伤害/配电箱嗡鸣）——
// 自 engine.ts 拆分，逻辑逐语句搬运；triggerStructs 返回 true 表示本帧已死亡（原 step 的 return）。
import { bandOfZ, bandOfPlayerZ, floorHeight, groundHeightAt, structBlocksSight, l11InteractionBlocked, structColliders, wallAt, FLOOR_H } from '../world/mapgen'
import { canOccupy, PLAYER_RADIUS } from '../core/player'
import { CONTAINERS, CONTAINER_RARE } from '../decorations/containers'
import { DECOR_VIEWS, GRAFFITI_LORE, GRAFFITI_LORE_KIND, BRAILLE_MARKS, GLASSWIN_TEXT } from '../decorations/lore'
import { L3_NOTE_IDS } from '../content/docs'
import { itemName } from '../content/items'
import { WIN_TAPES, NORMAL_LEVELS, levelDefOf } from '../levels'
import { audio } from '../core/audio'
import { forceL7PorchDrop } from './movement'
import { entityBand as entityFloorBand } from './entityAI'
import { makeEntity } from '../entities'
import { skinStealerTalk } from './skinStealerAI'
import { jerryInteractBox } from './jerryAI'
import { look } from '../renderer/shared'
import type { FloorBand, Structure } from '../core/types'
import type { Engine } from '../engine'
import { beginSitting, pickSeat, standUp, seatedEyeHeight, seatedEyeOffset } from './seating'
import { furnitureSeats } from '../content/furnitureSeats'

type DiffMult = { dmg: number; drain: number }

/** 结构交互按玩家到占地矩形最近表面计算；同时返回准星应瞄向的表面点。 */
export function structureSurfacePoint(s: Structure, x: number, y: number): { x: number; y: number; d: number } {
  let sx = Math.max(s.x, Math.min(x, s.x + s.w))
  let sy = Math.max(s.y, Math.min(y, s.y + s.h))
  const d = Math.hypot(sx - x, sy - y)
  // 玩家位于非实心结构占地区域内时没有唯一最近边，瞄准点回退到中心，但表面距离仍为 0。
  if (d < 0.02) { sx = s.x + s.w / 2; sy = s.y + s.h / 2 }
  return { x: sx, y: sy, d }
}

export function structureSurfaceDistance(s: Structure, x: number, y: number): number {
  const sx = Math.max(s.x, Math.min(x, s.x + s.w))
  const sy = Math.max(s.y, Math.min(y, s.y + s.h))
  return Math.hypot(sx - x, sy - y)
}

// ---- v51：L3 配电箱电流嗡鸣（定位音频惯例：按最近配电箱距离逐帧调音量）----
// （原 step 内联段，逐语句搬运）
export function updateElecHum(eng: Engine) {
  const p = eng.player, m = eng.map!
  let elecHum = 0
  // ---- v51：L3 配电箱电流嗡鸣（定位音频惯例：按最近配电箱距离逐帧调音量）----
  if (eng.levelDef.id === 3) {
    let dh = 1e9
    for (const s of m.structures) {
      if (s.kind !== 'elecbox') continue
      const dd = Math.hypot(s.x + 0.5 - p.x, s.y + 0.5 - p.y)
      if (dd < dh) dh = dd
    }
    elecHum = dh < 9 ? 1 - dh / 9 : 0
  } else if (eng.levelDef.id === 5) {
    let ds = 1e9
    for (const s of m.structures) {
      if (s.kind !== 'sconce') continue
      const dd = Math.hypot(s.x + 0.5 - p.x, s.y + 0.5 - p.y)
      if (dd < ds) ds = dd
    }
    elecHum = ds < 6 ? 0.45 * (1 - ds / 6) : 0
  }
  audio.setElecHum(elecHum)
  // ---- v55：L5 留声机诡异古典乐（按最近播放中留声机距离逐帧调音量；E 停播的[data.on=0]不计；
  //      近场淡入留声机并闪避 BGM，远场恢复——audio.setPhono 内处理）----
  if (eng.levelDef.id === 5) {
    let dp = 1e9
    for (const s of m.structures) {
      if (s.kind !== 'phonograph' || s.data?.on === 0) continue
      const dd = Math.hypot(s.x + 0.5 - p.x, s.y + 0.5 - p.y)
      if (dd < dp) dp = dd
    }
    audio.setPhono(dp < 10 ? 1 - dp / 10 : 0)
  } else audio.setPhono(0)
}

/** 容器搜索进度 + 战利品面板自动关闭（原 step 内联段，逐语句搬运） */
export function updateContainerSearch(eng: Engine, dt: number) {
  const p = eng.player, m = eng.map!
  // ---- 容器搜索进度 ----
  if (eng.searching) {
    const s = eng.searching
    const st = m.structures.find((x) => x.data?.sid === s.sid)
    const near = st && structureSurfaceDistance(st, p.x, p.y) < 2.4
    if (!st || !near || st.looted) {
      eng.searching = null // 离开或已空，取消
    } else {
      s.t += dt
      if (Math.random() < dt * 5) audio.searchTick()
      if (s.t >= s.dur) {
        eng.searching = null
        eng.finishSearch(st)
      }
    }
  }

  // ---- 战利品面板：离开交互半径自动关闭（未拿取物品留在容器内，可再次搜索）----
  if (eng.lootPanel) {
    const lp = eng.lootPanel
    const st = m.structures.find((x) => x.data?.sid === lp.sid)
    if (!st || structureSurfaceDistance(st, p.x, p.y) > 2.5) {
      eng.closeLootPanel()
    }
  }
}

/** 未涂黑窗户陷阱 / 锈蚀钢筋 / 蒸汽阀门伤害（原 step 内联段；true=本帧已死亡） */
export function triggerStructs(eng: Engine, dt: number, dm: DiffMult): boolean {
  const p = eng.player, m = eng.map!
  // 未涂黑窗户陷阱（wiki L4：未涂黑的窗户必须避开）——靠近即触发一次
  for (const s of m.structures) {
    if(s.kind==='trade_anomaly'&&s.data?.hidden)continue
    if (s.kind !== 'windowtrap' || s.data?.triggered) continue
    const d = Math.hypot(s.x + 0.5 - p.x, s.y + 0.5 - p.y)
    if (d < 1.9) {
      s.data = { ...s.data, triggered: 1 }
      if(s.data.l4&&s.data.windowId)for(const pane of m.structures){
        if(pane.kind==='windowtrap'&&pane.data?.windowId===s.data.windowId)pane.data.triggered=1
      }
      p.sanity = Math.max(0, p.sanity - 14)
      eng.emit({ kind: 'sanityhit' })
      eng.camShake = Math.min(1, eng.camShake + 0.4)
      eng.msg('玻璃后面贴着一张脸——它不是你的倒影！你踉跄后退。（理智-14）', 'damage')
      audio.aggro()
      eng.noiseEvent(p.x, p.y, 12, true) // 响动引来实体
    }
  }

  // 锈蚀钢筋（L1：突出墙壁的生锈金属尖端——wikidot/Fandom：刺伤可致破伤风；一次性划伤）
  for (const s of m.structures) {
    if (s.kind !== 'rebar' || s.data?.triggered) continue
    if (Math.hypot(s.x + 0.5 - p.x, s.y + 0.5 - p.y) < 0.9) {
      s.data = { ...s.data, triggered: 1 }
      eng.hurtPlayer(4, '锈蚀钢筋')
    }
  }

  // 蒸汽阀门伤害
  for (const s of m.structures) {
    if (s.kind === 'valve' && s.data?.on) {
      const d = Math.hypot(s.x + 0.5 - p.x, s.y + 0.5 - p.y)
      if (d < 1.6 && !p.hasGloves) {
        p.hp -= 8 * dt * dm.dmg
        if (Math.random() < dt * 2) eng.steamParticles(s.x + 0.5, s.y + 0.5)
        if (p.hp <= 0) { eng.die('被蒸汽烫死了'); return true }
      }
      if (Math.random() < dt * 3) eng.steamParticles(s.x + 0.5, s.y + 0.5)
    }
  }
  return false
}
export const INTERACT_RANGE = { object: 2.2, item: 2.0, npc: 2.5 } as const
// NPC 的交互距离以可见身体表面为起点，而不是以脚下坐标/模型中心为起点。
// 低模角色连同自然下垂的手臂约 0.5m 宽；略留一点配饰余量，避免准星已经落在
// 背包、吉他或外套边缘时仍判定为没有指向角色。
export const NPC_INTERACTION_BODY = { radius: 0.52, height: 1.94 } as const
export const INTERACT_Z_RANGE = 3.0 // v57t：交互目标必须位于玩家眼高 ±3m 内（海面不能隔几十米抓到海床上的物品/容器）
const AIM_NORMAL = 15 * Math.PI / 180
const AIM_NEAR = 20 * Math.PI / 180
const AIM_TOUCHING = 28 * Math.PI / 180

const angleDiff = (a: number, b: number) => {
  let d = Math.abs(a - b)
  if (d > Math.PI) d = Math.PI * 2 - d
  return d
}

export interface StructureInteractionProfile {
  /** 相对本层地面的交互体积下沿。 */
  minZ: number
  /** 相对本层地面的交互体积上沿。 */
  maxZ: number
  /** 相对本层地面的交互体积中心高度。 */
  centerZ: number
  /** 交互体积的垂直半径；准星落在可见模型高度内时不产生俯仰误差。 */
  verticalRadius: number
  /** 水平模型半径；与占地表面距离分离，避免细长/宽幅模型共用一个球形容差。 */
  horizontalRadius: number
}

/**
 * 可交互结构的可见高度体积。
 * 渲染模型高度差异很大（地面文件、桌面文件、布面地标、2.6m 路牌等），不能再用统一的 0.73m 目标点。
 */
export function structureInteractionProfile(s: Structure): StructureInteractionProfile {
  let lo = 0.1, hi = Math.min(2.3, Math.max(0.8, 0.5 + Math.max(s.w, s.h) * 0.35))
  let horizontalRadius = Math.min(0.55, 0.24 + Math.min(s.w, s.h) * 0.16)
  switch (s.kind) {
    case 'landmark':
      lo = s.data?.poster ? 0.68 : 0.78; hi = s.data?.poster ? 2.08 : 1.84
      horizontalRadius = s.data?.poster ? 0.49 : 0.32
      break
    case 'roadsign': lo = 0.2; hi = 2.02; horizontalRadius = 0.36; break
    case 'l9arrowsign': lo = 0.15; hi = 2.12; horizontalRadius = 0.42; break
    case 'l9stair': lo = 0.05; hi = 2.75; horizontalRadius = Math.min(0.85, Math.max(0.5, s.w / 2)); break
    case 'megsign': lo = 0.2; hi = 2.55; horizontalRadius = 0.52; break
    case 'megdoc': lo = s.data?.ontable ? (s.data?.l0Furniture ? 0.97 : s.data?.manila ? 1.09 : 0.75) : 0; hi = s.data?.ontable ? (s.data?.l0Furniture ? 1.07 : s.data?.manila ? 1.19 : 0.84) : 0.1; horizontalRadius = 0.2; break
    case 'invitation': lo = 0; hi = 0.14; horizontalRadius = 0.25; break
    case 'lightswitch': lo = 1.05; hi = 1.55; horizontalRadius = 0.22; break
    case 'braille': lo = 1.2; hi = 1.44; horizontalRadius = 0.22; break
    case 'graffiti': lo = 0.45; hi = 2.35; horizontalRadius = 0.52; break
    case 'bigpainting': {
      const ph = Math.min(2.6, Math.max(0.8, Number(s.data?.ph) || 1.3))
      lo = 0.86; hi = Math.min(2.85, lo + ph)
      horizontalRadius = Math.min(1.65, Math.max(0.42, (Number(s.data?.pw) || 1.8) / 2))
      break
    }
    case 'windowblack': case 'windowtrap': case 'glasswin': lo = 0.55; hi = 2.2; horizontalRadius = 0.5; break
    case 'statue': lo = 0.15; hi = 2.65; horizontalRadius = 0.48; break
    case 'handspike': lo = 0; hi = 1.25; horizontalRadius = 0.38; break
    case 'clipfuse': lo = 0; hi = 2.8; horizontalRadius = Math.min(1.2, Math.max(s.w, s.h) / 2); break
    case 'endletters': lo = 0; hi = 1.7; horizontalRadius = Math.min(1.4, Math.max(0.45, s.w / 2)); break
    case 'arcadecab': lo = 0.15; hi = 1.65; horizontalRadius = 0.36; break
    case 'hoteldoor': case 'rollerdoor': case 'glassdoor': case 'inkdoor': case 'bargate': case 'lift':
      lo = 0.1; hi = 2.45; horizontalRadius = Math.min(0.65, Math.max(0.42, Math.min(s.w, s.h) / 2)); break
    case 'frontdesk': lo = 0.15; hi = 1.32; horizontalRadius = Math.min(1.2, Math.max(0.45, s.w / 2)); break
    case 'table': lo = 0.55; hi = 0.88; horizontalRadius = Math.min(0.75, Math.max(0.35, Math.min(s.w, s.h) / 2)); break
    case 'alpha_desk': lo = 0.68; hi = 0.82; horizontalRadius = Math.min(0.75, Math.max(0.35, Math.min(s.w, s.h) / 2)); break
    case 'alpha_labbench': lo = 0.84; hi = 1.04; horizontalRadius = Math.min(0.75, Math.max(0.35, Math.min(s.w, s.h) / 2)); break
    case 'alpha_cold_cabinet': lo = 0.3; hi = 1.85; horizontalRadius = Math.min(0.75, Math.max(0.35, Math.min(s.w, s.h) / 2)); break
    case 'alpha_archive_reader': lo = 0.72; hi = 1.1; horizontalRadius = Math.min(0.75, Math.max(0.35, Math.min(s.w, s.h) / 2)); break
    case 'alpha_reception_counter': lo = 0.75; hi = 1.25; horizontalRadius = Math.min(0.75, Math.max(0.35, Math.min(s.w, s.h) / 2)); break
    case 'alpha_dispatch_desk': case 'alpha_executive_desk': lo = 0.72; hi = 1.08; horizontalRadius = Math.min(0.75, Math.max(0.35, Math.min(s.w, s.h) / 2)); break
    case 'alpha_grow_station': case 'alpha_home_kitchen': case 'alpha_library_counter': case 'alpha_build_bench':
      lo = 0.72; hi = 1.1; horizontalRadius = Math.min(0.75, Math.max(0.35, Math.min(s.w, s.h) / 2)); break
    case 'valve': lo = 0.15; hi = 1.38; horizontalRadius = 0.3; break
    case 'phonograph': lo = 0.08; hi = 1.62; horizontalRadius = 0.34; break
    case 'booth': lo = 0.1; hi = 2.05; horizontalRadius = Math.min(0.7, Math.max(0.45, Math.min(s.w, s.h) / 2)); break
    case 'server': lo = 0.1; hi = 2.22; horizontalRadius = Math.min(0.8, Math.max(0.45, Math.min(s.w, s.h) / 2)); break
    case 'vending': lo = 0.08; hi = 2.02; horizontalRadius = 0.5; break
    case 'l6stairwell': lo = 0; hi = 1.5; horizontalRadius = 0.6; break
    case 'obelisk': lo = 0.1; hi = 2.85; horizontalRadius = Math.min(0.8, Math.max(0.45, Math.min(s.w, s.h) / 2)); break
    case 'corpse': lo = 0; hi = 0.28; horizontalRadius = 0.38; break
    case 'crate': case 'megcrate': lo = 0; hi = 0.76; horizontalRadius = 0.45; break
    case 'car': lo = 0.1; hi = 1.25; horizontalRadius = Math.min(0.9, Math.max(0.5, Math.min(s.w, s.h) / 2)); break
    case 'cabinet': case 'dresser': case 'safebox':
      if (s.kind === 'dresser' && s.data?.manilaTable) { lo = 0.05; hi = s.data?.l0Furniture ? 1.01 : 1.13; horizontalRadius = s.data?.l0Furniture ? 0.64 : 0.77 }
      else { lo = 0.05; hi = s.kind === 'dresser' ? 1.15 : s.kind === 'safebox' ? 0.9 : 1.85; horizontalRadius = 0.45 }
      break
    case 'locker': case 'fridge': lo = 0.05; hi = 2.02; horizontalRadius = 0.4; break
    case 'toolbox': case 'suitcase': lo = 0; hi = 0.5; horizontalRadius = 0.35; break
    case 'mailbox': lo = 0.45; hi = 1.35; horizontalRadius = 0.38; break
    case 'barrel': lo = 0; hi = 1.02; horizontalRadius = 0.45; break
    case 'bookcase': lo = 0.05; hi = 2.05; horizontalRadius = Math.min(0.75, Math.max(0.45, Math.min(s.w, s.h) / 2)); break
    case 'ropeanchor': lo = 0.5; hi = 1.4; horizontalRadius = 0.5; break
    case 'bonepile': lo = 0; hi = 0.55; horizontalRadius = 0.45; break
    case 'campstall': lo = 0.2; hi = 2.1; horizontalRadius = Math.min(0.9, Math.max(0.5, Math.min(s.w, s.h) / 2)); break
    case 'elecbox': lo = 0.45; hi = 1.65; horizontalRadius = 0.38; break
    default: break
  }
  return { minZ: lo, maxZ: hi, centerZ: (lo + hi) / 2, verticalRadius: Math.max(0.05, (hi - lo) / 2), horizontalRadius }
}

/** 交互目标的世界坐标轴对齐体积；准星直接命中它时优先于角度辅助。 */
export interface InteractionVolume {
  minX: number
  minY: number
  minZ: number
  maxX: number
  maxY: number
  maxZ: number
}

interface InteractionRay {
  ox: number
  oy: number
  oz: number
  dx: number
  dy: number
  dz: number
}

/** 交互使用的眼高与蹲伏相机保持一致；摇头/震屏只作视觉效果，不改变操作瞄准。 */
export function interactionEyeZ(eng: Engine): number {
  return eng.player.z + seatedEyeHeight(eng)
}

/** 从屏幕中央准星发出的世界空间射线，与 renderer/combat 的朝向约定一致。 */
export function crosshairRay(eng: Engine): InteractionRay {
  const p = eng.player
  const offset = seatedEyeOffset(eng)
  const n = Math.hypot(look.rayX, look.rayY, look.rayZ) || 1
  return {
    ox: p.x + offset.x,
    oy: p.y + offset.y,
    oz: interactionEyeZ(eng),
    dx: look.rayX / n,
    dy: look.rayY / n,
    dz: look.rayZ / n,
  }
}

/** Level 10 的持续交互。饮水、挖掘和深湖下潜都必须完整保持到进度结束。 */
export function updateL10Actions(eng: Engine, dt: number) {
  const m = eng.map
  if (!m || eng.levelDef.id !== 10 || eng.transition) { eng.l10Action = null; return }
  const p = eng.player
  const deepExit = m.exits.find((e) => e.def.kind === 'lakeswim')
  const atDeepCenter = !!deepExit
    && Math.hypot(p.x - deepExit.x, p.y - deepExit.y) <= 2.35
    && eng.inLiquid === 1 && eng.submerged && p.z < -1.5

  if (!eng.l10Action && atDeepCenter && deepExit) {
    eng.l10Action = { kind: 'dive', t: 0, dur: 3, x: deepExit.x, y: deepExit.y }
    eng.msg('湖心之下没有可见湖底。继续下潜……', 'lore')
  }

  const a = eng.l10Action
  if (!a) return
  if (a.kind === 'drink') {
    let stillNearWater = eng.inLiquid !== 1
    if (stillNearWater) {
      stillNearWater = false
      const minX = Math.max(0, Math.floor(p.x - 2.4)), maxX = Math.min(m.w - 1, Math.floor(p.x + 2.4))
      const minY = Math.max(0, Math.floor(p.y - 2.4)), maxY = Math.min(m.h - 1, Math.floor(p.y + 2.4))
      for (let y = minY; y <= maxY && !stillNearWater; y++) for (let x = minX; x <= maxX; x++) {
        if (m.liquid[y * m.w + x] === 1 && Math.hypot(x + .5 - p.x, y + .5 - p.y) <= 2.4) { stillNearWater = true; break }
      }
    }
    if (!stillNearWater) { eng.l10Action = null; return }
  } else if (a.kind === 'dig') {
    const st = m.structures.find((s) => s.data?.sid === a.sid && s.kind === 'l10digsite')
    if (!st || st.data?.dug || structureSurfaceDistance(st, p.x, p.y) > 2.4) { eng.l10Action = null; return }
  } else if (!atDeepCenter) {
    eng.l10Action = null
    return
  }

  a.t += dt
  if (a.t < a.dur) return
  eng.l10Action = null

  if (a.kind === 'drink') {
    p.thirst = Math.min(100, p.thirst + 18)
    eng.msg('你喝下湖水。（口渴 +18）水能入口，但留下很重的泥土余味。', 'loot')
    audio.pickup()
    return
  }
  if (a.kind === 'dive') {
    if (deepExit) eng.takeExit(deepExit.def)
    return
  }

  const st = m.structures.find((s) => s.data?.sid === a.sid && s.kind === 'l10digsite')
  if (!st || st.data?.dug) return
  st.data = { ...st.data, dug: 1 }
  const count = 6 + Math.floor(Math.random() * 5)
  for (let i = 0; i < count; i++) {
    const ang = (i / count) * Math.PI * 2 + Math.random() * .45
    const r = .55 + Math.random() * 1.35
    const x = st.x + st.w / 2 + Math.cos(ang) * r
    const y = st.y + st.h / 2 + Math.sin(ang) * r
    const worm = makeEntity('soilworm', x, y, groundHeightAt(m, x, y))
    worm.hidden = false
    worm.state = 'chase'
    worm.targetX = p.x; worm.targetY = p.y
    worm.l10BurrowT = 15 + Math.random() * 10
    m.entities.push(worm)
  }
  eng.msg(`土层突然涌动——${count} 条土壤蠕虫从挖掘点附近钻了出来！离开现场，它们很快会退回地下。`, 'damage')
  audio.aggro()
  eng.camShake = Math.min(1, eng.camShake + .5)
}

/** 射线首次进入 AABB 的距离；射线起点已在体积内时返回 0。 */
export function rayInteractionVolume(ray: InteractionRay, box: InteractionVolume, maxT = 12): number | null {
  let near = 0
  let far = maxT
  const axes = [
    [ray.ox, ray.dx, box.minX, box.maxX],
    [ray.oy, ray.dy, box.minY, box.maxY],
    [ray.oz, ray.dz, box.minZ, box.maxZ],
  ] as const
  for (const [origin, direction, min, max] of axes) {
    if (Math.abs(direction) < 1e-7) {
      if (origin < min || origin > max) return null
      continue
    }
    let a = (min - origin) / direction
    let b = (max - origin) / direction
    if (a > b) [a, b] = [b, a]
    near = Math.max(near, a)
    far = Math.min(far, b)
    if (near > far) return null
  }
  return far >= 0 && near <= maxT ? Math.max(0, near) : null
}

/** 结构交互体积：水平面复用物理碰撞的精确轮廓，垂直面复用可见模型高度。 */
export function structureInteractionVolume(eng: Engine, s: Structure, band: FloorBand): InteractionVolume {
  const m = eng.map!
  const boxes = structColliders(s, m)
  const profile = structureInteractionProfile(s)
  const base = floorHeight(m, s.x + s.w / 2, s.y + s.h / 2, band)
  return {
    minX: Math.min(...boxes.map((b) => b.x0)),
    minY: Math.min(...boxes.map((b) => b.y0)),
    minZ: base + profile.minZ,
    maxX: Math.max(...boxes.map((b) => b.x1)),
    maxY: Math.max(...boxes.map((b) => b.y1)),
    maxZ: base + profile.maxZ,
  }
}

/** 当前楼层带的三维交互 LOS：墙体、地板高度与精细实心结构碰撞盒均参与。 */
export function interactionLos3D(eng: Engine, x: number, y: number, z: number, band: FloorBand, target?: Structure): boolean {
  const p = eng.player, m = eng.map
  if (!m || bandOfPlayerZ(m, p.z,p.x,p.y) !== band) return false
  const x0 = p.x, y0 = p.y, z0 = interactionEyeZ(eng)
  const dx = x - x0, dy = y - y0, dz = z - z0
  if(p.level===11&&l11InteractionBlocked(m,[x0,z0,y0],[x,z,y],band,target))return false
  const steps = Math.max(2, Math.ceil(Math.hypot(dx, dy, dz) / 0.12))
  for (let i = 1; i < steps; i++) {
    const t = i / steps
    const sx = x0 + dx * t, sy = y0 + dy * t, sz = z0 + dz * t
    const tx = Math.floor(sx), ty = Math.floor(sy)
    if (wallAt(m, tx, ty, band)) return false
    if (sz < floorHeight(m, sx, sy, band) + 0.035) return false
    if (structBlocksSight(m, sx, sy, sz, band, target)) return false
  }
  return true
}

/** 距离、俯仰/准星硬门槛与三维 LOS 的统一探针；返回值同时作为多目标排序分数。 */
export function interactionProbe(
  eng: Engine, x: number, y: number, z: number, band: FloorBand, maxDistance: number,
  radius = 0.25, volume?: InteractionVolume, target?: Structure, surfaceDistance?: number, verticalRadius = radius,
): { a: number; d: number; direct: boolean; rayT: number } | null {
  const p = eng.player
  const dx = x - p.x, dy = y - p.y
  const aimD = Math.hypot(dx, dy)
  const d = surfaceDistance ?? aimD
  if (d > maxDistance) return null
  // v57t：交互判断的 z 轴硬门槛——玩家眼高与目标中心超过 3m 直接不可交互
  const eyeZ = interactionEyeZ(eng)
  if (Math.abs(z - eyeZ) > INTERACT_Z_RANGE) return null

  // 视觉命中是首要入口：玩家准星真正落在木箱顶面、柜门或大型结构边缘时，
  // 不再因为代表点位于模型中心/背面而丢失提示。
  if (volume) {
    const ray = crosshairRay(eng)
    const rayT = rayInteractionVolume(ray, volume)
    if (rayT !== null) {
      const hx = ray.ox + ray.dx * rayT
      const hy = ray.oy + ray.dy * rayT
      const hz = ray.oz + ray.dz * rayT
      if (Math.abs(hz - eyeZ) <= INTERACT_Z_RANGE && interactionLos3D(eng, hx, hy, hz, band, target)) {
        return { a: -1 + Math.min(10, rayT) * 1e-3, d, direct: true, rayT }
      }
    }
  }

  const yawErr = aimD < 0.02 ? 0 : angleDiff(Math.atan2(dy, dx), p.facing)
  const pitchTo = Math.atan2(z - interactionEyeZ(eng), Math.max(0.05, aimD))
  // 水平与垂直体积分别扣除角半径：高路牌不会把巨大高度容差错误地扩张到左右方向，
  // 地面文档也不会再沿用高柜的俯仰容差。
  const yawMiss = Math.max(0, yawErr - Math.atan2(radius, Math.max(0.05, aimD)))
  const pitchMiss = Math.max(0, Math.abs(pitchTo - look.pitch) - Math.atan2(verticalRadius, Math.max(0.05, aimD)))
  const a = Math.hypot(yawMiss, pitchMiss)
  const hardLimit = d < 0.75 ? AIM_TOUCHING : d < 1.2 ? AIM_NEAR : AIM_NORMAL
  if (a > hardLimit || !interactionLos3D(eng, x, y, z, band, target)) return null
  return { a, d, direct: false, rayT: Number.POSITIVE_INFINITY }
}

// 兼容 AI/旧调用的水平视锥：贴身可放宽方向，但任何距离都必须保持无遮挡。
export function inView(eng: Engine, x: number, y: number, radius: number): boolean {
  const p = eng.player
  const dx = x - p.x, dy = y - p.y
  const d = Math.hypot(dx, dy)
  if (d > radius) return false
  const ang = Math.atan2(dy, dx)
  const diff = angleDiff(ang, p.facing)
  if (d >= 0.9 && diff > 1.5) return false // 贴身只放宽方向，不跳过 LOS
  // 目标点向玩家回拉，避免实心容器/结构自身遮挡 LOS
  if (d < 0.02) return true
  const pull = Math.min(0.65, d * 0.5)
  const tx = x - (dx / d) * pull, ty = y - (dy / d) * pull
  return eng.los(p.x, p.y, tx, ty)
}

// 目标与视线朝向的水平角差（弧度）——贴身目标仍计算真实方向，避免近处余光目标被伪装成准星正中。
export function viewAngle(eng: Engine, x: number, y: number): number {
  const p = eng.player
  const dx = x - p.x, dy = y - p.y
  if (Math.hypot(dx, dy) < 0.02) return 0
  const ang = Math.atan2(dy, dx)
  return angleDiff(ang, p.facing)
}
// 统一可交互目标选择（HUD 提示与 doInteract 执行共用本函数结果）。
// v57：出口/物品/结构/NPC/特殊实体全部进入同一个准星评分器，避免旧版“数组类别先返回”让
// 身旁出口或地面物品抢走玩家正对目标。优先级：准星实际覆盖 > 3D 角误差 > 距离 > 可执行性。
export function scanInteract(eng: Engine) {
  const p = eng.player, m = eng.map!
  eng.interactTarget = null
  const band = bandOfPlayerZ(m, p.z,p.x,p.y)
  type Target = NonNullable<Engine['interactTarget']>
  type Candidate = { target: Target; a: number; d: number; can: boolean }
  const choice: { current: Candidate | null } = { current: null }
  const commitCandidate = (target: Target, a: number, d: number, can: boolean) => {
    const old = choice.current
    if (!old || a < old.a - 1e-4
      || (Math.abs(a - old.a) <= 1e-4 && d < old.d - 1e-4)
      || (Math.abs(a - old.a) <= 1e-4 && Math.abs(d - old.d) <= 1e-4 && can && !old.can)) {
      choice.current = { target, a, d, can }
    }
  }
  const vh = look.visualHit
  const visualHit = vh
    && Date.now() - vh.at < 250
    && angleDiff(vh.yaw, look.yaw) < 0.045
    && Math.abs(vh.pitch - look.pitch) < 0.045
    && Math.hypot(vh.playerX - p.x, vh.playerY - p.y, vh.playerZ - p.z) < 0.18
    ? vh : null
  const volumeAt = (x: number, y: number, z0: number, radius: number, height: number): InteractionVolume => ({
    minX: x - radius, minY: y - radius, minZ: z0,
    maxX: x + radius, maxY: y + radius, maxZ: z0 + height,
  })
  const considerTarget = (
    target: Target, x: number, y: number, z: number, targetBand: FloorBand, maxDistance: number,
    can = true, radius = 0.25, volume?: InteractionVolume, surfaceDistance?: number,
    structure?: Structure, verticalRadius = radius,
  ) => {
    const probe = interactionProbe(eng, x, y, z, targetBand, maxDistance, radius, volume, structure, surfaceDistance, verticalRadius)
    if (!probe) return
    const { a, d } = probe
    commitCandidate(target, a, d, can)
  }
  // 出口按 FloorBand 过滤；缺省仍在主层。
  for (const e of m.exits) {
    if ((e.floor ?? 0) !== band) continue
    if (e.def.kind === 'graystairs' || e.def.kind === 'graystairsup' || e.def.kind === 'oldstairs') continue // v29/v54：可行走阶梯——直接走上去/走下去，无 E 交互
    if (e.def.kind === 'ninthroad') continue // L8 第九大道狭窄洞口由移动碰触自动进入，不显示 E 交互提示
    if (e.def.kind === 'lakeswim') continue // L10 深湖仅在湖心持续下潜约 3 秒后自动触发
    if (e.def.kind === 'l11liftshaft') continue // enter the open shaft by walking
    const ex = e.x + 0.5, ey = e.y + 0.5
    const d = Math.hypot(ex - p.x, ey - p.y)
    const tinyBlocked = e.def.kind === 'littledoor' && eng.tinyBlocksLittleDoor(e)
    const archiveSealed=p.level===11&&e.def.kind==='basebeta'&&!eng.l11World?.archiveUnlocked
    const exitTarget: Target = { kind: 'exit', label: archiveSealed?`提交六盘磁带并撕下封条（${eng.countItem('tape')}/6）`:tinyBlocked ? '小小盘踞在门上方（暂时无法进入）' : `进入 ${e.def.name}`, e }
    // v58：准星真实命中出口模型（电梯门等）——与结构/物品共用视觉命中通道，直指即达
    if (visualHit?.kind === 'exit' && visualHit.exit === e
      && interactionLos3D(eng, visualHit.x, visualHit.y, visualHit.z, e.floor ?? 0)) {
      e.discovered = true
      commitCandidate(exitTarget, -2 + Math.min(10, visualHit.rayT) * 1e-3, d, true)
      continue
    }
    // v58：电梯交互距离放宽（1.6→2.2m）且交互体加大——壁龛格已有门扇碰撞进不去，
    // 站在门扇正前/侧前舒适距离内即可唤起「进入 电梯」
    const avenueMouth = e.def.kind === 'ninthroad'
    const ceilingVent = e.def.kind === 'l8vent'
    const l9OutdoorExit = e.def.kind === 'arrowsign' || e.def.kind === 'grasspath' || e.def.kind === 'l9caveback'
    const range = e.def.kind === 'elevatorshaft' ? 2.2 : ceilingVent ? 3.0 : avenueMouth ? 3.2 : l9OutdoorExit ? 2.2 : 1.6
    if (d < range) {
      e.discovered = true
      const exitBase = e.z ?? floorHeight(m, ex, ey, e.floor ?? 0) // v57t：漂浮门等出口自带 z 高度
      const ez = ceilingVent ? exitBase : exitBase + 0.95
      const big = e.def.kind === 'elevatorshaft'
      considerTarget(exitTarget, ex, ey, avenueMouth ? exitBase + 2.2 : ez, e.floor ?? 0, range, true,
        avenueMouth ? 2.35 : ceilingVent ? 0.68 : big ? 0.62 : 0.48,
        volumeAt(ex, ey, ceilingVent ? exitBase - 0.12 : exitBase, avenueMouth ? 2.55 : ceilingVent ? 0.7 : big ? 0.75 : 0.5, avenueMouth ? 4.7 : ceilingVent ? 0.86 : 1.95))
    }
  }
  // L10 普通湖泊：只允许站在岸边对着水面持续饮用；深湖下潜由自动判定处理。
  if (eng.levelDef.id === 10 && eng.inLiquid !== 1) {
    const minX = Math.max(0, Math.floor(p.x - 2)), maxX = Math.min(m.w - 1, Math.floor(p.x + 2))
    const minY = Math.max(0, Math.floor(p.y - 2)), maxY = Math.min(m.h - 1, Math.floor(p.y + 2))
    for (let y = minY; y <= maxY; y++) for (let x = minX; x <= maxX; x++) {
      if (m.liquid[y * m.w + x] !== 1) continue
      const wx = x + .5, wy = y + .5, d = Math.hypot(wx - p.x, wy - p.y)
      if (d > 1.9) continue
      considerTarget({ kind: 'l10drink', label: '饮用 湖水（2 秒）' }, wx, wy, .03, band, 1.9, true,
        .42, volumeAt(wx, wy, -.06, .45, .16), d)
    }
  }
  // 地面物品（半径 2.0m；v13：按物品所在高度过滤楼层）
  for (const it of m.items) {
    const iz = it.z ?? groundHeightAt(m, it.x, it.y)
    const itemBand = bandOfPlayerZ(m, iz,it.x,it.y)
    if (itemBand !== band) continue
    const target: Target = {
      kind: 'item', label: it.type === 'welcomenote' ? `查看 ${itemName(it.type)}` : `拾取 ${itemName(it.type)}`, it,
    }
    const d = Math.hypot(it.x - p.x, it.y - p.y)
    if (visualHit?.kind === 'item' && visualHit.item === it && d <= INTERACT_RANGE.item
      && interactionLos3D(eng, visualHit.x, visualHit.y, visualHit.z, itemBand)) {
      commitCandidate(target, -2 + Math.min(10, visualHit.rayT) * 1e-3, d, true)
    }
    considerTarget(
      target,
      it.x, it.y, iz + 0.22, itemBand, INTERACT_RANGE.item, true, 0.2, volumeAt(it.x, it.y, iz, 0.22, 0.44),
    )
  }
  // 结构（半径 2.2m，含容器）
  const consider = (kind: string, label: string, s: Structure, d: number, can: boolean) => {
    const surface = structureSurfacePoint(s, p.x, p.y)
    const sx = surface.x, sy = surface.y
    const targetBand = s.kind === 'lift' ? band : (s.floor ?? 0)
    const profile = structureInteractionProfile(s)
    const sz = floorHeight(m, sx, sy, targetBand) + profile.centerZ
    const volume = structureInteractionVolume(eng, s, targetBand)
    const target: Target = { kind, label, s }
    if (visualHit?.kind === 'structure' && visualHit.structure === s
      && interactionLos3D(eng, visualHit.x, visualHit.y, visualHit.z, targetBand, s)) {
      commitCandidate(target, -2 + Math.min(10, visualHit.rayT) * 1e-3, d, can)
    }
    considerTarget(target, sx, sy, sz, targetBand, INTERACT_RANGE.object, can,
      profile.horizontalRadius, volume, d, s, profile.verticalRadius)
  }
  for (const marker of fieldTargets(eng)) consider('careerField','记录现场证据',marker,Math.hypot(marker.x-p.x,marker.y-p.y),true)
  for (const s of m.structures) {
    // v13：结构按楼层过滤（楼上楼下同名容器互不干扰）；lift 跨层服务
    if (s.kind !== 'lift' && (s.floor ?? 0) !== band) continue
    const d = structureSurfaceDistance(s, p.x, p.y) // 大结构按最近表面，而非中心计交互距离
    if (d > INTERACT_RANGE.object) continue
    if(s.kind==='trade_anomaly'&&s.data?.hidden)continue
    if (furnitureSeats(s, eng.levelDef.id).length) {
      if (!eng.seating) consider('sit', '坐下', s, d, !!pickSeat(eng, s))
      else if (s === eng.seating.structure) consider('stand', '起身', s, d, true)
      continue
    }
    if (s.kind === 'settlementstation' || s.data?.facility || TRADE_DEFS.some(def=>def.id===s.kind&&def.interactive)) { consider('settlementstation', String(s.data?.label ?? '查看贸易设施'), s, d, true); continue }
    if (s.kind === 'lift') { consider('lift', band === 0 ? '乘电梯 上楼' : '乘电梯 下楼', s, d, !eng.ride); continue }
    // v18：已搜空容器仍可选中（交互时提示「容器是空的」），未搜空的正常提示
    // v23：全部容器走统一表（含新增的储物柜/工具箱/行李箱/冰箱/保险箱/信箱/木桶/书柜/骨堆/营地摊位）
    if (s.kind === 'l11landmark') consider(s.data?.outpost ? 'landmark' : 'l11guide', '查看 城市导览牌', s, d, true)
    else if (s.kind === 'l11prop' && ['sink','lockedlift','anomaly'].includes(String(s.data?.prop))) consider('l11inspect', s.data?.prop === 'sink' ? '使用 饮水设施' : '查看 设施', s, d, true)
    else if (CONTAINERS[s.kind]) {
      const C = CONTAINERS[s.kind]
      const containerLabel = s.data?.manilaTable ? '桌下橱柜' : C.label
      const gate = !C.gate || (C.gate === 'carkey' ? eng.hasPocket('carkey') : eng.hasItem('crowbar'))
      const gateText = C.gate === 'carkey' ? '（需要车钥匙）' : '（需要撬棍）'
      const label = s.looted ? `${containerLabel}（空）`
        : !gate ? `${containerLabel}${gateText}`
        : s.data?.searched ? `查看 ${containerLabel}（剩余物品）`
        : `搜索 ${containerLabel}`
      consider(s.kind, label, s, d, s.looted ? true : gate)
    }
    else if (s.kind === 'lightswitch') consider('lightswitch', s.data?.flipped ? '电灯开关（已经拨过了）' : '拨动 电灯开关', s, d, true)
    else if (s.kind === 'roadsign' || s.kind === 'megsign') consider('roadsign', DECOR_VIEWS.roadsign.label, s, d, true)
    else if (s.kind === 'l9arrowsign') consider('l9arrowsign', `查看 第 ${Number(s.data?.seq ?? 1)} 块箭头路牌`, s, d, true)
    else if (s.kind === 'l9stair') consider('l9stair', '查看 通往二层的楼梯', s, d, true)
    else if (s.kind === 'braille') consider('braille', DECOR_VIEWS.braille.label, s, d, true)
    else if (s.kind === 'arcadecab') consider('arcadecab', '投币 街机', s, d, true)
    else if (s.kind === 'endletters') consider('endletters', DECOR_VIEWS.endletters.label, s, d, true)
    else if (s.kind === 'clipfuse') consider('clipfuse', DECOR_VIEWS.clipfuse.label, s, d, true)
    else if (s.kind === 'handspike') consider('handspike', DECOR_VIEWS.handspike.label, s, d, true)
    else if (s.kind === 'hoteldoor') {
      if (s.data?.sealed) consider('hoteldoor', '锁死的门（锁的结构闻所未闻）', s, d, true) // v41：L2 特殊锁死门——任何方式都打不开
      else if (s.data?.locked) {
        const staffCard = s.data?.staff === 1 && eng.hasPocket('keycard')
        const canAxe = eng.hasItem('axe') && eng.axeDur > 0
        const can = staffCard || eng.hasItem('crowbar') || eng.hasPocket('skeleton') || canAxe
        const label = staffCard ? '刷员工卡 打开员工门'
          : canAxe ? `劈开 上锁的房门（斧头耐久 ${eng.axeDur}/5）`
          : can ? '撬开 上锁的房门' : s.data?.staff === 1 ? '上锁的员工门（需要员工卡/撬棍/万能钥匙/斧头）' : '上锁的房门（需要撬棍/万能钥匙/斧头）'
        consider('hoteldoor', label, s, d, can)
      } else consider('hoteldoor', s.data?.open ? '关上 房门' : '打开 房门', s, d, true)
    }
    else if (s.kind === 'ropeanchor') {
      const deployed = s.data?.deployed === 1
      consider('ropeanchor', deployed ? '尼龙绳（已系好，可靠近攀爬）' : '系上 尼龙绳', s, d, true)
    }
    else if (s.kind === 'rollerdoor') {
      if (s.data?.locked) consider('rollerdoor', '卷帘门锁死了', s, d, false)
      else consider('rollerdoor', s.data?.open ? '放下 卷帘门' : '升起 卷帘门', s, d, true)
    }
    else if (s.kind === 'glassdoor') consider('glassdoor', s.data?.open ? '关上 玻璃门' : '推开 玻璃门', s, d, true)
    else if (s.kind === 'inkdoor') consider('inkdoor', s.data?.open ? '关上 墨黑色金属门' : '打开 墨黑色金属门', s, d, true)
    else if (s.kind === 'bargate') consider('bargate', s.data?.open ? '关上 栅栏门' : '打开 栅栏门', s, d, true)
    else if (s.kind === 'glasswin' && !s.data?.partition) consider('glasswin', DECOR_VIEWS.glasswin.label, s, d, true)
    else if (s.kind === 'windowtrap') consider('windowtrap', s.data?.triggered ? '查看 窗户（已无异常）' : '查看 未涂黑的窗户', s, d, true)
    else if (s.kind === 'windowblack') consider('windowblack', DECOR_VIEWS.windowblack.label, s, d, true)
    else if (s.kind === 'graffiti') consider('graffiti', DECOR_VIEWS.graffiti.label, s, d, true)
    else if (s.kind === 'statue') consider('statue', DECOR_VIEWS.statue.label, s, d, true)
    else if (s.kind === 'bigpainting') consider('bigpainting', DECOR_VIEWS.bigpainting.label, s, d, true) // v53b：L3 大幅画作
    else if (s.kind === 'megdoc') consider('megdoc', s.data?.doc === 'backrooms_basics' ? '阅读马尼拉玛丽基金会文件' : '阅读 M.E.G. 文档', s, d, true)
    else if (s.kind === 'landmark') consider('landmark', '查看 定居点地标', s, d, true)
    else if (s.kind === 'invitation') consider('landmark', '阅读 烫金邀请函', s, d, true) // v55b：邀请函=地标式可交互装饰（弹地标卡前往原住民）
    else if (s.kind === 'valve') consider('valve', s.data?.on ? '关闭 蒸汽阀门' : '打开 蒸汽阀门', s, d, true)
    else if (s.kind === 'phonograph') consider('phonograph', s.data?.on === 0 ? '摇起 留声机（恢复播放）' : '停下 留声机', s, d, true) // v55：L5 留声机启停
    else if (s.kind === 'table' && eng.levelDef.id === 5 && s.data?.drink === 1 && s.data?.searched !== 1) consider('drinktable', '拿取 桌上的饮料', s, d, true) // v55：L5 休息室桌上饮料
    else if (s.kind === 'booth' && !eng.player.leverPulled) consider('lever', '扳动 电源拉杆', s, d, true)
    else if (s.kind === 'server' && s.locked) consider('server', '刷门禁卡 进入', s, d, eng.hasPocket('keycard'))
    else if (s.kind === 'vending') consider('vending', '使用 自动售货机', s, d, true)
    else if (s.kind === 'frontdesk') consider('frontdesk', '与前台交易', s, d, true)
    else if (s.kind === 'l6stairwell') consider('l6stairwell', band === 0 ? '沿废弃楼梯井下行' : '沿废弃楼梯井返回地表', s, d, true)
    else if (s.kind === 'obelisk') consider('obelisk', '辨认 方尖碑上的字迹', s, d, true)
    else if (s.kind === 'l10digsite') consider('l10digsite', s.data?.dug ? '旧挖掘点（已经被惊动）' : '挖掘 旧挖掘点（3 秒）', s, d, true)
  }
  // v35：NPC 与其他类别统一竞争，玩家正对 NPC 时不再被附近容器/出口抢走交互。
  for (const n of eng.npcs) {
    if (n.dead || n.hostile) continue // v39：尸体与敌对员工不可交谈
    if ((n.floor ?? 0) !== band) continue // v46：隔层不可交谈（夹楼 NPC 须上到 2F）
    const npcBase = floorHeight(m, n.x, n.y, n.floor ?? band)
    const { radius: bodyRadius, height: bodyHeight } = NPC_INTERACTION_BODY
    const surfaceDistance = Math.max(0, Math.hypot(n.x - p.x, n.y - p.y) - bodyRadius)
    const nz = npcBase + bodyHeight * 0.5
    considerTarget({ kind: 'npc', label: `与 ${n.def.name} 交谈`, npc: n }, n.x, n.y, nz, n.floor ?? band,
      INTERACT_RANGE.npc, true, bodyRadius,
      volumeAt(n.x, n.y, npcBase - 0.03, bodyRadius, bodyHeight + 0.06),
      surfaceDistance, undefined, bodyHeight * 0.5)
  }
  // v45：实体「杰瑞」——驯服提示随状态变化；v47：冷却剩余在提示中显示。
  for (const e of m.entities) {
    if (e.dead || e.def.type !== 'jerry') continue
    const entityBand = bandOfZ(e.z)
    if (entityBand !== band) continue
    // 重制：判定盒随杰瑞离地高度（栖木 1.48m / 神父肩头）抬高，并排除栖木自身遮挡——与 npc.aimJerry 同一口径
    const box = jerryInteractBox(eng, e)
    considerTarget({
        kind: 'jerry',
        label: eng.jerryContactCd > 0
          ? `接触 鹉主杰瑞（冷却 ${Math.ceil(eng.jerryContactCd)}s）`
          : eng.jerryTamed ? '接触 鹉主杰瑞（已驯服）' : '接触 鹉主杰瑞（教化 +25 · 对其使用杏仁水可驯服）',
        ent: e,
      }, box.x, box.y, box.z, entityBand, INTERACT_RANGE.npc, true, box.radius,
      box.volume, box.surfaceDistance, box.perch, box.verticalRadius)
  }
  // v58：小小（L7 环形场的可对话实体）——未被激怒时可交谈；激怒后仍可选中但拒绝对话
  for (const e of m.entities) {
    if (e.dead || e.def.type !== 'tiny') continue
    // 水生实体的 z 是真实水深，不能直接用 bandOfZ：L7 深水中的负高度会被误判为
    // L6 式地下层，导致同处水中的玩家永远无法选中小小。
    const entityBand = entityFloorBand(m, e)
    if (entityBand !== band) continue
    const scale = e.def.scale ?? 1
    const bodyRadius = 0.62 * scale
    const bodyHeight = 2.82 * scale
    const surfaceDistance = Math.max(0, Math.hypot(e.x - p.x, e.y - p.y) - bodyRadius)
    considerTarget({
        kind: 'tiny',
        label: e.provoked ? '小小（已被激怒，不再对话）' : '与 小小 交谈',
        ent: e,
      }, e.x, e.y, e.z + bodyHeight * 0.48, entityBand, INTERACT_RANGE.npc, true, bodyRadius,
      volumeAt(e.x, e.y, e.z - 0.18 * scale, bodyRadius, bodyHeight), surfaceDistance, undefined, bodyHeight * 0.48)
  }
  // v77：穿着人皮的窃皮者——看上去就是个流浪者，可以搭话；但它只会重复几句借来的话，不会进入对话
  for (const e of m.entities) {
    if (e.dead || e.def.type !== 'skinstealer' || e.disguised !== 'human') continue
    const entityBand = entityFloorBand(m, e)
    if (entityBand !== band) continue
    const bodyRadius = 0.3, bodyHeight = 1.85
    const surfaceDistance = Math.max(0, Math.hypot(e.x - p.x, e.y - p.y) - bodyRadius)
    considerTarget({ kind: 'skinstealer', label: '与 流浪者 交谈', ent: e }, e.x, e.y, e.z + bodyHeight * 0.5, entityBand, INTERACT_RANGE.npc, true, bodyRadius,
      volumeAt(e.x, e.y, e.z, bodyRadius, bodyHeight), surfaceDistance, undefined, bodyHeight * 0.5)
  }
  // v51：人制品售货机（Entity 36）——正面取货 / 背面看标语。
  for (const e of m.entities) {
    if (e.dead || e.def.type !== 'vendingmachine' || e.activated) continue
    const entityBand = bandOfZ(e.z)
    if (entityBand !== band) continue
    // 正/背面：玩家在机器朝向的一侧为正面
    const behind = Math.cos(e.facing) * (p.x - e.x) + Math.sin(e.facing) * (p.y - e.y) < 0
    considerTarget({
        kind: 'vendingmachine',
        label: behind ? '查看 人制品售货机（背面）' : '取出 人制品',
        ent: e, vmBack: behind,
      }, e.x, e.y, e.z + 0.95, entityBand, INTERACT_RANGE.object, true, 0.5,
      volumeAt(e.x, e.y, e.z, 0.5, 1.9))
  }
  eng.interactTarget = choice.current?.target ?? (eng.seating ? { kind: 'stand', label: '起身', s: eng.seating.structure } : null)
}

function sameInteractionTarget(a: Engine['interactTarget'], b: Engine['interactTarget']): boolean {
  if (!a || !b || a.kind !== b.kind) return false
  return a.s === b.s && a.it === b.it && a.e === b.e && a.npc === b.npc && a.ent === b.ent
}

export function doInteract(eng: Engine) {
  const scanned = eng.interactTarget
  if (!scanned || !eng.map) return
  // 输入到真正执行之间再次跑同一套距离、楼层带、硬准星与三维 LOS；目标发生变化则本次按键作废。
  scanInteract(eng)
  const t = eng.interactTarget
  if (!sameInteractionTarget(scanned, t) || !t) return
  const p = eng.player, m = eng.map
  switch (t.kind) {
    case 'sit': { if (t.s) beginSitting(eng, t.s); break }
    case 'stand': { standUp(eng); break }
    case 'careerField': { recordField(eng,String(t.s?.data?.faction) as CareerId);break }
    case 'settlementstation': {
      const s=t.s!;
      if(s.kind.startsWith('trade_')&&!s.data?.facility&&s.data?.cargoId===undefined){eng.msg(s.kind==='trade_car'?'保险库固定藏品：浅蓝色 250 GT。仅作展示，不可驾驶或搜刮。':String(s.data?.label??'贸易设施，尚未配置现场业务。'),'lore');break}
      const id=String(t.s?.data?.faction) as CareerId
      eng.activeStation=String(t.s?.data?.room ?? '')
      eng.emit({kind:(t.s?.data?.services as string[]|undefined)?.includes('career')?'faction':'facility',text:id})
      break
    }
    case 'l11guide': {
      if (eng.l11World) eng.l11World.marks = ['archive','metro','L9','L10']
      eng.msg('已记下公共档案馆、地铁和两条出城路线的位置。道路、建筑与出口保持稳定。','system')
      break
    }
    case 'l11inspect': {
      const prop=t.s?.data?.prop
      if (prop === 'sink') { p.thirst=Math.min(100,p.thirst+18);eng.msg('自来水仍在正常供应。你喝下了一些清水。（口渴 +18）','system') }
      else if (prop === 'lockedlift') eng.msg('这部分楼层暂不开放。电梯已经停用，无法进入。','system')
      else eng.msg('附近的告示记录着未经确认的空间异常，护栏阻止你继续接近。','lore')
      break
    }
    case 'exit': {
      const e = t.e
      if (e) eng.takeExit(e.def)
      break
    }
    case 'l10drink': {
      if (!eng.l10Action) eng.l10Action = { kind: 'drink', t: 0, dur: 2, x: p.x, y: p.y }
      break
    }
    case 'l10digsite': {
      const s = t.s
      if (!s || s.data?.dug) { eng.msg('坑边的土已经塌回去了。下面重新归于安静。', 'system'); break }
      if (!s.data?.sid) s.data = { ...s.data, sid: Math.floor(Math.random() * 1e9) }
      eng.l10Action = { kind: 'dig', t: 0, dur: 3, sid: Number(s.data.sid), x: s.x + s.w / 2, y: s.y + s.h / 2 }
      eng.noiseEvent(p.x, p.y, 7, false)
      break
    }
    case 'l6stairwell': {
      eng.switchL6Floor(bandOfPlayerZ(m, p.z,p.x,p.y) === 0 ? -1 : 0, 'stairs')
      break
    }
    case 'obelisk': {
      eng.msg('方尖碑高得没入黑暗。刻痕像文字，又像某种从未属于人类的坐标。', 'lore')
      break
    }
    case 'item': {
      // v12：拾取 scanInteract 选中的同一物品（仍在地上才有效）
      const bi = t.it && m.items.includes(t.it) ? t.it : null
      if (bi) {
        const mpTake = () => eng.emit({ kind: 'mpevent', mp: { t: 'takeItem', id: bi.id } }) // v58：联机——先到先得共享物资（广播移除）
        if (bi.fake) { m.items = m.items.filter((i) => i !== bi); if (m.inf) m.inf.taken.add(bi.id); mpTake(); return }
        // v34：致新流浪者的纸条——查看即收录图鉴「文档」（不入背包，归宿是文档存档）
        if (bi.type === 'welcomenote') {
          m.items = m.items.filter((i) => i !== bi)
          if (m.inf) m.inf.taken.add(bi.id)
          mpTake()
          audio.pickup()
          eng.emit({ kind: 'doc', text: 'welcome_note' })
          eng.msg('纸条已存档到图鉴 ·「文档」。', 'system')
          break
        }
        // 手电筒：副手空着时拾取即自动装备（开局引导）
        if (bi.type === 'flashlight' && !p.equip.offhand) {
          m.items = m.items.filter((i) => i !== bi)
          if (m.inf) m.inf.taken.add(bi.id)
          mpTake()
          p.equip.offhand = { type: 'flashlight', count: 1 }
          p.flashlight = true
          eng.syncPassives()
          audio.pickup()
          eng.msg('拾取 手电筒——已自动装到【副手】。', 'loot')
          eng.emit({ kind: 'toast', text: '+1 手电筒（副手）' })
          break
        }
        const n = bi.count ?? 1 // 整叠丢弃的地面物品带堆叠数量
        let got = 0
        for (let k = 0; k < n; k++) if (eng.addItem(bi.type)) got++
        if (got > 0) {
          if (got >= n) {
            m.items = m.items.filter((i) => i !== bi)
            if (m.inf) m.inf.taken.add(bi.id) // v17：防止窗口重载后物品复活
            mpTake()
          } else {
            bi.count = n - got // 背包装不下：剩余的留在原地
            eng.msg(`背包已满，${n - got} 个 ${itemName(bi.type)} 留在地上。`, 'system')
          }
          audio.pickup(bi.type === 'tape')
          if (bi.type === 'tape') { p.tapes += got; eng.msg(`拾取 磁带（${p.tapes}/${WIN_TAPES}）`, 'lore') }
          eng.emit({ kind: 'toast', text: `+${got} ${itemName(bi.type)}` })
        } else eng.msg('背包已满。', 'system')
      }
      break
    }
    case 'crate': case 'corpse': case 'car': case 'cabinet': case 'dresser': case 'megcrate':
    case 'locker': case 'toolbox': case 'suitcase': case 'fridge': case 'safebox':
    case 'mailbox': case 'barrel': case 'bookcase': case 'bonepile': case 'campstall':
    case 'elecbox': { // v51：L3 配电箱（统一容器表成员，漏登记会导致显示可交互但按键无响应）
      const kind = t.kind
      // v12：搜索 scanInteract 选中的同一容器（不再是数组序第一个同类容器）
      // 距离、楼层、准星与 LOS 已由执行前的统一重扫校验；此处只验证目标身份。
      const s = t.s && t.s.kind === kind ? t.s : null
      if (!s) return
      // v18：空容器直接提示（不出面板、不出进度条）
      const leftover = s.data?.lootItems as string[] | undefined
      if (s.looted || (s.data?.searched && (!leftover || leftover.length === 0))) {
        s.looted = true
        eng.msg('容器是空的。', 'system')
        return
      }
      if (!s.data?.sid) s.data = { ...s.data, sid: Math.floor(Math.random() * 1e9) }
      const C = CONTAINERS[kind] ?? CONTAINERS.crate
      const label = s.data?.manilaTable ? '桌下橱柜' : C.label
      // v18：已搜索过且仍有剩余物品 → 免进度条，直接打开面板显示之前没拿完的物品
      if (s.data?.searched && leftover && leftover.length > 0) {
        eng.lootPanel = { sid: s.data.sid as number, label, items: leftover }
        audio.searchDone()
        eng.emit({ kind: 'lootpanel' })
        return
      }
      if (C.gate === 'carkey' && !eng.hasPocket('carkey')) { eng.msg('后备箱锁着，需要车钥匙（放在口袋栏生效）。', 'system'); return }
      if (C.gate === 'crowbar' && !eng.hasItem('crowbar')) { eng.msg('转盘锁纹丝不动。得用撬棍撬铰链。', 'system'); return }
      if (kind === 'crate' && !eng.hasItem('crowbar') && Math.random() < 0.5) { eng.msg('箱子钉死了，也许需要撬棍。', 'system'); return }
      // v18：首次搜索——内容物在搜索发起时生成并持久（即使中断重搜也不刷新）
      if (!Array.isArray(s.data?.lootItems)) s.data = { ...s.data, lootItems: eng.rollLoot(kind) }
      eng.searching = { sid: s.data.sid as number, t: 0, dur: C.dur, label }
      audio.searchStart()
      eng.noiseEvent(p.x, p.y, 6, false) // 翻找容器的声音会被听见（肢团）
      break
    }
    // ============ v23：新层级的可交互物 ============
    case 'lightswitch': {
      // Wikidot Level 6「世界最安静的房间」：那个人声称找到了电灯开关，会不断恳求来访者去拨动它。
      // 官方警告只有一句：不要拨。
      const s = t.s
      if (!s) return
      if (s.data?.flipped) { eng.msg('开关已经在另一侧了。什么也没有发生过。', 'system'); return }
      s.data = { ...s.data, flipped: 1 }
      audio.uiTick()
      eng.msg('你拨动了开关。', 'system')
      eng.msg('……什么都没有亮起来。但走廊里所有的声音，在这一瞬间同时停了。', 'damage')
      p.sanity = Math.max(0, p.sanity - 22)
      eng.emit({ kind: 'sanityhit' })
      // 拨开关会把本层所有「模仿者」引到你这里——它们一直在等有人拨它
      for (const e of m.entities) if (!e.dead && e.def.type === 'mimicry') { e.state = 'chase'; e.targetX = p.x; e.targetY = p.y }
      audio.aggro()
      break
    }
    case 'roadsign': {
      const sign = t.s
        if (sign?.data?.avenue === 1) {
          const inf = m.inf
          const currentSeq = Number(sign.data.seq ?? 0)
          const nextWorldX = Number(sign.data.nextX)
          const nextWorldY = Number(sign.data.nextY)
        const playerWorldX = p.x + (inf?.ox ?? 0)
        const playerWorldY = p.y + (inf?.oy ?? 0)
        const dx = nextWorldX - playerWorldX, dy = nextWorldY - playerWorldY
        const distance = Math.max(0, Math.round(Math.hypot(dx, dy)))
        // 地图坐标 +y 朝南；将角度量化为玩家容易理解的八方位。
          const dirs = ['东', '东南', '南', '西南', '西', '西北', '北', '东北']
          const dirIndex = Math.round((Math.atan2(dy, dx) + Math.PI * 2) / (Math.PI / 4)) % 8
          const nextName = sign.data.final === 1 ? '“第九大道”洞口' : '下一块“第九大道”路标'
          // 先把玩家正在查看的路标登记为已知，再登记下一站。
          // markAvenueLandmark 内部使序号单调递增：跳过 4 号先交互 5 号时，4/5 号都是旧标记，6 号仍是当前目标。
          eng.markAvenueLandmark(currentSeq, sign.x + sign.w / 2 + (inf?.ox ?? 0), sign.y + sign.h / 2 + (inf?.oy ?? 0), 'sign')
          eng.markAvenueLandmark(currentSeq + 1, nextWorldX, nextWorldY, sign.data.final === 1 ? 'exit' : 'sign')
          eng.msg(`第九大道 · ${currentSeq + 1}号路标`, 'lore')
          eng.msg(`${nextName}已标记在地图上，位于${dirs[dirIndex]}方向，约 ${distance} 米。`, 'system')
        if (sign.data.final === 1) {
          const avenueExit = m.exits.find(e2 => e2.def.kind === 'ninthroad')
          if (avenueExit) avenueExit.discovered = true
        }
      } else {
        const ex = eng.nearestExit()
        const R = DECOR_VIEWS.roadsign.msgs!
        eng.msg(R[0].text, R[0].type)
        if (ex) { for (const e2 of m.exits) e2.discovered = true; eng.msg(R[1].text, R[1].type) }
      }
      audio.uiTick()
      break
    }
    case 'l9arrowsign': {
      const sign = t.s && t.s.kind === 'l9arrowsign' ? t.s : null
      if (!sign) return
      const inf = m.inf
      const nextX = Number(sign.data?.nextX ?? 0), nextY = Number(sign.data?.nextY ?? 0)
      const px = p.x + (inf?.ox ?? 0), py = p.y + (inf?.oy ?? 0)
      const dx = nextX - px, dy = nextY - py
      const dirs = ['东', '东南', '南', '西南', '西', '西北', '北', '东北']
      const di = Math.round((Math.atan2(dy, dx) + Math.PI * 2) / (Math.PI / 4)) % 8
      const seq = Number(sign.data?.seq ?? 1), total = Number(sign.data?.total ?? 6)
      eng.msg(`箭头路牌 ${seq}/${total}：箭头指向${dirs[di]}。`, 'lore')
      eng.msg(`下一块路牌约在 ${Math.round(Math.hypot(dx, dy))} 米外；道路会继续变宽、变得更像城市。`, 'system')
      audio.uiTick()
      break
    }
    case 'l9stair': {
      eng.msg('楼梯本身很完整，但通往二层的入口被厚木板和一把没有锁孔的挂锁封死了。', 'lore')
      eng.msg('二层目前无法进入。', 'system')
      audio.uiTick()
      break
    }
    case 'braille': {
      eng.msg(`指尖摸到一行刻痕：${BRAILLE_MARKS[Math.floor(Math.random() * BRAILLE_MARKS.length)]}`, 'lore')
      p.sanity = Math.min(100, p.sanity + DECOR_VIEWS.braille.sanity)
      audio.uiTick()
      break
    }
    case 'arcadecab': {
      // Wikidot Level 11：位置不合常理的街机柜——任何交互都会把你送去 Level 25
      eng.msg('屏幕亮了。它没有投币口，但它开始运行了。', 'lore')
      const ad = Math.floor(Math.random() * NORMAL_LEVELS)
      eng.transition = { anim: 'glitch', t: 0, dest: ad }
      eng.emit({ kind: 'transition', anim: 'glitch', cutIn: levelDefOf(ad)?.entryAnim, dest: ad })
      break
    }
    case 'endletters': {
      for (const dm of DECOR_VIEWS.endletters.msgs!) eng.msg(dm.text, dm.type)
      p.sanity = Math.max(0, p.sanity + DECOR_VIEWS.endletters.sanity)
      break
    }
    case 'clipfuse': {
      for (const dm of DECOR_VIEWS.clipfuse.msgs!) eng.msg(dm.text, dm.type)
      p.sanity = Math.max(0, p.sanity + DECOR_VIEWS.clipfuse.sanity)
      eng.emit({ kind: 'sanityhit' })
      break
    }
    case 'statue': {
      // v51：L3 铁栅栏后的风化希腊女像（纯氛围查看，同 clipfuse/endletters 惯例）
      for (const dm of DECOR_VIEWS.statue.msgs!) eng.msg(dm.text, dm.type)
      p.sanity = Math.max(0, p.sanity + DECOR_VIEWS.statue.sanity)
      eng.emit({ kind: 'sanityhit' })
      break
    }
    case 'bigpainting': {
      // v53b：L3 大幅画作——先播报画作描述（按 data.tex），再随机展开一页笔记残页
      // （wikidot L3 多页笔记纸转录，志莽行手书风格文档；见 content/docs.ts L3_NOTES）
      // v55：按层级区分——L5 古典肖像/风景画只播报画作描述（不给 L3 笔记残页文档）
      const s = t.s && t.s.kind === 'bigpainting' ? t.s : null
      const tex = s?.data?.tex as string | undefined
      if (eng.levelDef.id === 5) {
        eng.msg(
          tex === 'l5_portrait1.png'
            ? '古典肖像：黑礼服贵族侧身而立，白领巾一丝不苟。他的眼睛像是在跟着你走。'
            : tex === 'l5_portrait2.png'
              ? '古典夫妇像：长裙贵妇与礼帽绅士并肩——两人的嘴角都被岁月磨平了，看不出是不是在笑。'
              : tex === 'l5_portrait3.png'
                ? '骑马像：骑手挺直腰背，马的眼神温顺。画的右下角没有签名，只有一道指甲划过的痕。'
                : '一幅风景油画：暗色的山峦与水面，笔触殷勤得近乎固执。',
          'lore',
        )
        p.sanity = Math.max(0, p.sanity + DECOR_VIEWS.bigpainting.sanity)
        eng.emit({ kind: 'sanityhit' })
        audio.uiTick()
        break
      }
      eng.msg(
        tex === 'l3_art_skeleton.png'
          ? '大幅画布上是一幅带翅膀的骷髅——它侧坐在桌案旁，烛火尚未燃尽。'
          : tex === 'l3_art_sketch.png'
            ? '整块白画布被狂乱的炭线涂满，夹着写不成句的字迹。'
            : '大幅画布上是一尊吹着长号的天使立像——它的脸被人用力涂抹掉了，像出于愤怒。',
        'lore',
      )
      p.sanity = Math.max(0, p.sanity + DECOR_VIEWS.bigpainting.sanity)
      eng.emit({ kind: 'sanityhit' })
      eng.msg('画框下缘钉着一页笔记，字迹疯狂而颤抖——', 'lore')
      eng.emit({ kind: 'doc', text: L3_NOTE_IDS[Math.floor(Math.random() * L3_NOTE_IDS.length)] })
      audio.uiTick()
      break
    }
    case 'handspike': {
      for (const dm of DECOR_VIEWS.handspike.msgs!) eng.msg(dm.text, dm.type)
      p.sanity = Math.max(0, p.sanity + DECOR_VIEWS.handspike.sanity)
      break
    }
    case 'hoteldoor': {
      // v12：开/关/撬 scanInteract 选中的同一扇门（根因修复：旧版按数组序找第一扇门，
      // 上锁门与普通门相邻时提示「打开 房门」却触发上锁门）
      const s = t.s && t.s.kind === 'hoteldoor' ? t.s : null
      if (!s) return
      if (s.data?.careerDoor && Number(s.data.access)>actualRank(eng,String(s.data.faction) as CareerId)) { eng.msg('该房间需要相应的专业资格。公共走廊与出口始终开放。','system'); return }
      if (s.data?.sealed) {
        // v41：L2 特殊锁死门——撬棍/万能钥匙/斧头全部无效（锁的结构闻所未闻）
        eng.msg('这扇门纹丝不动，锁的结构闻所未闻。', 'system')
        audio.uiTick()
        return
      }
      if (s.data?.locked) {
        if (s.data?.staff === 1 && eng.hasPocket('keycard')) {
          s.data = { ...s.data, locked: 0, open: 1 }
          s.solid = false
          audio.uiTick()
          eng.msg('你刷员工卡打开了员工门。', 'system')
          eng.emit({ kind: 'mpevent', mp: { t: 'door', x: s.x + (m.inf?.ox ?? 0), y: s.y + (m.inf?.oy ?? 0), open: true } })
        } else if (eng.hasItem('axe') && eng.axeDur > 0) {
          // v32：斧头破门——消耗 1 点耐久（共 5 点，耗尽斧头报废）
          eng.axeDur--
          s.data = { ...s.data, locked: 0, open: 1 }
          s.solid = false
          audio.hit()
          eng.noiseEvent(p.x, p.y, 16, true) // 破门巨响引来实体
          if (eng.axeDur <= 0) {
            eng.consumeItem('axe')
            eng.axeDur = eng.hasItem('axe') ? 5 : 0
            eng.msg('你一斧劈开了门锁——斧刃崩断，斧头报废了！', 'damage')
          } else {
            eng.msg(`你一斧劈开了门锁！（斧头耐久剩余 ${eng.axeDur}）`, 'system')
          }
        } else if (eng.hasPocket('skeleton')) {
          s.data = { ...s.data, locked: 0, open: 1 }
          s.solid = false
          eng.msg('黄铜万能钥匙转了一圈——锁开了。', 'loot')
          audio.pickup()
        } else if (eng.hasItem('crowbar')) {
          s.data = { ...s.data, locked: 0, open: 1 }
          s.solid = false
          eng.msg('你用撬棍猛地撬开了门锁，巨响在走廊里回荡。', 'system')
          audio.hit()
          eng.noiseEvent(p.x, p.y, 14, true) // 撬锁巨响引来实体
        } else {
          eng.msg('门锁死了。需要撬棍撬开，或一把万能钥匙。', 'system')
        }
        return
      }
      const open = s.data?.open ? 0 : 1
      s.data = { ...s.data, open }
      s.solid = !open
      // v58：联机——门开合状态同步（先到先得共享世界；坐标转世界系，跨端窗口无关）
      eng.emit({ kind: 'mpevent', mp: { t: 'door', x: s.x + (m.inf?.ox ?? 0), y: s.y + (m.inf?.oy ?? 0), open: open === 1 } })
      // v57m：L7 门廊尽头舱门——开门瞬间海侧重力捕获门边玩家，直接甩出舱门落入海中
      if (open && s.data?.l7porch === 1) forceL7PorchDrop(eng)
      if (!open) {
        // v41：关门时玩家站在门洞——把玩家推到最近的可走一侧（否则嵌进实心门体卡死）
        const m = eng.map!
        const r = PLAYER_RADIUS
        if (p.x > s.x - r && p.x < s.x + s.w + r && p.y > s.y - r && p.y < s.y + s.h + r) {
          const f = (x: number, y: number) => x >= 0 && y >= 0 && x < m.w && y < m.h && m.tiles[y * m.w + x] === 1
          const ax = Math.floor(s.x + s.w / 2), ay = Math.floor(s.y + s.h / 2)
          const alongY = s.data?.l0Door ? s.w>s.h : !f(ax - 1, ay) && !f(ax + 1, ay) // Thin L0 jambs come from architecture, not wall tiles.
          const cand = alongY
            ? [{ x: p.x, y: s.y - r - 0.12 }, { x: p.x, y: s.y + s.h + r + 0.12 }]
            : [{ x: s.x - r - 0.12, y: p.y }, { x: s.x + s.w + r + 0.12, y: p.y }]
          const ok = (c: { x: number; y: number }) => canOccupy(m, c.x, c.y, r, { z: p.z, crouch: p.crouching })
          const d0 = Math.hypot(cand[0].x - p.x, cand[0].y - p.y)
          const d1 = Math.hypot(cand[1].x - p.x, cand[1].y - p.y)
          const [near, far] = d0 <= d1 ? [cand[0], cand[1]] : [cand[1], cand[0]]
          if (ok(near)) { p.x = near.x; p.y = near.y }
          else if (ok(far)) { p.x = far.x; p.y = far.y }
        }
      }
      eng.msg(open ? '门吱呀一声开了。' : '你轻轻带上了门。', 'system')
      audio.uiTick()
      break
    }
    case 'ropeanchor': {
      // v57m：L7 门廊入口系缆桩——使用尼龙绳固定，绳索从门廊出口垂到海面，之后可攀爬返回
      const s = t.s && t.s.kind === 'ropeanchor' ? t.s : null
      if (!s) return
      if (s.data?.deployed === 1) {
        eng.msg('尼龙绳已经系好了。走到海面上的绳底，按住前进即可攀回门廊。', 'system')
        audio.uiTick()
        return
      }
      if (!eng.hasItem('rope')) {
        eng.msg('这里有一个生锈的系缆桩。要回到门廊，你得先有一卷尼龙绳。', 'system')
        audio.uiTick()
        return
      }
      eng.consumeItem('rope')
      s.data = { ...s.data, deployed: 1 }
      eng.msg('你把尼龙绳牢牢系在系缆桩上。绳索从门廊出口垂向海面，像一条勉强可攀的路。', 'lore')
      audio.pickup()
      break
    }
    case 'lift': {
      // v13：电梯——交互后轿厢垂直送达另一层（脚本化乘降，期间锁定移动）
      const s = t.s && t.s.kind === 'lift' ? t.s : null
      if (!s || eng.ride) return
      const from = bandOfZ(p.z) === 1 ? FLOOR_H : 0
      const to = from === 0 ? FLOOR_H : 0
      p.x = s.x + 0.5; p.y = s.y + 0.5 // 走进轿厢
      eng.ride = { sx: p.x, sy: p.y, from, to, t: 0 }
      audio.uiTick()
      eng.msg(to > 0 ? '电梯抖动了一下，缓缓上升……' : '电梯抖动了一下，缓缓下降……', 'system')
      break
    }
    case 'rollerdoor': case 'glassdoor': {
      const s = t.s && t.s.kind === t.kind ? t.s : null
      if (!s) return
      if(s.data?.tradeDoor&&!s.data.open&&!bntgDoorAllowed(eng,s)){eng.msg('普通库区需要正式雇员资格，高价值库需要资深物流专员资格。当前盘点任务仅开放指定货位。','system');break}
      if (t.kind === 'rollerdoor' && s.data?.locked) {
        eng.msg('卷帘门锁死了，纹丝不动。门缝里黑漆漆的，看不清里面堆了什么。', 'system')
        break
      }
      const open = s.data?.open ? 0 : 1
      if(!open&&s.kind==='glassdoor'&&s.data?.l4){
        const occupied=structColliders({...s,solid:true},eng.map!).some(b=>{
          const dx=p.x-Math.max(b.x0,Math.min(b.x1,p.x)),dy=p.y-Math.max(b.y0,Math.min(b.y1,p.y))
          return dx*dx+dy*dy<=(PLAYER_RADIUS+.03)**2
        })
        if(occupied){eng.msg('请先离开门口，玻璃门才能合上。','system');break}
      }
      s.data = { ...s.data, open }
      s.solid = !open
      eng.msg(
        open
          ? t.kind === 'rollerdoor' ? '卷帘门哗啦一声升起，室外的空气涌了进来。' : '玻璃门无声滑开。'
          : t.kind === 'rollerdoor' ? '卷帘门哐当落下。' : '玻璃门合上了。',
        'system',
      )
      audio.uiTick()
      break
    }
    case 'inkdoor': {
      // 维护通廊墨黑色金属门（横跨 2 格门洞，交互开/关；关门时实心阻挡）
      const s = t.s && t.s.kind === 'inkdoor' ? t.s : null
      if (!s) return
      const open = s.data?.open ? 0 : 1
      s.data = { ...s.data, open }
      s.solid = !open
      eng.msg(open ? '墨黑色金属门吱呀一声开了——门后是一片晃眼的白。' : '你带上了墨黑色金属门。', 'system')
      audio.uiTick()
      break
    }
    case 'bargate': {
      // v51：L3 铁栅栏门（交互开/关；关门时实心阻挡，玩家站门洞则推到最近可走一侧——同 hoteldoor）
      const s = t.s && t.s.kind === 'bargate' ? t.s : null
      if (!s) return
      const open = s.data?.open ? 0 : 1
      s.data = { ...s.data, open }
      s.solid = !open
      // v58：联机——门开合状态同步（先到先得共享世界；坐标转世界系，跨端窗口无关）
      eng.emit({ kind: 'mpevent', mp: { t: 'door', x: s.x + (m.inf?.ox ?? 0), y: s.y + (m.inf?.oy ?? 0), open: open === 1 } })
      // v57m：L7 门廊尽头舱门——开门瞬间海侧重力捕获门边玩家，直接甩出舱门落入海中
      if (open && s.data?.l7porch === 1) forceL7PorchDrop(eng)
      if (!open) {
        const m = eng.map!
        const r = PLAYER_RADIUS
        if (p.x > s.x - r && p.x < s.x + s.w + r && p.y > s.y - r && p.y < s.y + s.h + r) {
          const f = (x: number, y: number) => x >= 0 && y >= 0 && x < m.w && y < m.h && m.tiles[y * m.w + x] === 1
          const ax = Math.floor(s.x + s.w / 2), ay = Math.floor(s.y + s.h / 2)
          const alongY = !f(ax - 1, ay) && !f(ax + 1, ay) // 门两侧是墙 ⇒ 通行沿 y 轴
          const cand = alongY
            ? [{ x: p.x, y: s.y - r - 0.12 }, { x: p.x, y: s.y + s.h + r + 0.12 }]
            : [{ x: s.x - r - 0.12, y: p.y }, { x: s.x + s.w + r + 0.12, y: p.y }]
          const ok = (c: { x: number; y: number }) => canOccupy(m, c.x, c.y, r, { z: p.z, crouch: p.crouching })
          const d0 = Math.hypot(cand[0].x - p.x, cand[0].y - p.y)
          const d1 = Math.hypot(cand[1].x - p.x, cand[1].y - p.y)
          const [near, far] = d0 <= d1 ? [cand[0], cand[1]] : [cand[1], cand[0]]
          if (ok(near)) { p.x = near.x; p.y = near.y }
          else if (ok(far)) { p.x = far.x; p.y = far.y }
        }
      }
      eng.msg(open ? '栅栏门哐当一声开了。' : '你带上了栅栏门，铁栏撞出一声闷响。', 'system')
      audio.uiTick()
      break
    }
    case 'megdoc': {
      // M.E.G. 文档：打开文档视图（App 侧记录到图鉴「文档」分类）
      const s = t.s && t.s.kind === 'megdoc' ? t.s : null
      if (!s) return
      audio.pickup()
      eng.emit({ kind: 'doc', text: (s.data?.doc as string) ?? 'meg_levels' })
      break
    }
    case 'landmark': {
      if(eng.player.level===11&&eng.l11World)eng.l11World.marks=['archive','metro','L9','L10']
      // v35：定居点地标——打开地标卡（据点介绍 + 前往/离开）
      // v55b：邀请函（invitation 结构）同走本链路（data.outpost='originals'）
      const s = t.s && (t.s.kind === 'landmark' || t.s.kind === 'invitation') ? t.s : null
      if (!s) return
      audio.uiTick()
      eng.emit({ kind: 'landmark', text: (s.data?.outpost as string) ?? 'alpha' })
      break
    }
    case 'npc': {
      // v35：与 NPC 交谈（App 打开对话窗并记录图鉴「NPC」分类）
      const n = t.npc
      if (!n) return
      // NPC 转身面向玩家（v39：工作循环的 BRC 员工不转身——他们从不停手）
      if (!n.def.workLoop) n.facing = Math.atan2(p.y - n.y, p.x - n.x)
      audio.uiTick()
      eng.emit({ kind: 'dialog', text: n.id })
      break
    }
    case 'jerry': {
      // v45：接触杰瑞——声望 +5（每次）+ 教化 +25 + 触发诵咏（驯服后不再积累教化）
      eng.contactJerry(t.ent)
      break
    }
    case 'tiny': {
      // v58：与小小对话——被激怒（噪音/肢体接触）后拒绝一切对话
      const e = t.ent
      if (!e || e.dead || e.def.type !== 'tiny') return
      if (e.provoked) {
        eng.msg('它不再回答。焦油层下的荧光斑冷冷地亮着，只剩毫不掩饰的恶意。', 'system')
        return
      }
      e.facing = Math.atan2(p.y - e.y, p.x - e.x) // 转身面向玩家
      audio.uiTick()
      eng.emit({ kind: 'dialog', text: 'tiny' })
      break
    }
    case 'skinstealer': {
      const e = t.ent
      if (!e || e.dead || e.def.type !== 'skinstealer' || e.disguised !== 'human') return
      skinStealerTalk(eng, e)
      break
    }
    case 'vendingmachine': {
      // v51：人制品售货机——背面看标语（此后背对它即激活）；正面取一份人制品
      const e = t.ent
      if (!e || e.dead || e.def.type !== 'vendingmachine') return
      if (t.vmBack) {
        eng.msg('人制品售货机 · 艾里克家族出品 ——「它于人人，人人为它，它为人人。」· 2019，亚利桑那', 'lore')
        e.activated = true // 标记：玩家已看过背面——背对它时激活
        eng.msg('看完最好也别背对它。', 'system')
      } else {
        eng.msg('格子里的金属线没有转动——一只白骨化的人手把产品推到了取货口。（获得 人制品 ×1）', 'lore')
        if (!eng.addItem('manmade')) eng.msg('背包已满，取不走这份产品。', 'system')
      }
      break
    }
    case 'glasswin': {
      if(t.s?.data?.partition)return
      const lvl = p.level
      eng.msg(lvl === 4 ? GLASSWIN_TEXT.l4 : GLASSWIN_TEXT.other, 'lore')
      p.sanity = Math.min(100, p.sanity + DECOR_VIEWS.glasswin.sanity)
      break
    }
    case 'windowtrap': {
      const s = t.s && t.s.kind === 'windowtrap' ? t.s : null
      if (!s || s.data?.triggered) { eng.msg('玻璃后面只剩黑暗。', 'system'); return }
      s.data = { ...s.data, triggered: 1 }
      p.sanity = Math.max(0, p.sanity - 14)
      eng.emit({ kind: 'sanityhit' })
      eng.camShake = Math.min(1, eng.camShake + 0.4)
      eng.msg('你凑近那扇没涂黑的窗户——里面的「房间」转过头来看你。（理智-14）', 'damage')
      audio.aggro()
      eng.noiseEvent(p.x, p.y, 12, true)
      break
    }
    case 'windowblack': {
      for (const dm of DECOR_VIEWS.windowblack.msgs!) eng.msg(dm.text, dm.type)
      p.sanity = Math.min(100, p.sanity + DECOR_VIEWS.windowblack.sanity)
      break
    }
    case 'graffiti': {
      // v17：变体房间专属 lore（涂鸦/文档，按 data.loreKind；同处再读顺延下一条）
      const s2g = t.s && t.s.kind === 'graffiti' ? t.s : null
      const loreKind = s2g?.data?.loreKind as string | undefined
      if (loreKind && GRAFFITI_LORE_KIND[loreKind] && s2g) {
        const pool2 = GRAFFITI_LORE_KIND[loreKind]
        const li2 = ((s2g.data?.loreIdx as number | undefined) ?? -1) + 1
        s2g.data = { ...s2g.data, loreIdx: li2 }
        eng.msg(pool2[li2 % pool2.length], 'lore')
        p.sanity = Math.min(100, p.sanity + DECOR_VIEWS.graffiti.sanity)
        break
      }
      eng.msg(GRAFFITI_LORE[Math.floor(Math.random() * GRAFFITI_LORE.length)], 'lore')
      // 出口方位涂鸦线索（按真实方位生成；v12：用选中的同一涂鸦）
      const s2 = t.s && t.s.kind === 'graffiti' ? t.s : null
      const ex = m.exits[0]
      if (s2 && ex && !s2.data?.readHint) {
        s2.data = { ...s2.data, readHint: 1 }
        const dx = ex.x - s2.x, dy = ex.y - s2.y
        const dir8 = ['东', '东南', '南', '西南', '西', '西北', '北', '东北']
        const idx = Math.round(((Math.atan2(dy, dx) + Math.PI * 2) % (Math.PI * 2)) / (Math.PI / 4)) % 8
        const words = ['出口', '门', '电梯', '楼梯', '通道']
        const w = words[Math.floor(Math.random() * words.length)]
        eng.msg(`下面还有一行小字：「${w}在${dir8[idx]}边，别回头。」`, 'lore')
      }
      p.sanity = Math.min(100, p.sanity + DECOR_VIEWS.graffiti.sanity)
      break
    }
    case 'valve': {
      const s = t.s && t.s.kind === 'valve' ? t.s : null
      if (!s) return
      if (s.data?.on && !p.hasGloves && !eng.hasItem('wrench')) {
        p.hp -= 6; eng.emit({ kind: 'damage' })
        eng.msg('阀门烫得吓人！你需要扳手或隔热手套。', 'damage')
        if (p.hp <= 0) eng.die('被阀门烫死了')
        return
      }
      s.data = { ...s.data, on: s.data?.on ? 0 : 1 }
      eng.msg(s.data.on ? '蒸汽喷涌而出。' : '蒸汽阀门关上了。', 'system')
      audio.uiTick()
      break
    }
    case 'phonograph': {
      // v55：L5 留声机启停——data.on=0 停播停转（唱盘动画/音乐同标记；持久化走 ChunkDynState 的 on 键）
      const s = t.s && t.s.kind === 'phonograph' ? t.s : null
      if (!s) return
      const off = s.data?.on === 0
      s.data = { ...s.data, on: off ? 1 : 0 }
      eng.msg(off ? '你摇起曲柄。唱针落下，走调的旋律又响了起来。' : '你抬起唱针。旋律戛然而止，只剩下唱盘空转的细响。', 'system')
      audio.uiTick()
      break
    }
    case 'drinktable': {
      // v55：L5 休息室桌上饮料——随机一瓶（五种风味文本各异；一次性，data.searched 持久化记态）
      const s = t.s && t.s.kind === 'table' ? t.s : null
      if (!s || s.data?.searched === 1) return
      const roll = Math.random()
      const [type, flavor] = roll < 0.3 ? ['almond', '瓶身还带着冷凝水——杏仁水。甜腻的香气让你安下心来。']
        : roll < 0.55 ? ['coffee', '一罐冷掉的咖啡。拉环还很脆，像从来没被时间碰过。']
        : roll < 0.7 ? ['luckymilk', '纸盒上印着微笑的四叶草奶牛——幸运豆奶。今天也许是走运的一天。']
        : roll < 0.88 ? ['cashew', '看起来像杏仁水……但你注意到标签的印刷歪了一毫米。腰果水。小心。']
        : ['liquidpain', '淡红色的液体在瓶里微微发光。液态痛苦。你不打算喝它，但它能派上别的用场。'] as const
      if (!eng.addItem(type)) { eng.msg('背包已满，拿不走这瓶饮料。', 'system'); return }
      s.data = { ...s.data, searched: 1 }
      eng.msg(flavor, 'loot')
      audio.pickup()
      break
    }
    case 'lever': {
      p.leverPulled = true
      eng.msg('电源拉杆已扳下。货运电梯恢复供电！', 'loot')
      audio.pickup()
      break
    }
    case 'server': {
      if (eng.hasPocket('keycard')) {
        const s = t.s && t.s.kind === 'server' && t.s.locked ? t.s : null
        if (s) { s.locked = false; s.solid = false; eng.msg('服务器机房解锁了。里面有些设备。', 'loot'); eng.addItem('battery'); eng.addItem('capacitor') }
      } else eng.msg('需要门禁卡（放在口袋栏生效）。', 'system')
      break
    }
    case 'vending': {
      if (t.s?.data?.trade) {
        // v54：免费取用——但每台机器迟早会卡：每次出货后 25% 概率卡死（data.jammed），之后无法再用
        const s = t.s
        if (s.data?.jammed) {
          eng.msg('出货口的东西卡在一半，怎么拍都不动。', 'system')
          break
        }
        const roll = Math.random()
        const out = roll < 0.32 ? 'almond' : roll < 0.58 ? 'canned' : roll < 0.84 ? 'coffee' : roll < 0.94 ? 'cashew' : 'luckymilk'
        eng.addItem(out)
        const flavor: Record<string, string> = {
          almond: '机器哐当一声，滚出一瓶杏仁水。', canned: '机器哐当一声，滚出一罐没标签的罐头。',
          coffee: '机器哐当一声，滚出一罐咖啡。', cashew: '机器哐当一声，滚出一瓶……杏仁水？标签的颜色好像有点深。',
          luckymilk: '机器哐当一声，滚出一盒印着四叶草奶牛的豆奶——你从没见过这个牌子。',
        }
        eng.msg(flavor[out], 'loot')
        if (Math.random() < 0.25) {
          s.data = { ...s.data, jammed: 1 }
          eng.msg('出货的声响卡在一半，变成一种很低的不情愿的嗡嗡声。', 'system')
        }
        break
      }
      if (p.tapes > 0 && eng.consumeItem('tape')) {
        p.tapes--
        eng.addItem('coffee'); eng.addItem('canned')
        eng.msg('售货机吞下一盘磁带，吐出了咖啡和罐头。（公平交易？）', 'lore')
      } else eng.msg('售货机上贴着字条：「只收磁带」。', 'system')
      break
    }
    case 'frontdesk': {
      if (eng.hasItem('silverware') && eng.consumeItem('silverware')) {
        eng.addItem('sedative'); eng.addItem('almond')
        eng.msg('前台铃铛自己响了。托盘上多了些东西。', 'lore')
      } else { p.sanity = Math.min(100, p.sanity + 10); eng.msg('前台空无一人，但你觉得安全了一些。（理智+10）', 'lore') }
      break
    }
  }
}
// ---------- 容器搜索 / 战利品面板 ----------
// v18：内容物生成（首次搜索发起时调用一次，结果持久在结构 data.lootItems 上）
export function rollLoot(eng: Engine, kind: string): string[] {
  const p = eng.player
  const C = CONTAINERS[kind] ?? CONTAINERS.crate
  // 本层独有物品也可能出现在容器里（容器化掉落的核心：补给不再只躺在地上）
  const levelUnique = eng.levelDef.items.map((it) => it.type)
  const loot = [...C.pool, ...levelUnique]
  const lucky = p.hasRabbit
  const n = C.n + (lucky && Math.random() < 0.4 ? 1 : 0)
  const items: string[] = []
  for (let i = 0; i < n; i++) {
    const cap = lucky ? loot.length : loot.length - 1 // 非幸运不出磁带
    items.push(loot[Math.floor(Math.random() * cap)])
  }
  // v32：小概率稀有掉落（表在 containers.ts；onceOwned=玩家已拥有一个后不再生成）
  for (const r of CONTAINER_RARE[kind] ?? []) {
    if (Math.random() >= r.p) continue
    if (r.onceOwned && eng.hasItem(r.type)) continue
    items.push(r.type)
  }
  // v32：腰果水 1/10 概率替代杏仁水（开局势能物资不受影响——那部分不走生成器）
  return items.map((t) => (t === 'almond' && Math.random() < 0.1 ? 'cashew' : t))
}

// 搜索进度完成：打开面板，内容 = 结构上持久的物品数组（拿取即同步容器剩余）
export function finishSearch(eng: Engine, s: import('../core/types').Structure) {
  s.data = { ...s.data, opened: 1, searched: 1 }
  const items = (s.data.lootItems as string[] | undefined) ?? []
  const kind = s.kind
  const label = s.data?.manilaTable ? '桌下橱柜' : CONTAINERS[kind]?.label ?? '容器'
  if (items.length === 0) {
    s.looted = true
    eng.msg('容器是空的。', 'system')
    return
  }
  eng.lootPanel = { sid: s.data!.sid as number, label, items }
  audio.searchDone()
  eng.emit({ kind: 'lootpanel' })
}

// 从战利品面板拿取一件（返回 false=背包满）
export function takeLoot(eng: Engine, i: number): boolean {
  const lp = eng.lootPanel
  if (!lp) return false
  const type = lp.items[i]
  if (!type) return false
  if (!eng.addItem(type)) { eng.msg('背包已满。', 'system'); return false }
  lp.items.splice(i, 1)
  audio.pickup(type === 'tape')
  eng.emit({ kind: 'toast', text: `+1 ${itemName(type)}` })
  if (type === 'tape') { eng.player.tapes++; eng.msg(`找到 磁带（${eng.player.tapes}/${WIN_TAPES}）`, 'lore') }
  eng.afterLootChange()
  return true
}

export function takeAllLoot(eng: Engine) {
  const lp = eng.lootPanel
  if (!lp) return
  let i = 0
  while (lp.items.length && i++ < 20) {
    if (!eng.takeLoot(0)) break
  }
}

export function closeLootPanel(eng: Engine) {
  eng.afterLootChange()
  eng.lootPanel = null
}

export function afterLootChange(eng: Engine) {
  const lp = eng.lootPanel
  if (lp && lp.items.length === 0) {
    // 容器搜空：状态可见
    const s = eng.map?.structures.find((x) => x.data?.sid === lp.sid)
    if (s && !s.looted) {
      s.looted = true
      eng.emit({ kind: 'mpevent', mp: { t: 'loot', sid: lp.sid } }) // v58：联机——容器搜空同步（先到先得）
    }
  }
}




