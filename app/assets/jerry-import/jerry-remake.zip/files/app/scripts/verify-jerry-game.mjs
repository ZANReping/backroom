// 鹉主杰瑞重制：在真实运行的游戏里验收（Level 274、真实渲染器/AI/交互/HUD）。
// 先在 3374 端口起开发服务（npx vite --port 3374 --strictPort --host 127.0.0.1），再按阶段运行：
//   node scripts/verify-jerry-game.mjs launch                 启动本脚本专属无头 QA 浏览器（--headless=new、.cache/jerry-game-qa、调试端口 9375）
//   node scripts/verify-jerry-game.mjs enter [classic|realistic]  进入 L274（可重复，直到进入）
//   node scripts/verify-jerry-game.mjs shots [classic|realistic]  截图：栖木 / 神父肩上（正面+斜侧）/ 扑击 / 木僵镜头
//   node scripts/verify-jerry-game.mjs aim                    准星实测：对准横杆上的杰瑞 → 交互提示 → 按 E 接触（教化 +25）
//   node scripts/verify-jerry-game.mjs close                  关闭 QA 浏览器
// 不连接任何已有浏览器；存档只写进这个独立浏览器目录的 localStorage（用于直接进入 L274），不触碰用户存档。
// JR_QA_QUERY：默认 ?cpu=1——无头 SwiftShader 一画 GPU 蒙皮网格 GPU 进程就崩溃，cpu=1 改用 CPU 蒙皮替身（真实 GPU 复验时设 JR_QA_QUERY= 关闭）。
import { spawn } from 'node:child_process'
import { mkdirSync, writeFileSync, readFileSync, rmSync } from 'node:fs'
const query = process.env.JR_QA_QUERY ?? '?cpu=1'
const base = process.env.JR_QA_URL ?? 'http://127.0.0.1:3374', port = process.env.JR_GAME_CDP ?? '9375', out = 'reports/jerry/'
mkdirSync(out, { recursive: true })
const profile = `${process.cwd()}/.cache/jerry-game-qa`, pidFile = `${process.cwd()}/.cache/jerry-game-qa.pid`
const phase = process.argv[2] ?? 'launch', mode = process.argv[3] ?? 'classic'
if (phase === 'launch') {
  rmSync(profile, { recursive: true, force: true })
  const c = spawn('chromium', ['--headless=new', '--enable-automation', `--remote-debugging-port=${port}`, `--user-data-dir=${profile}`, '--no-first-run', '--no-default-browser-check', '--no-sandbox', '--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--window-size=1600,900', 'about:blank'], { stdio: 'ignore', detached: true })
  c.unref(); writeFileSync(pidFile, String(c.pid)); console.log('QA 浏览器 pid', c.pid); process.exit(0)
}
const errors = [], report = { mode, phase, query, steps: [] }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
try {
  let page
  for (let i = 0; i < 80 && !page; i++) { await sleep(250); try { page = (await (await fetch(`http://127.0.0.1:${port}/json/list`)).json()).find((p) => p.type === 'page') } catch { /* 等浏览器 */ } }
  if (!page) throw Error('QA 浏览器未启动')
  const ws = new WebSocket(page.webSocketDebuggerUrl); await new Promise((r) => ws.addEventListener('open', r, { once: true }))
  let seq = 0; const pending = new Map()
  ws.addEventListener('message', (e) => { const r = JSON.parse(e.data); if (r.method === 'Runtime.exceptionThrown') errors.push(JSON.stringify(r.params.exceptionDetails).slice(0, 600)); if (r.method === 'Runtime.consoleAPICalled' && r.params.type === 'error') errors.push(r.params.args?.map((a) => a.value ?? a.description).join(' ').slice(0, 600)); const p = pending.get(r.id); if (p) { pending.delete(r.id); r.error ? p.reject(r.error) : p.resolve(r.result) } })
  const send = (method, params = {}) => new Promise((resolve, reject) => { const id = ++seq; pending.set(id, { resolve, reject }); ws.send(JSON.stringify({ id, method, params })) })
  const ev = async (expression) => { const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true }); if (r.exceptionDetails) throw Error(JSON.stringify(r.exceptionDetails).slice(0, 800)); return r.result?.value }
  const until = async (expr, label, tries = Number(process.env.JR_TRIES ?? 300)) => { for (let i = 0; i < tries; i++) { await sleep(300); if (await ev(`Boolean(${expr})`)) return } throw Error('超时：' + label) }
  const shot = async (n) => writeFileSync(out + n + '.png', Buffer.from((await send('Page.captureScreenshot', { format: 'png' })).data, 'base64'))
  // 无头 SwiftShader 下帧率很低（实测 <1fps）：等渲染器真正画出 n 帧（相机射线 look.ray* 与姿态才会更新）
  const frames = async (n) => { const f0 = await ev('__renderer.frameTick'); await until(`__renderer.frameTick>=${f0 + n}`, `等待 ${n} 帧`, 200) }
  const step = (name, data) => { report.steps.push({ name, ...data }); console.log(name, JSON.stringify(data)) }
  await send('Runtime.enable'); await send('Page.enable')
  const ver = await send('Browser.getVersion'), cl = await send('Browser.getBrowserCommandLine')
  if (!ver.userAgent.includes('HeadlessChrome') || !cl.arguments.includes('--headless=new') || !cl.arguments.some((a) => a.includes('jerry-game-qa'))) throw Error('不是本脚本的无头 QA 浏览器')
  await send('Emulation.setDeviceMetricsOverride', { width: 1600, height: 900, deviceScaleFactor: 1, mobile: false })
  if (phase === 'close') { await send('Browser.close').catch(() => {}); throw Error('closed') }
  const inGame = await ev(`Boolean(window.__engine && __engine.player.level===274 && __renderer?.isNearWorldReady(__engine))`).catch(() => false)
  if (phase === 'enter' && !inGame) {
    const navigated = await ev(`location.href.startsWith(${JSON.stringify(base)})`)
    if (!navigated) {
      const init = await send('Page.addScriptToEvaluateOnNewDocument', { source: `localStorage.clear();sessionStorage.clear();localStorage.setItem('br_settings',JSON.stringify({renderResolution:'native',renderScale:100,maxPixelRatio:1,dynamicRes:false,lightMode:${JSON.stringify(mode)},sceneLightLimit:16,shadowQuality:1,lightShadows:1,loadingBudgetMs:6,devMode:true}))` })
      await send('Page.navigate', { url: base + '/' + query })
      await until('window.__engine && document.querySelector(".title-menu")', '标题界面')
      await send('Page.removeScriptToEvaluateOnNewDocument', { identifier: init.identifier })
    }
    await until('window.__engine && document.querySelector(".title-menu")', '标题界面')
    const hasSave = await ev(`Boolean(localStorage.getItem('br_save_slot1'))`)
    if (!hasSave) {
      await ev(`(()=>{const raw=__engine.snapshot();localStorage.setItem('br_save_slot1',JSON.stringify({...raw,seed:274,level:274,mapSeed:274,savedAt:Date.now(),player:{...raw.player,level:274}}))})()`)
      await send('Page.reload')
      await until(`document.querySelector('.title-menu')`, '读档标题')
    }
    await ev(`(()=>{const b=[...document.querySelectorAll('.menu-btn')].find(b=>b.textContent.includes('继续游戏'));b.click()})()`)
    await sleep(600)
    await ev(`(()=>{const b=[...document.querySelectorAll('.hud-panel button')].find(b=>b.textContent.includes('继续'));b&&b.click()})()`)
    await until('__engine.player.level===274 && !__engine.paused && __renderer.isNearWorldReady(__engine)', '进入 L274', 250)
  }
  if (phase === 'enter') { step('已进入 L274', { ok: await ev(`__engine.player.level===274`) }); throw Error('enter-done') }
  if (!inGame) throw Error('还没有进入 L274，先运行 enter')
  await ev(`(()=>{const b=[...document.querySelectorAll('.hud-panel button')].find(b=>b.textContent.trim()==='▾');b&&b.click();return true})()`) // 收起开发者面板
  const J = `await import('/src/game/engine/jerryAI.ts')`
  // 把玩家放到 (x,y) 并让准星对准世界点 (tx,ty,tz)
  const placeLook = (x, y, tx, ty, tz, side = 0) => ev(`(async()=>{const I=await import('/src/game/engine/interact.ts');const e=__engine,p=e.player;p.x=${x};p.y=${y};p.z=0;p.vz=0
    const dx=${tx}-p.x,dy=${ty}-p.y;__look.yaw=Math.atan2(-dx,-dy)+${side};__look.pitch=Math.atan2(${tz}-I.interactionEyeZ(e),Math.hypot(dx,dy));return{x:+p.x.toFixed(2),y:+p.y.toFixed(2)}})()`)
  const jerryInfo = () => ev(`(async()=>{const J=${J};const e=__engine,j=J.findJerry(e),s=J.jerryState(j),R=__renderer,g=R.entityMeshes.get(j.id);let cpu=0,sk=0;g?.traverse(o=>{if(o.userData.cpuSkin&&o.visible)cpu++;if(o.isSkinnedMesh&&o.visible)sk++});
    return{mode:s.mode,alt:+s.alt.toFixed(2),x:+j.x.toFixed(2),y:+j.y.toFixed(2),meshY:g?+g.position.y.toFixed(2):null,visible:!!g?.visible,cpuSkinMeshes:cpu,gpuSkinVisible:sk,lost:R.three.getContext().isContextLost()}})()`)

  if (phase === 'shots') {
    const want = (n) => !process.env.JR_SHOTS || process.env.JR_SHOTS.split(',').includes(n)
    await ev(`(async()=>{const J=${J};const e=__engine;e.dev.god=true;e.dev.statLock=true;e.indoctrination=0;e.jerryRun.stupor=null;J.jerryState(J.findJerry(e)).spokeIntro=true;return true})()`)
    // 先走到栖木南侧（实体网格按距离创建），再等杰瑞模型就绪
    await ev(`(()=>{const e=__engine,j=e.map.entities.find(z=>z.def.type==='jerry');e.player.x=j.x;e.player.y=j.y+3.2;e.player.z=0;__look.yaw=0;__look.pitch=0;return true})()`)
    await until(`(()=>{const R=__renderer,e=__engine,j=e.map.entities.find(z=>z.def.type==='jerry'),g=j&&R.entityMeshes.get(j.id);return g&&g.visible})()`, '杰瑞模型就绪', 200)
    const take = async (name, data) => { await frames(3); step(name, { ...data, ...(await jerryInfo()) }); await shot(`game-${mode}-${name}`) }
    // 冻结 AI 并把杰瑞放回栖木、面朝南（玩家一侧）
    const resetPerch = (js = '') => ev(`(async()=>{const J=${J};const e=__engine,j=J.findJerry(e),s=J.jerryState(j);e.dev.frozenAI=true;J.forceSermon&&0;
      const bb=e.npcs.find(n=>n.id==='bluebird');if(bb){bb.sermon={phase:'rest',t:9999,lineT:0};bb.x=bb.homeX;bb.y=bb.homeY}
      s.mode='perch';s.rider=null;s.wantRider=null;s.alt=J.JERRY.perchAlt;j.x=s.homeX;j.y=s.homeY;j.facing=Math.PI/2;s.fury=0;s.pounceCd=99
      Object.assign(s,{gazeYaw:0,gazePitch:-0.15,tilt:0.25,talk:0,preen:0,shake:0,spread:0,flap:0,glide:0,pounce:0,crouch:0,scream:0,bubbleT:0});${js};return{hx:s.homeX,hy:s.homeY}})()`)
    const home = await resetPerch()
    // 1) 栖木上的杰瑞：中央走道南侧 3.2m，略仰视
    if (want('perch')) { await placeLook(home.hx, home.hy + 3.2, home.hx, home.hy, 1.25); await take('perch', {}) }
    // 1b) 近景：1.8m，歪头注视、说话（字幕气泡）
    if (want('perch-close')) { await resetPerch(`s.tilt=0.35;s.talk=0.8;s.bubbleText=J.JERRY_TALK_LINES[3];s.bubbleT=30`); await placeLook(home.hx + 0.5, home.hy + 1.7, home.hx, home.hy, 1.6); await take('perch-close', {}) }
    // 2) 青鸟神父肩上：讲道中（神父面朝南侧长椅）；正面 + 斜侧检查肩部贴合
    if (want('shoulder')) {
      const bb = await ev(`(async()=>{const J=${J};const e=__engine;e.dev.frozenAI=true;J.forceSermon(e);const n=e.npcs.find(q=>q.id==='bluebird');const s=J.jerryState(J.findJerry(e));Object.assign(s,{gazeYaw:0.2,gazePitch:-0.1,tilt:0,talk:0.6,spread:0,flap:0,crouch:0,bubbleText:J.JERRY_TALK_LINES[0],bubbleT:30});n.bubbleText=J.SERMON_LINES[0];n.bubbleT=30;return{x:n.x,y:n.y,f:n.facing}})()`)
      await placeLook(bb.x, bb.y + 2.2, bb.x, bb.y, 1.35); await take('shoulder', { bluebird: bb })
      await placeLook(bb.x + 1.6, bb.y + 1.3, bb.x, bb.y, 1.4); await take('shoulder-side', { bluebird: bb })
      await placeLook(bb.x - 0.9, bb.y - 1.2, bb.x, bb.y, 1.45); await take('shoulder-back', { bluebird: bb })
    }
    // 3) 扑击：从栖木尖啸着扑向玩家（姿态量冻结在扑击中段）
    if (want('pounce')) {
      await resetPerch()
      const pz = await ev(`(async()=>{const J=${J};const e=__engine,j=J.findJerry(e),s=J.jerryState(j);s.mode='pounce';s.fromAlt=J.JERRY.perchAlt;j.y=s.homeY+1.1;s.alt=1.3;j.facing=Math.PI/2;
        Object.assign(s,{spread:1,flap:0.35,pounce:1,scream:1,glide:0,crouch:0,talk:0,gazePitch:-0.1,bubbleText:J.JERRY_SCREAM,bubbleT:30});return{x:j.x,y:j.y}})()`)
      await placeLook(pz.x + 0.3, pz.y + 2.4, pz.x, pz.y, 1.25); await take('pounce', {})
    }
    // 4) 木僵镜头：教化越过 25 → 镜头不由自主转向杰瑞（真实 updateJerryPlayer 推动），HUD 失神叠加
    if (want('stupor')) {
      await resetPerch(`s.gazeYaw=0;s.gazePitch=-0.2;s.tilt=0.2`)
      await placeLook(home.hx + 2.2, home.hy + 2.6, home.hx + 6, home.hy + 8, 1.5) // 先看向别处
      const st = await ev(`(async()=>{const J=${J};const e=__engine,j=J.findJerry(e);e.indoctrination=24;e.jerryRun.stuporMask=0;e.jerryRun.maskInit=true;J.addIndoctrination(e,2,j);return{stupor:!!e.jerryRun.stupor,ind:e.indoctrination}})()`)
      const t0 = Date.now()
      // 无头下每帧游戏时间被钳制，木僵计时推进很慢：等到镜头已被真实 updateJerryPlayer 转到杰瑞附近（或计时过 1.5s）
      await until(`(()=>{const r=__engine.jerryRun;if(!r.stupor)return true;if(r.stupor.t>1.5)return true;const e=__engine,j=e.map.entities.find(z=>z.def.type==='jerry');const a=Math.atan2(-(j.x-e.player.x),-(j.y-e.player.y));return Math.abs(Math.atan2(Math.sin(a-__look.yaw),Math.cos(a-__look.yaw)))<0.12})()`, '木僵镜头转向', 260).catch(() => {})
      const info = await ev(`(async()=>{const J=${J};const r=__engine.jerryRun;return{t:r.stupor?+r.stupor.t.toFixed(2):null,overlay:J.jerryOverlay(__engine),yaw:+__look.yaw.toFixed(2),pitch:+__look.pitch.toFixed(2)}})()`)
      step('stupor', { ...st, ...info, waitedMs: Date.now() - t0, ...(await jerryInfo()) }); await shot(`game-${mode}-stupor`)
      // 虔诚姿态：把计时快进到醒来后的鞠躬中段（低头角度由真实 updateJerryPlayer 按计时算出），再等两帧
      await ev(`(async()=>{const J=${J};const r=__engine.jerryRun;if(r.stupor)r.stupor.t=Math.max(r.stupor.t,J.JERRY.stuporDur+J.JERRY.devotionDur*0.45);return true})()`)
      await frames(2)
      const info2 = await ev(`(async()=>{const J=${J};const r=__engine.jerryRun;return{t:r.stupor?+r.stupor.t.toFixed(2):null,overlay:J.jerryOverlay(__engine),pitch:+__look.pitch.toFixed(2)}})()`)
      step('stupor-devotion', info2); await shot(`game-${mode}-stupor-devotion`)
      await ev(`(()=>{const e=__engine;e.jerryRun.stupor=null;e.indoctrination=0;return true})()`)
    }
    await ev(`(()=>{__engine.dev.frozenAI=false;return true})()`)
    ws.close(); throw Error('shots-done')
  }

  if (phase === 'aim') {
    // 准星实测：真实渲染器把相机中心射线写进 look.ray*，引擎 scanInteract 用它选交互目标；再按真实键盘 E 触发接触
    await ev(`(async()=>{const J=${J};const e=__engine,j=J.findJerry(e),s=J.jerryState(j);e.dev.god=true;e.dev.statLock=true;e.dev.frozenAI=true;e.indoctrination=0;e.jerryContactCd=0;e.jerryRun.stupor=null;s.mode='perch';s.alt=J.JERRY.perchAlt;j.x=s.homeX;j.y=s.homeY;j.facing=Math.PI/2;return true})()`)
    const j = await jerryInfo()
    const box = await ev(`(async()=>{const J=${J};const e=__engine,j=J.findJerry(e);const b=J.jerryInteractBox(e,j);return{x:b.x,y:b.y,z:b.z}})()`)
    const res = [], part = process.env.JR_AIM_PART ?? 'all' // 无头帧率很低时可分两次跑：JR_AIM_PART=cases / contact
    for (const [name, ang, dist, dz, side] of part === 'contact' ? [] : [['南 1.7m', Math.PI / 2, 1.7, 0, 0], ['北 1.7m', -Math.PI / 2, 1.7, 0, 0], ['东 1.6m', 0, 1.6, 0, 0], ['西南 2.1m', 2.4, 2.1, 0, 0], ['对准头部', Math.PI / 2, 1.7, 0.35, 0], ['对准尾羽', Math.PI / 2, 1.7, -0.4, 0], ['偏开 0.6rad', Math.PI / 2, 1.7, 0, 0.6], ['看头顶上方 1.2m', Math.PI / 2, 1.7, 1.2, 0], ['3.4m 外', Math.PI / 2, 3.4, 0, 0]]) {
      await placeLook(box.x + Math.cos(ang) * dist, box.y + Math.sin(ang) * dist, box.x, box.y, box.z + dz, side)
      await frames(1)
      const r = await ev(`(()=>{const e=__engine;e.scanInteract();const hud=/接触\s*鹉主杰瑞/.test(document.body.innerText);return{target:e.interactTarget?.kind??null,label:e.interactTarget?.label??null,aim:!!e.aimJerry(),hudPrompt:hud,ray:[+__look.rayX.toFixed(3),+__look.rayY.toFixed(3),+__look.rayZ.toFixed(3)]}})()`)
      // HUD 按自身刷新率重绘：最多再等 3 帧读提示文字（textContent；innerText 会受过渡样式影响）
      r.hudPrompt = false
      for (let k = 0; k < (r.target ? 3 : 1) && !r.hudPrompt; k++) { await frames(1); r.hudPrompt = await ev(`document.body.textContent.includes('接触 鹉主杰瑞')`) }
      res.push({ name, ...r }); console.log(name, JSON.stringify(r))
      if (name === '南 1.7m') await shot('game-aim-prompt')
    }
    if (part === 'cases') { step('aim-cases', { jerry: j, box, results: res }); ws.close(); throw Error('aim-done') }
    // 真实按键 E：回到南 1.7m 对准，派发键盘事件
    await placeLook(box.x, box.y + 1.7, box.x, box.y, box.z); await frames(2)
    const ind0 = await ev('__engine.indoctrination')
    for (const type of ['keyDown', 'keyUp']) await send('Input.dispatchKeyEvent', { type, key: 'e', code: 'KeyE', windowsVirtualKeyCode: 69, nativeVirtualKeyCode: 69, text: type === 'keyDown' ? 'e' : undefined })
    await frames(2)
    let ind1 = await ev('__engine.indoctrination'), via = 'keyboard'
    // 无指针锁定时 App 不把键盘交给游戏：改为置位与 E 键处理器相同的 engine.input.interact（引擎下一帧照常结算）
    if (ind1 === ind0) { await ev('(()=>{__engine.input.interact=true;return true})()'); await frames(2); ind1 = await ev('__engine.indoctrination'); via = 'engine.input.interact（E 键处理器同一入口；无头无指针锁定，键盘事件不进游戏）' }
    if (ind1 === ind0) { await ev('(()=>{__engine.scanInteract();__engine.doInteract();return true})()'); ind1 = await ev('__engine.indoctrination'); via = 'doInteract' }
    await frames(2); await shot('game-aim-contact')
    const stuporAfter = await ev('!!__engine.jerryRun.stupor')
    step('aim', { jerry: j, box, results: res, contact: { ind0, ind1, via, stuporTriggered: stuporAfter } })
    await ev(`(()=>{const e=__engine;e.jerryRun.stupor=null;e.indoctrination=0;e.dev.frozenAI=false;return true})()`)
    ws.close(); throw Error('aim-done')
  }
  ws.close()
} catch (err) { const m = String(err?.message ?? err); if (!['enter-done', 'closed', 'shots-done', 'aim-done'].includes(m)) { report.error = m; console.log('失败：', m) } }
finally {
  report.errors = errors
  if (phase === 'shots' || phase === 'aim') {
    const f = out + `game-verify-${phase === 'aim' ? 'aim' : mode}.json`
    if (process.env.JR_SHOTS || process.env.JR_AIM_PART) { try { const old = JSON.parse(readFileSync(f, 'utf8')); report.steps = [...old.steps.filter((o) => !report.steps.some((n) => n.name === o.name)), ...report.steps]; report.errors = [...(old.errors ?? []), ...report.errors] } catch { /* 首批 */ } }
    writeFileSync(f, JSON.stringify(report, null, 2) + '\n')
  }
  if (phase === 'close') { try { process.kill(-Number(readFileSync(pidFile, 'utf8')), 'SIGKILL') } catch { /* 已退出 */ } }
  if (errors.length) console.log('浏览器错误：', errors.length, JSON.stringify(errors.slice(0, 5)).slice(0, 1500))
  process.exit(0)
}
